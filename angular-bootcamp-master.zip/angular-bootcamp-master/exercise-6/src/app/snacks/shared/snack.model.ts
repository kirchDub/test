export interface Snack {
  id: number;
  name: string;
  description: string;
  snackType: SnackType;
  calories: number;
  fat: number;
  protein: number;
  carbohydrates: number;
}

export enum SnackType {
  Bitter = 'BITTER',
  Salty = 'SALTY',
  Sour = 'SOUR',
  Sweet = 'SWEET',
  Umami = 'UMAMI',
}​​​​​
