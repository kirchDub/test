import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styles: [
  ]
})
export class FooterComponent implements OnInit {

  footerText = 'Your use of this product is governed by the terms of your company agreement. You may not use or disclose this product or allow others to use it or disclose it, except as permitted by your agreement with Optum.';

  constructor() { }

  ngOnInit(): void {
  }

}
