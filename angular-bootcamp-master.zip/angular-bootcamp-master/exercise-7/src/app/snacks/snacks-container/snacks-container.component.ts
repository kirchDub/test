import { Component, OnInit } from '@angular/core';
import { Snack } from '../shared/snack.model';
import { SnackService } from '../shared/snack.service';

@Component({
  selector: 'app-snacks-container',
  templateUrl: './snacks-container.component.html',
  styles: [
  ]
})
export class SnacksContainerComponent implements OnInit {

  snacksTableTitle = 'Snacks Table View';
  snacksTreeTitle = 'Snacks Tree View';
  snackDetailTitle = 'Snack Detail';

  snacks: Snack[];
  selectedSnack: Snack;

  constructor(private snackService: SnackService) { }

  ngOnInit(): void {
    this.snackService.allSnacks.subscribe((result) => {
      this.snacks = [...result];
    });
  }

  onSwitchTab(event: any): void {}

  setSelectedSnack(snack: Snack) {
    this.selectedSnack = snack;
  }
}
