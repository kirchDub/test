package com.optum.claimsprocessor.dto;

import java.io.Serializable;
import java.time.Instant;

public class PatientSummary implements Serializable {

  private String patientName;
  private double totalCost;
  private Instant dateProcessed;

  public PatientSummary() {}

  public String getPatientName() {
    return patientName;
  }

  public void setPatientName(String patientName) {
    this.patientName = patientName;
  }

  public double getTotalCost() {
    return totalCost;
  }

  public void setTotalCost(double totalCost) {
    this.totalCost = totalCost;
  }

  public Instant getDateProcessed() {
    return dateProcessed;
  }

  public void setDateProcessed(Instant dateProcessed) {
    this.dateProcessed = dateProcessed;
  }
}
