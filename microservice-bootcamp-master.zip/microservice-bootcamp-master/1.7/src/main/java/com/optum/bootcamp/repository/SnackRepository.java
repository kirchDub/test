package com.optum.bootcamp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.optum.bootcamp.entity.SnackEntity;

public interface SnackRepository extends JpaRepository<SnackEntity, Integer> {}
