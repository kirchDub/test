[![Generated with GP Scaffold](https://badges.optum.com/badge/generated%20with-GP%20Scaffold-e87722?style=flat-square&labelColor=434448)](https://github.optum.com/gp-optumil/gp-scaffold)

<!-- To add a Jenkins build status badge, ensure that your Jenkins server has been configured correctly (See https://gp-docs.optum.com/docs/knowledge/jenkins/configuration). Then, navigate to a job in Jenkins, click "Embeddable Build Status" on the left-hand side, copy one of the Markdown options, and paste it here. -->

# angular-bootcamp

## Prerequisites for Deployment

### 1. Add GitHub User

Add the following service account as a user to the GitHub organization:

- User: `your-service-account`

### 2. Create Artifactory Docker

Go to [TechHub](https://tech.optum.com/products/artifactory/create-artifactory-namespace) to create the namespace. If you've never logged into [Artifactory](https://repo1.uhc.com/artifactory/webapp/#/login) before, you will need to do so first.

- Name: `artifactory-namespace`
- User: `your-service-account`

### 3. Create Load Balancers

Go to [TechHub](https://tech.optum.com/products/load-balancing/create-load-balancer) and create a load balancer for both Stage and Production. If the following names are not available, choose a different URL and update the `gtmUrl`s and `ltmUrl`s in `pipeline.yml` to reflect this change.

- Stage: `angular-bootcamp-stage.optum.com`
- Prod: `angular-bootcamp.optum.com`

### 4. Create OpenShift Projects

Go to [TechHub](https://tech.optum.com/products/openshift/create-osfi-origin-project) and use the OpenShift project creation wizard (**Create OSFI Origin Project**) with the following information:  

Be sure to also add `your-service-account` as another OpenShift project administrator.

- Nonprod
  - Datacenter: `Chaska`
  - Zone: `Core`
  - Environment: `Non-Prod`
  - Project Name: `angular-bootcamp-nonprod`

- Stage (CTC)
  - Datacenter: `Chaska`
  - Zone: `Core`
  - Environment: `Stage`
  - Project Name: `angular-bootcamp-stage-ctc`

- Stage (ELR)
  - Datacenter: `Elk River`
  - Zone: `Core`
  - Environment: `Stage`
  - Project Name: `angular-bootcamp-stage-elr`

- Prod (CTC)
  - Datacenter: `Chaska`
  - Zone: `Core`
  - Environment: `Prod`
  - Project Name: `angular-bootcamp-ctc`

- Prod (ELR)
  - Datacenter: `Elk River`
  - Zone: `Core`
  - Environment: `Prod`
  - Project Name: `angular-bootcamp-elr`

### 5. Configure Jenkins

If you don't already have a Jenkins instance, use [TechHub](https://tech.optum.com/products/jenkins/create-jenkins-master) to create a Jenkins project. Follow this [Configuring Jenkins guide](https://gp-docs.optum.com/docs/knowledge/jenkins/configuration) for GP Scaffold-specific configuration instructions. 


[Get an Artifactory NPM auth key](https://github.optum.com/jenkins/docker_build_agents/tree/master/mixins/jenkins_mixin_nodejs#find-npm_auth_key) to add to Jenkins credential store as a key named `npm_auth`. If you name the credential differently in Jenkins, you will need to update `npmAuthToken` in `pipeline.yml`.

---

## Local Development

Run `npm install` to download your project's dependencies. 

This application is scaffolded with a `package-lock.json` which sets dependencies that will not conflict with each other. Over time, these dependencies will become out-of-date. To get the most up-to-date dependencies, simply remove `package-lock.json` and run `npm install` again. 

Optum's Angular UI Toolkit is installed by default. Please see [uitoolkit.optum.com](https://uitoolkit.optum.com/) for more information about using the Toolkit. 

### Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

### Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

### Build

Run `ng build` to build the project. 

### Test

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

---

## Local Containers

You may want to build the application into a Docker image and run it with docker compose. This assumes you have previously run `ng build`

```
docker-compose up --build -d
```

Stop the locally running containers with:

```
docker-compose down
```

---

## Deploying

Deploying to Stage and Production is done via tags.

Tags should be created in the format of `<deployment_platform>.standard.<deploy_env>.<BUILD_NUMBER>.<GIT_COMMIT_SHORT>.<timestamp_milliseconds>.<author_msid>` (e.g. `openshift.standard.prod.4.19e5fb3.1583466063486.jdoe3`)

You can create a release version of the library by creating a tag in Github.  [Read more](https://help.github.com/en/enterprise/2.19/user/github/administering-a-repository/managing-releases-in-a-repository)

Alternatively, execute the following commands in your local git repository:

```
git tag <tag>
git push origin --tags
```
