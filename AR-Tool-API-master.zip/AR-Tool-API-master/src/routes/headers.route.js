var express = require('express');
var router = express.Router();
var db = require('../config/db.config.js');
var teradata = require('../config/teradata.config.js');
var async = require('async');
const request = require('request');
var memberProcess = require('../common/index.js');
const claims = require('../controller/claims');

/* GET Excel Headers. */
router.get('/:load_file_id', function (req, res) {
    try{
    db.query('select load_file_headers from batch_file_input_headers where load_file_id=?', req.params.load_file_id, function (err, records) {
        if (err) throw err;
        else {
            if (records.length > 0) {
                res.send({
                    status: 200,
                    result: 'success',
                    response: records
                })
            } else {
                res.send({
                    status: 404,
                    result: 'failure',
                    response: 'no records found'
                })
            }
        }
    })
}catch(error) 
{
    res.send({
        status: 500,
        result: 'failure',
        response: 'error'
    })
}
})


router.post('/mappings/:load_file_id', function (req, res) {
    try{
    res.connection.setTimeout(0);
    console.log("mapp called");
    let mappings = req.body;
    async.eachSeries(Object.keys(mappings), function (key, callbk) {
        if (mappings[key] && mappings[key] !== '--') {
            db.query('select input_field_id from batch_file_field where input_field_name =?', key.toLowerCase(), function (err, records, fields) {
                let insertIfNotExistQuery = "INSERT INTO batch_file_field_mapping (input_field_id, input_file_excel_header) " +
                    "SELECT * FROM (SELECT " + records[0].input_field_id + ",'" + mappings[key].toLowerCase() + "') AS tmp " +
                    "WHERE NOT EXISTS ( " +
                    "SELECT input_field_id FROM batch_file_field_mapping WHERE input_field_id = " + records[0].input_field_id +
                    " and input_file_excel_header='" + mappings[key].toLowerCase() + "') LIMIT 1";

                db.query(insertIfNotExistQuery, function (err, records, fields) {
                    callbk(null,"done");
                    console.log("err ", err)
                })

            });
        } else {
            callbk(null,"done");
        }
        
    });


    const reversemap = Object.keys(mappings)
        .reduce((obj, key) => ({ ...obj, [mappings[key]]: key }), {});

    db.query('select file_metdata,load_file_id from batch_file_input where load_file_id=?', req.params.load_file_id, function (err, records, fields) {
        if (err) throw err;

        else {
            var filedata = records.map(attribute => attribute.file_metdata);
            filedata = JSON.parse(filedata);

            var fileId = JSON.parse(JSON.stringify(records));
            var insertId = fileId[0].load_file_id;

            var mapKeys = Object.keys(reversemap);

            for (var i = 0; i < mapKeys.length; i++) {
                for (var j = 0; j < filedata.length; j++) {
                    if (filedata[j].hasOwnProperty(mapKeys[i])) {
                        var oobject = filedata[j];
                        var value = reversemap[mapKeys[i]];
                        oobject[value] = filedata[j][mapKeys[i]];
                        if (value !== mapKeys[i]) {
                            delete filedata[j][mapKeys[i]];
                        }
                    }
                }

            }

            for (var i = 0; i < filedata.length; i++) {
                filedata[i].load_file_id = insertId;
                var d = filedata[i].patient_dob;
                // var yy = d.substr(-2);
                // var newdate = (yy <= 19) ? '20' + yy : '19' + yy;
                // d = d.substr(0, d.lastIndexOf("/"));
                // d += '/' + newdate;
                try {
                    filedata[i].patient_dob = new Date(d).toISOString().substring(0, 10);
                }
                catch (err) {
                    console.log("did not convert "+d);
                    filedata[i].patient_dob = "";
                }
                try {
                    filedata[i].from_date_of_service = new Date(filedata[i].from_date_of_service).toISOString().substring(0, 10);
                }
                catch (err) {
                    console.log("did not convert "+filedata[i].from_date_of_service);
                    filedata[i].from_date_of_service = "";
                }
                try {
                    filedata[i].to_date_of_service = new Date(filedata[i].to_date_of_service).toISOString().substring(0, 10);
                }
                catch (err) {
                    console.log("did not convert "+filedata[i].to_date_of_service);
                    filedata[i].to_date_of_service = "";
                }
                try {
                    filedata[i].claim_last_reconsideration_date = new Date(filedata[i].claim_last_reconsideration_date).toISOString().substring(0, 10);
                }
                catch (err) {
                    console.log("did not convert "+filedata[i].claim_last_reconsideration_date);
                    filedata[i].claim_last_reconsideration_date = "";
                }
                try {
                    filedata[i].claim_paid_date = new Date(filedata[i].claim_paid_date).toISOString().substring(0, 10);
                }
                catch (err) {
                    console.log("did not convert "+filedata[i].claim_paid_date);
                    filedata[i].claim_paid_date = "";
                }
                try {
                    filedata[i].patient_first_name = filedata[i].patient_first_name.split("'")[0];
                }
                catch (err) {
                    console.log("did not convert "+filedata[i].patient_first_name);
                    filedata[i].patient_first_name = "INVALID FIRST NAME";
                }
                try {
                    filedata[i].prov_natl_prov_id = Number(filedata[i].prov_natl_prov_id).toFixed(0).replace('NaN', '');
                }
                catch (err) {
                    console.log("did not convert "+filedata[i].prov_natl_prov_id);
                    filedata[i].prov_natl_prov_id = "";
                }
                try {
                    filedata[i].prov_tax_id = Number(filedata[i].prov_tax_id).toFixed(0).replace('NaN', '');
                }
                catch (err) {
                    console.log("did not convert "+filedata[i].prov_tax_id);
                    filedata[i].prov_tax_id = "";
                }
                try {
                    filedata[i].claim_billed_charges = formatMoney(filedata[i].claim_billed_charges.toString().replace('$', '').replace(',', '').replace('(', '-').replace(')', ''), 2).replace('$NaN', '');
                }
                catch (err) {
                    console.log("did not convert "+filedata[i].claim_billed_charges);
                    filedata[i].claim_billed_charges = "";
                }
                try {
                    filedata[i].claim_contractual_adjustments = formatMoney(filedata[i].claim_contractual_adjustments.toString().replace('$', '').replace(',', '').replace('(', '-').replace(')', ''), 2).replace('$NaN', '');
                }
                catch (err) {
                    console.log("did not convert "+filedata[i].claim_contractual_adjustments);
                    filedata[i].claim_contractual_adjustments = "";
                }
                try {
                    filedata[i].claim_non_covered_charges = formatMoney(filedata[i].claim_non_covered_charges.toString().replace('$', '').replace(',', '').replace('(', '-').replace(')', ''), 2).replace('$NaN', '');
                }
                catch (err) {
                    console.log("did not convert "+filedata[i].claim_non_covered_charges);
                    filedata[i].claim_non_covered_charges = "";
                }
                try {
                    filedata[i].claim_deductible = formatMoney(filedata[i].claim_deductible.toString().replace('$', '').replace(',', '').replace('(', '-').replace(')', ''), 2).replace('$NaN', '');
                }
                catch (err) {
                    console.log("did not convert "+filedata[i].claim_deductible);
                    filedata[i].claim_deductible = "";
                }
                try {
                    filedata[i].claim_copay = formatMoney(filedata[i].claim_copay.toString().replace('$', '').replace(',', '').replace('(', '-').replace(')', ''), 2).replace('$NaN', '');
                }
                catch (err) {
                    console.log("did not convert "+filedata[i].claim_copay);
                    filedata[i].claim_copay = "";
                }
                try {
                    filedata[i].claim_coins = formatMoney(filedata[i].claim_coins.toString().replace('$', '').replace(',', '').replace('(', '-').replace(')', ''), 2).replace('$NaN', '');
                }
                catch (err) {
                    console.log("did not convert "+filedata[i].claim_coins);
                    filedata[i].claim_coins = "";
                }
                try {
                    filedata[i].claim_total_payment = formatMoney(filedata[i].claim_total_payment.toString().replace('$', '').replace(',', '').replace('(', '-').replace(')', ''), 2).replace('$NaN', '');
                }
                catch (err) {
                    console.log("did not convert "+filedata[i].claim_total_payment);
                    filedata[i].claim_total_payment = "";
                }
                try {
                    filedata[i].claim_expected_payment = formatMoney(filedata[i].claim_expected_payment.toString().replace('$', '').replace(',', '').replace('(', '-').replace(')', ''), 2).replace('$NaN', '');
                }
                catch (err) {
                    console.log("did not convert "+filedata[i].claim_expected_payment);
                    filedata[i].claim_expected_payment = "";
                }



            }

            var importvalues = [];

            for (var i = 0; i < filedata.length; i++) {
                importvalues.push([filedata[i].load_file_id, filedata[i].plan_name, filedata[i].product, filedata[i].patient_last_name, filedata[i].patient_first_name, filedata[i].patient_dob, filedata[i].patient_group_policy, filedata[i].subscriber_id, filedata[i].patient_account_number, filedata[i].prov_natl_prov_id, filedata[i].prov_tax_id, filedata[i].prov_name, filedata[i].claim_number, filedata[i].from_date_of_service, filedata[i].to_date_of_service, filedata[i].claim_billed_charges, filedata[i].claim_contractual_adjustments, filedata[i].claim_non_covered_charges, filedata[i].claim_deductible, filedata[i].claim_copay, filedata[i].claim_coins, filedata[i].claim_total_payment, filedata[i].claim_expected_payment, filedata[i].claim_provider_comments, filedata[i].claim_reason_codes, filedata[i].claim_paid_date, filedata[i].claim_last_reconsideration_date, filedata[i].ExtractField1, filedata[i].ExtractField2, filedata[i].ExtractField3, filedata[i].ExtractField4, filedata[i].ExtractField5,filedata[i].area])
            }

            var sql = "INSERT INTO batch_file_input_detail (load_file_id,plan_name, product, patient_last_name, patient_first_name, patient_dob, patient_group_policy, subscriber_id, patient_account_number, prov_natl_prov_id, prov_tax_id, prov_name, claim_number, from_date_of_service, to_date_of_service, claim_billed_charges, claim_contractual_adjustments, claim_non_covered_charges, claim_deductible, claim_copay, claim_coins, claim_total_payment, claim_expected_payment, claim_provider_comments, claim_reason_codes, claim_paid_date, claim_last_reconsideration_date, ExtractField1, ExtractField2, ExtractField3, ExtractField4, ExtractField5,area) VALUES ?";

            db.query(sql, [importvalues], function (err, result) {
                if (err) throw err;
                // Member Search""

                console.log("Inserted records into input detail table");
                for (var i = 0; i < filedata.length; i++) {
                    filedata[i].EXCEL_ROW_ID = i + 2;
                }

                db.query('select load_file_detail_id from batch_file_input_detail where load_file_id=? order by load_file_detail_id limit 1', req.params.load_file_id, function (err, results, fields) {
                    var filedetailId = JSON.parse(JSON.stringify(results));
                    var filedetailInsertId = filedetailId[0].load_file_detail_id;
                    if (results.length > 0) {
                        db.query("update batch_file_input set status_id=2 where load_file_id=?", insertId, function (err, resultt) {

                        });
                        memberProcess.memberSearch(res, filedata, insertId, filedetailInsertId, function (error, response) {
                            console.log("Completed member insert in header route");
                            // insertClaims(filedetailInsertId, function (er, resp) {
                            //res.status(200).json({ message: 'Members inserted successfully' });
                            // });
                        });

                    }
                });


            });
        }
    })
}catch(error) 
{
    res.send({
        status: 500,
        result: 'failure',
        response: 'error'
    })
}
})

function formatMoney(n, c, d, t) {
    var c = isNaN(c = Math.abs(c)) ? 2 : c,
        d = d == undefined ? "." : d,
        t = t == undefined ? "," : t,
        s = n < 0 ? "-" : "",
        i = String(parseInt(n = Math.abs(Number(n) || 0).toFixed(c))),
        j = (j = i.length) > 3 ? j % 3 : 0;

    return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
};




module.exports = router;