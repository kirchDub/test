import { TestBed } from '@angular/core/testing';
import { 
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';

import { SnackService } from './snack.service';
import { environment } from 'src/environments/environment';
import { Snack, SnackType } from './snack.model';

describe('SnackService', () => {
  let httpTestingController: HttpTestingController;
  let service: SnackService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
    });
    service = TestBed.inject(SnackService);
    httpTestingController = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('can call snacks API and cache response data', () => {
    let testData: Snack[] = [
      {
        id: 1,
        name: 'Hummus',
        description: 'A dip, spread, or savory dish made from cooked, mashed chickpeas',
        snackType: SnackType.Umami,
        calories: 177,
        fat: 8.59,
        protein: 4.8,
        carbohydrates: 20.1,
      },
      {
        id: 2,
        name: 'Broccoli',
        description: 'An edible green plant in the cabbage family',
        snackType: SnackType.Bitter,
        calories: 34,
        fat: 0.0,
        protein: 4.7,
        carbohydrates: 80.4,
      },
    ];

    service.allSnacks.subscribe((result) => {
      expect(result).toEqual(testData);
    });

    const request = httpTestingController.expectOne(`${environment.apiBaseUrl}/snacks`);

    expect(request.request.method).toEqual('GET');

    request.flush(testData);

    service.allSnacks.subscribe((result) => {
      expect(result).toEqual(testData);
    });

    httpTestingController.expectNone(`${environment.apiBaseUrl}/snacks`);
  });
});
