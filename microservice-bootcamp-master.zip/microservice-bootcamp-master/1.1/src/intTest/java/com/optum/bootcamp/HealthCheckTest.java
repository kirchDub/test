package com.optum.bootcamp;

import static io.restassured.RestAssured.when;
import static org.hamcrest.Matchers.equalTo;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;

class HealthCheckTest {

  @BeforeAll
  static void setup() {
    RestAssured.baseURI = Config.baseURI;
    RestAssured.port = Config.port;
    // Ignore SSL handshake errors
    RestAssured.useRelaxedHTTPSValidation();
  }

  @Test
  void testHealthCheck() {
    when()
        .get("/api/actuator/health")
        .then()
        .assertThat()
        .statusCode(200)
        .body("status", equalTo("UP"));
  }
}
