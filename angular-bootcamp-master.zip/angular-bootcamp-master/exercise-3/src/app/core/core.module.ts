import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UITKFooterModule, UITKNavigationModule } from '@uitk/angular';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';



@NgModule({
  declarations: [HeaderComponent, FooterComponent],
  imports: [
    CommonModule,
    UITKNavigationModule,
    UITKFooterModule,
  ],
  exports: [
    HeaderComponent,
    FooterComponent
  ],
})
export class CoreModule { }
