var nodemailer = require('nodemailer');
var db = require('../config/db.config.js');

exports.sendEmail = function (loadFileId, callback) {
    try {
    db.query("select A.email,A.first_name, B.file_name, B.load_dttm from pdat01.users A left outer join pdat01.batch_file_input B on A.login_name = B.load_user_id where B.load_file_id = ? order by login_name limit 1", loadFileId, function (err, resultt) {
        if (err) {
            callback(err);
        }
        else {
            var transporter = nodemailer.createTransport({
                host: 'ctc-smtp-relay-ose.optum.com',
                port: 25,
                secure: false,
                rejectUnauthorized: false,
                ignoreTLS: true
            });
            var emailDetails = JSON.parse(JSON.stringify(resultt));
            var userEmail = emailDetails[0].email;
            var fileName = emailDetails[0].file_name;
            var userName = emailDetails[0].first_name;
            var submittedDate = emailDetails[0].load_dttm.substring(0, 10);
            var mailOptions = {
                from: 'no-reply@optum.com',
                to: userEmail,
                subject: "PART File Processing Complete - " + fileName + "",
                text: "" + userName + "\n"+
                "Your file " + fileName + " which was submitted on " + submittedDate + " has completed Member and Claim search processing.\n"+
                "You can review your file here " + process.env.REVIEW_URL + "\n"+
                "\n"+
                "If you have questions or issues, \n"+
                "Contact PART Support  " + process.env.SERVICE_NOW + " and provide the reference."
            };

            transporter.sendMail(mailOptions, function (error, info) {
                if (error) {
                    console.log(error);
                    //   cb(error);
                } else {
                    console.log('Email sent: ' + info.response);
                }
            });
        }
    })
}
catch(error)
{
    callback({
        error
    });
}
}