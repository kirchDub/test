package com.optum.claimsprocessor.util;

import java.time.Instant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.optum.PatientSummary;
import com.optum.SubmittedClaim;

public class PatientSummaryUtil {

  private static Logger LOG = LoggerFactory.getLogger(PatientSummaryUtil.class);

  public static PatientSummary processClaim(SubmittedClaim submittedClaim) {
    PatientSummary patientSummary = new PatientSummary();
    patientSummary.setPatientName(submittedClaim.getPatientName());
    double totalCost =
        submittedClaim.getPrescriptions().stream()
            .mapToDouble(prescription -> prescription.getCost())
            .sum();
    patientSummary.setTotalCost(totalCost);
    patientSummary.setDateProcessed(Instant.now());
    LOG.info("Created PatientSummary from submitted claim {} ", patientSummary);
    return patientSummary;
  }
}
