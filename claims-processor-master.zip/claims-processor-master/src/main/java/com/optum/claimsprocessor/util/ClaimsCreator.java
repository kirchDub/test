package com.optum.claimsprocessor.util;

import static java.util.stream.Collectors.toList;

import java.time.Instant;
import java.util.List;
import java.util.Random;
import java.util.stream.Stream;

import com.optum.Prescription;
import com.optum.SubmittedClaim;

public class ClaimsCreator {
  private static String[] names =
      new String[] {
        "Don McClean",
        "Brody Taylor",
        "Jeff Bridges",
        "Dana White",
        "Matt Damon",
        "Lawrence Olivier",
        "Charles Dickens",
        "Paul Bevere",
        "Haddon Davis",
        "Larry Finch",
        "Darryl  Hall",
        "Martin Peters",
        "Frank Deboer",
        "Martin Jaansen",
        "Virgyl Van Dijk",
        "Wendy Bojk",
        "Weiss Bakker",
        "Patty Hubbard",
        "Priscilla White",
        "Paula De Vries",
        "Pamela Reisburg",
        "Chistianne Van Damme",
        "Lucille Richards",
        "George Branson",
        "Molly Henninberg",
        "Dani Jackson",
        "Reggie Fischer",
        "Anatoly Karpovich",
        "Yegnevy Kruschev",
        "Lola Brinch",
        "Randal Kissinger",
        "Brett Stevens",
        "Colin Bale",
        "Matilda Roberts",
        "Xavier Mascimento",
        "Jadon Savalino",
        "Brianna Fredericks",
        "Peony Williams",
        "Georgina Reinhardt",
        "Taylor Olson",
        "Evelyn Baruch",
        "Joshua Bloch"
      };
  private static String[] drugs =
      new String[] {
        "Myalept", "Ravicti", "Mavenclad", "Folotyn", "Remdesivir", "Nexletol", "Pravastatin"
      };
  private static Random random = new Random();

  public static List<SubmittedClaim> createClaims() {
    return Stream.of(names).map(name -> createSubmittedClaim(name)).collect(toList());
  }

  private static SubmittedClaim createSubmittedClaim(String name) {
    SubmittedClaim submittedClaim = new SubmittedClaim();
    submittedClaim.setAction("Process Prescription");
    submittedClaim.setCostCode(random.nextDouble());
    submittedClaim.setDateSubmitted(Instant.now());
    submittedClaim.setPatientName(name);
    submittedClaim.setPrescriptions(prescriptions());
    return submittedClaim;
  }

  private static List<Prescription> prescriptions() {
    return Stream.of(drugs)
        .map(drugName -> createPrescription(drugName, random.nextDouble() * 6000))
        .collect(toList());
  }

  private static Prescription createPrescription(String drugName, double cost) {
    Prescription prescription = new Prescription();
    prescription.setCost(cost);
    prescription.setDrugName(drugName);
    return prescription;
  }
}
