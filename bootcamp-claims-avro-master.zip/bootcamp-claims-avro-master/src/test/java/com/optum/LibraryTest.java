package com.optum;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.avro.Schema;
import org.apache.avro.data.TimeConversions;
import org.apache.avro.reflect.ReflectData;
import org.junit.jupiter.api.Test;

public class LibraryTest {
  @Test
  public void schemaGenerate2() throws Exception {
    ReflectData.get().addLogicalTypeConversion(new TimeConversions.TimestampMillisConversion());
    ReflectData.get().addLogicalTypeConversion(new TimeConversions.DateConversion());
    Schema schema = ReflectData.get().getSchema(SubmittedClaim.class);
    // uncomment to view generated avro schema
    // System.out.println(schema.toString(true));

    Path avroPath = Paths.get("./src/main/resources/avro");
    Files.createDirectories(avroPath);
    Path path =
        Paths.get("./src/main/resources/avro/" + SubmittedClaim.class.getSimpleName() + ".avsc");
    byte[] strToBytes = schema.toString().getBytes();

    Files.write(path, strToBytes);
  }
}
