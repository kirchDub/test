package com.optum;

import java.time.Instant;
import java.util.ArrayList;

public class SubmittedClaim {
  private String patientName;
  private Instant dateSubmitted;
  private double costCode;
  private String action;
  private ArrayList<Prescription> prescriptions;
}
