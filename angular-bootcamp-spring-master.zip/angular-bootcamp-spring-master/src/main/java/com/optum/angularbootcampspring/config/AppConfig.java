package com.optum.angularbootcampspring.config;

import com.optum.angularbootcampspring.domain.IngredientDto;
import com.optum.angularbootcampspring.domain.NutritionFactsDto;
import com.optum.angularbootcampspring.entities.Ingredient;
import com.optum.angularbootcampspring.entities.NutritionFacts;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    ModelMapper modelMapper() {
        ModelMapper mapper = new ModelMapper();
        mapper.addMappings(nutritionFactsMapping);
        mapper.addMappings((ingredientsMapping));
        return mapper;
    }


    static PropertyMap<NutritionFacts, NutritionFactsDto> nutritionFactsMapping = new PropertyMap<NutritionFacts, NutritionFactsDto>() {
        @Override
        protected void configure() {
            map().setAllergicNotice(source.getAllergicNotice());
            map().setTotalCalories(source.getTotalCalories());
            map().setNumberOfServings(source.getNumberOfServings());
        }
    };

    static PropertyMap<Ingredient, IngredientDto> ingredientsMapping = new PropertyMap<Ingredient, IngredientDto>() {
        @Override
        protected void configure() {
            map().setId(source.getId());
            map().setClassification(source.getClassification());
            map().setName(source.getName());
            map().setPercent(source.getPercent());
        }
    };


}
