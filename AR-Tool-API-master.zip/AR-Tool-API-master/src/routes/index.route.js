var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  try{
  res.render('index', { title: 'AR Tool API' });
}catch(error) 
{
    res.send({
        status: 500,
        result: 'failure',
        response: 'error'
    })
}
});

module.exports = router;