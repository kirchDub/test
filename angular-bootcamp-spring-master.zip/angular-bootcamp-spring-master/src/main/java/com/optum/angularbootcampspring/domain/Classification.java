package com.optum.angularbootcampspring.domain;

public enum Classification {
    Natural,
    Artificial
}
