package com.optum.bootcamp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.optum.bootcamp.model.Snack;
import com.optum.bootcamp.service.SnackService;

@RestController
public class SnackController {
  @Autowired SnackService snackService;

  @GetMapping(value = "/v1/snacks/{snackId}", produces = MediaType.APPLICATION_JSON_VALUE)
  public Snack getSnackById(@PathVariable("snackId") Integer id) {
    return snackService.getSnackById(id);
  }
}
