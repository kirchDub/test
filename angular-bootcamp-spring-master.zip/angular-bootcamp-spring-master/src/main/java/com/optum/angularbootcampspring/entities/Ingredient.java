package com.optum.angularbootcampspring.entities;

import com.optum.angularbootcampspring.domain.Classification;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.Objects;

@Data
@Entity
public class Ingredient implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @NotBlank
    private String name;

    @ManyToOne
    @JoinColumn(name = "snack_id")
    private Snack snack;

    @Digits(integer = 3, fraction = 0)
    private int percent;

    @Column(length = 10, columnDefinition = "varchar(10) default 'Artificial'")
    @Enumerated(EnumType.STRING)
    private Classification classification = Classification.Artificial;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Ingredient)) return false;
        Ingredient that = (Ingredient) o;
        return name.equals(that.name) &&
                snack.equals(that.snack);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, snack);
    }
}
