import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SnacksTreeComponent } from './snacks-tree.component';

describe('SnacksTreeComponent', () => {
  let component: SnacksTreeComponent;
  let fixture: ComponentFixture<SnacksTreeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SnacksTreeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SnacksTreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
