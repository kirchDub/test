package com.optum.claimsprocessor;

public class Config {

  public static String baseURI = System.getProperty("baseURI", "http://localhost");
  public static int port = Integer.parseInt(System.getProperty("port", "8080"));
}
