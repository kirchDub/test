package com.optum.bootcamp.controller;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.optum.bootcamp.entity.SnackEntity;
import com.optum.bootcamp.model.Snack;
import com.optum.bootcamp.service.SnackService;

@SpringBootTest
public class SnackControllerTest {

  @Autowired private SnackController snackController;
  @MockBean private SnackService snackService;

  @Test
  public void getSnackByIdTest() {
    SnackEntity snackToReturn = new SnackEntity();
    snackToReturn.setId(3);
    snackToReturn.setName("Butterfingers");

    Mockito.when(snackService.getSnackById(3)).thenReturn(snackToReturn);

    Snack retrievedSnack = snackController.getSnackById(3);

    assertThat(retrievedSnack.getId()).isEqualTo(3);
    assertThat(retrievedSnack.getName()).isEqualTo("Butterfingers");
  }

  @Test
  public void createSnackTest() {
    Integer id = 1;
    String name = "Skittles";

    Snack snackToCreate = new Snack();
    snackToCreate.setName(name);

    SnackEntity snackToReturn = new SnackEntity(id, name);

    Mockito.when(snackService.createSnack(Mockito.any(SnackEntity.class)))
        .thenReturn(snackToReturn);

    Snack createdSnack = snackController.createSnack(snackToCreate);

    assertThat(createdSnack.getId()).isEqualTo(id);
    assertThat(createdSnack.getName()).isEqualTo(name);
  }
}
