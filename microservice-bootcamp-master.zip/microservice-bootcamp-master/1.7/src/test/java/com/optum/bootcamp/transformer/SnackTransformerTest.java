package com.optum.bootcamp.transformer;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

import com.optum.bootcamp.entity.SnackEntity;
import com.optum.bootcamp.model.Snack;

public class SnackTransformerTest {

  @Test
  public void toSnackTest() {
    Integer id = 1;
    String name = "Veggie Straws";
    SnackEntity snackEntity = new SnackEntity(id, name);

    Snack snack = SnackTransformer.toSnack(snackEntity);

    assertThat(snack.getId()).isEqualTo(id);
    assertThat(snack.getName()).isEqualTo(name);
  }

  @Test
  public void toSnackEntityTest() {
    Integer id = 1;
    String name = "Veggie Straws";
    Snack snack = new Snack(id, name);

    SnackEntity snackEntity = SnackTransformer.toSnackEntity(snack);

    assertThat(snackEntity.getId()).isEqualTo(id);
    assertThat(snackEntity.getName()).isEqualTo(name);
  }
}
