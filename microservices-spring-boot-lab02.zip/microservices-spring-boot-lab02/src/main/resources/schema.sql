CREATE TABLE medication_type (
   id   INTEGER IDENTITY NOT NULL PRIMARY KEY
  ,typename VARCHAR(25) NOT NULL
);

CREATE TABLE medication (
   brandname            VARCHAR(50)
  ,class                VARCHAR(50)
  ,classification       VARCHAR(50)
  ,description          VARCHAR(100)
  ,doseForm             VARCHAR(50)
  ,drugtype             INTEGER  NOT NULL
  ,drugusages           VARCHAR(30)
  ,federallegendcode    INTEGER  NOT NULL
  ,genericmedid         INTEGER  NOT NULL
  ,id                   INTEGER IDENTITY NOT NULL PRIMARY KEY
  ,generic              BIT  NOT NULL
  ,name                 VARCHAR(50) NOT NULL
  ,route                VARCHAR(30)
  ,strength             VARCHAR(30)
  ,strengthnumericunit  VARCHAR(3)
  ,strengthunit         VARCHAR(11)
);
