package com.optum.angularbootcampspring.domain;

public enum SnackTypes {
        Savoury,
        Sweet,
        Uncategorized
}
