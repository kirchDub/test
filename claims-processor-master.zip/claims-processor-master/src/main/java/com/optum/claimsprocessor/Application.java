package com.optum.claimsprocessor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.EnableKafka;

import com.optum.claimsprocessor.services.ClaimsProcessor;

@SpringBootApplication
@EnableKafka
public class Application {

  private ClaimsProcessor claimsProcessor;

  public static void main(String[] args) {
    SpringApplication.run(Application.class, args);
  }
}
