package com.optum.claimsprocessor.config;

import java.util.Map;

import org.apache.avro.generic.GenericRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.*;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

import io.confluent.kafka.serializers.AbstractKafkaAvroSerDeConfig;
import io.confluent.kafka.serializers.subject.TopicRecordNameStrategy;
import io.opentracing.Tracer;
import io.opentracing.contrib.kafka.spring.TracingProducerFactory;

@Configuration
public class KafkaConfiguration {

  private Map<String, Object> consumerProperties;

  @Autowired private LocalValidatorFactoryBean validator;

  @Bean
  public ProducerFactory<String, GenericRecord> producerFactory(
      KafkaProperties kafkaProps, Tracer tracer) {

    Map<String, Object> producerProperties = kafkaProps.buildProducerProperties();

    producerProperties.put("value.subject.name.strategy", TopicRecordNameStrategy.class.getName());

    producerProperties.put(AbstractKafkaAvroSerDeConfig.AUTO_REGISTER_SCHEMAS, true);

    return new TracingProducerFactory<String, GenericRecord>(
        new DefaultKafkaProducerFactory<>(producerProperties), tracer);
  }

  @Bean
  public KafkaTemplate<String, GenericRecord> kafkaTemplate(
      ProducerFactory<String, GenericRecord> producerFactory) {
    return new KafkaTemplate<>(producerFactory);
  }

  @Bean
  public ConsumerFactory<String, GenericRecord> kafkaConsumerFactory(
      KafkaProperties kafkaProps, Tracer tracer) {
    Map<String, Object> consumerProperties = kafkaProps.buildProducerProperties();
    return new DefaultKafkaConsumerFactory<>(consumerProperties);
  }
}
