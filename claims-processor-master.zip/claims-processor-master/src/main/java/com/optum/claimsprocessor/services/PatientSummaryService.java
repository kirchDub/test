package com.optum.claimsprocessor.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;

import com.optum.PatientSummary;
import com.optum.SubmittedClaim;
import com.optum.claimsprocessor.util.PatientSummaryUtil;

@Service
public class PatientSummaryService {

  private ClaimsProcessor claimsProcessor;

  private Logger LOG = LoggerFactory.getLogger(PatientSummaryService.class);

  @Autowired
  public PatientSummaryService(ClaimsProcessor claimsProcessor) {
    this.claimsProcessor = claimsProcessor;
  }

  @KafkaListener(topics = "${claims.kafka.topic}", autoStartup = "${claims.listener.enabled}")
  public void processClaim(
      SubmittedClaim submittedClaim,
      @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
      @Header(KafkaHeaders.OFFSET) long offset,
      @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition) {

    LOG.info("Received a Submitted Claim message {} " + submittedClaim);

    PatientSummary patientSummary = PatientSummaryUtil.processClaim(submittedClaim);

    claimsProcessor.publishPatientSummary(patientSummary);
  }
}
