import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UITKTabbedPanelsModule, UITKTableModule, UITKTreeModule } from '@uitk/angular';
import { SnacksContainerComponent } from './snacks-container/snacks-container.component';



@NgModule({
  declarations: [SnacksContainerComponent],
  imports: [
    CommonModule,
    UITKTabbedPanelsModule,
    UITKTableModule,
    UITKTreeModule,
  ],
  exports: [SnacksContainerComponent],
})
export class SnacksModule { }
