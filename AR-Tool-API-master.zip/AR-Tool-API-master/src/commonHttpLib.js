exports.getSOAPEnvelopRequest = function(sNamespacePrefix, sNamespace, sRequest){
    //<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:v7="http://upm3.uhc.com/security/readuserprofileandtokens/v7">
    
        var oSooapEnv = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:` + sNamespacePrefix + `="` + sNamespace + `">
                            <soapenv:Header>
                                <wsse:Security soapenv:mustUnderstand="1" xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
                                <wsse:UsernameToken wsu:Id="UsernameToken-PDAT">
                                    <wsse:Username>` + process.env.UPM_API_USERNAME + `</wsse:Username>
                                    <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">` + process.env.UPM_API_PASSWORD + `</wsse:Password>
                                    <wsse:Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">WScqanjCEAC4mQoBE07sAQ==</wsse:Nonce>
                                    <wsu:Created>` + (new Date()).toISOString() + `</wsu:Created>
                                </wsse:UsernameToken>
                            </wsse:Security>
                            </soapenv:Header>` + sRequest + `</soapenv:Envelope>`;
    
        return oSooapEnv;
    };