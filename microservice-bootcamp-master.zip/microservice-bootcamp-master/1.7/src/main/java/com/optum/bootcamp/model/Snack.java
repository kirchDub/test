package com.optum.bootcamp.model;

public class Snack {
  private Integer id;

  private String name;

  public Snack() {}

  public Snack(Integer id, String name) {
    this.id = id;
    this.name = name;
  }

  public Integer getId() {
    return id;
  }

  public String getName() {
    return name;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public void setName(String name) {
    this.name = name;
  }
}
