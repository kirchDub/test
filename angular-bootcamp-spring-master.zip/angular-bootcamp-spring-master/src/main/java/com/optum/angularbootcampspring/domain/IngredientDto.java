package com.optum.angularbootcampspring.domain;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

@Data
public class IngredientDto implements Serializable {

    private int id;

    @NotBlank
    private String name;

    private int percent;

    @NotNull
    private Classification classification;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof IngredientDto)) return false;
        IngredientDto that = (IngredientDto) o;
        return name.equals(that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
}
