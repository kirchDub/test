package com.optum.angularbootcampspring;

import com.optum.angularbootcampspring.entities.Snack;
import com.optum.angularbootcampspring.service.ObjectMapperService;
import com.optum.angularbootcampspring.service.SnackLoader;
import com.optum.angularbootcampspring.service.SnackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@EnableJpaRepositories
@EnableTransactionManagement
@SpringBootApplication
public class AngularBootcampSpringApplication implements CommandLineRunner {

    @Autowired
    ObjectMapperService objectMapperService;

    @Autowired
    SnackLoader snackLoader;


    @Autowired
    SnackService snackService;

    public static void main(String[] args) {
        SpringApplication.run(AngularBootcampSpringApplication.class, args);
    }

    @Transactional
    public void loadSnacks() {
        snackService.deleteAllSnacks();
        List<Snack> snacks = snackLoader.snacksForLoading();
        snacks.forEach(snack -> {
            snackService.saveSnack(snack);
        });
    }

    @Override
    public void run(String... args) throws Exception {
        snackLoader.logSnacks();
        loadSnacks();
    }
}
