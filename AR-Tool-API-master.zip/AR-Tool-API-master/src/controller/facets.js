var express = require('express');
var router = express.Router();
var db = require('../config/db.config.js')
const request = require('request');
var async = require('async');
//var debug = require('request-debug');
process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;

exports.insertClaims  = function(load_file_id, cb) {

    console.log("Getting file details and file data");
    //let quer = "select * from batch_file_input_detail b2 where b2.load_file_detail_id = " + file_detail_id;

    getLatestFileData(load_file_id, function (err, fileRecords) {

        async.eachSeries(fileRecords, function (fileData, callback) {
            async.waterfall([function(callbk){
                callbk(null,fileData.load_file_detail_id)
            },
                getMemberRecord,
                findClaims,
                function(memberRecord, claims, call){
                    async.eachSeries(claims,function(claim,callSeries){
                        async.waterfall([
                            function(cl){
                                cl(null,memberRecord,claim.clm_num);
                            },getClaimDetails,   
                            getClaimSearchDetails,
                            processClaimData,
                            insertClaimRecord
                        ],callSeries(null,"done"));
                    }, function(err,result){call(null,result)});
                }], function (err, res) {
                    callback(null, "done");
                });
        }, function (err, result) {
            cb(null, "done");
        });
        
    });


}

function getLatestFileData(load_file_id, callback) {
    let quer = "select * from batch_file_input_detail b2 where b2.load_file_id = ?";
   // let quer = "select * from batch_file_input_detail b2 where b2.load_file_id = 903";

    db.query(quer, load_file_id, function (err, fileData, fields) {
        if (err) {
            console.log("error getting file data ",err);
            throw err;
        } else {
            try {
                fileData = JSON.parse(JSON.stringify(fileData));
                callback(null, fileData);
            } catch (error) {
                console.log("error parsing ",error)
                callback("error");
            }
        }
    });

}

function getFileDetailRecord(file_detail_id, callback) {
    let quer = "select * from batch_file_input_detail b2 where b2.load_file_detail_id = " + file_detail_id;
    db.query(quer, function (err, fileData, fields) {
        if (err) {
            callback(err);
        } else {
            try {
                fileData = JSON.parse(JSON.stringify(fileData));
                callback(null, fileData);
            } catch (error) {
                console.log("error parsing ",error)
                callback("error");
            }
        }
    });
}

function getMemberRecord(file_detail_id, callback) {
    var sql = "SELECT b2.prov_tax_id AS tin,b2.subscriber_id,b2.from_date_of_service AS dos,b1.member_id,b2.load_file_id,b2.load_file_detail_id,b1.source_system,b1.load_file_detail_member_id FROM batch_file_detail_member b1 JOIN batch_file_input_detail b2 ON b1.load_file_detail_id = b2.load_file_detail_id WHERE b1.source_system='APF' and b2.load_file_detail_id=" + file_detail_id;
    db.query(sql, function (err, memRecord, fields) {
        if (err) {
            console.log("error getting member record ", err);
            throw err;
        } else {
            try {
                memRecord = JSON.parse(JSON.stringify(memRecord));
                if (memRecord && memRecord.length > 0) {
                    callback(null, memRecord);
                } else {
                    callback("no records");
                }
            } catch (error) {
                console.log("error parsing ",error)
                callback("error");
            }
           
        }
    });
}

function findClaims(memberRecords, callback) {
    if (memberRecords.length < 1) {
        callback("error");
    }
   
    if(memberRecords[0].member_id == undefined || memberRecords[0].member_id ==null || memberRecords[0].member_id.trim() == null){
        callback("No member id found");
    }

    let mem_split = memberRecords[0].member_id.split(/\s+/);
    let sub_id = undefined;
    let suffix = undefined;

    if(mem_split.length == 1){
        sub_id = memberRecords[0].member_id.substring(8,16);
        suffix = memberRecords[0].member_id.substring(17);
    }else if(mem_split.length == 2){
        sub_id = mem_split[1].substring(0, 9);
        suffix = mem_split[1].substring(9);
    }else{
        callback("unable to extract subscriber id from member id");
    }

    if(!sub_id || !suffix){
        callback("Null sub id and suffix");
    }
    
     
    //let suffix = "01";

    let url = process.env.FACETS_URL+"/claims/claimsearch?dos=" + memberRecords[0].dos + "&subscriberId=" + sub_id + "&suffix=" + suffix + "&provTin=" + memberRecords[0].tin;
    
    var claimId;
    
    var options = {
        //     url: 'http://localhost:5000/claims/claimsearch?dos=2017-05-10&subscriberId=111387636&suffix=1&provTin=112855934',
        url: url,
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'charset': 'utf-8',
            'Access-Control-Allow-Origin': '*',
            'token': 'anything'
        }
    };
    
    //debug(request);
    request(options, function (error, response, body) {
        
        try {
            
            body = JSON.parse(body);
        } catch (error) {
            console.log("error parsing ",error)
            
            body = undefined;
        }

        if (!body || body.length < 1) {
            console.log("No claim records found for given criteria ");
            callback("error");
            
        }else{
            console.log("Result from claimsearch  length ", body);
            callback(null, memberRecords,body);
        }
        
    });

}

function getClaimDetails(memberRecords, claimId, callback) {
    
    request.post({
        headers: {
            'content-type': 'application/json', 'Accept': 'application/json', 'charset': 'utf-8',
            'Access-Control-Allow-Origin': '*',
        },
        url: process.env.FACETS_URL+'/utils/login',
        body: { 'u': 'MS\\'+process.env.PDAT_USER, 'p': process.env.PDAT_PASSWORD },
        rejectUnauthorized: false,
        json: true
    }, function (error, response, body) {
        if (body != undefined) {
    var url = process.env.FACETS_URL+'/claims/details?id=' + claimId;
    options = {
        url: url,
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'charset': 'utf-8',
            'Access-Control-Allow-Origin': '*',
            'token': body.tk
        }
    };
    request(options, function (error, response, body) {
        if(error){
            callback(error);
            return;
        }
        try {
            var claimData = JSON.parse(body);
        claimData = claimData.line_details.filter((claim)=>claim.clm_nbr === claimId);
        callback(null,memberRecords, claimId, claimData);
        } catch (error) {
            console.log("error parsing ",error)
            callback("error");
        }

        
    });
}
});
}

function getClaimSearchDetails(memberRecords,claimId,claimData, callback) {
    request.post({
        headers: {
            'content-type': 'application/json', 'Accept': 'application/json', 'charset': 'utf-8',
            'Access-Control-Allow-Origin': '*',
        },
        url: process.env.FACETS_URL+'/utils/login',
        body: { 'u': 'MS\\'+process.env.PDAT_USER, 'p': process.env.PDAT_PASSWORD },
        rejectUnauthorized: false,
        json: true
    }, function (error, response, body) {
        if (body != undefined) {
            var url = process.env.FACETS_URL+'/claims/search?id=' + claimId;
        options = {
            url: url,
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'charset': 'utf-8',
                'Access-Control-Allow-Origin': '*',
                'token': body.tk
            }
        };

        request(options, function (error, response, body) {
            if(error){
                callback(error);
                return;
            }
            try {
                var claimSearchData = JSON.parse(body);
                claimSearchData = claimSearchData.filter((claim)=>claim.clm_num === claimId);
                callback(null,memberRecords, claimData, claimSearchData);
            } catch (error) {
                console.log("error parsing ",error)
            callback("error");
            }                       
        
           

           
        

    });
}
});
}

function processClaimData(memberRecords,claimData, claimSearchData, callback) {
    var claim_billed_amt = 0;
    var claim_copay_amt = 0;
    var claim_ded_amt = 0;
    var claim_coins_amt = 0;
    var claim_first_service_date = new Date(8640000000000000);
    var claim_last_service_date = new Date(-8640000000000000);
    var pos = [];
    var denial_cd = [];


    var claim_disallow_amt = 0;
    for (var j = 0; j < claimData.length; j++) {
        claim_billed_amt += claimData[j].bld_amt;
        claim_ded_amt += claimData[j].ded;
        claim_copay_amt += claimData[j].copay;
        claim_coins_amt += claimData[j].coins;
        claim_disallow_amt += claimData[j].disallwd_amt;
        if (claim_first_service_date >= new Date(claimData[j].frm_dt)) {
            claim_first_service_date = new Date(claimData[j].frm_dt);
        }
        if (claim_last_service_date <= new Date(claimData[j].to_dt)) {
            claim_last_service_date = new Date(claimData[j].to_dt);
        }
        if (!pos.includes(claimData[j].pos)) {
            pos.push(claimData[j].pos);
        }
        if (!denial_cd.includes(claimData[j].dnl_code)) {
            denial_cd.push(claimData[j].dnl_code);
        }
    }
    var dr = '';
    if (denial_cd && denial_cd.length > 0) {
        denial_cd.forEach(item => { dr = dr + item });
    }
    var post = {
        claim_id: claimData[0].clm_nbr,
        claim_billed_amt: claim_billed_amt,
        claim_ded_amt: claim_ded_amt,
        claim_copay_amt: claim_copay_amt,
        claim_coins_amt: claim_coins_amt,
        claim_first_service_date: claim_first_service_date,
        claim_last_service_date: claim_last_service_date,
        place_of_service: pos,
        claim_disallow_amt: claim_disallow_amt,
        denial_cd: dr,
        claim_process_date: claimSearchData[0].prcss_dt,
        claim_received_date: claimSearchData[0].rcvd_dt,
        check_num: claimSearchData[0].chk_num,
        claim_paid_amt: claimSearchData[0].pd_amt,
        prov_state: claimSearchData[0].rmt_adrss.state,
        load_file_id: memberRecords[0].load_file_id,
        load_file_detail_id: memberRecords[0].load_file_detail_id,
        claim_tin: memberRecords[0].tin,
        //load_file_detail_id: fileData[k].load_file_detail_id? fileData[k].load_file_detail_id : '',
        load_file_detail_member_id: memberRecords[0].load_file_detail_member_id

    };

    callback(null, post);
}

function insertClaimRecord(claimRecord, callback) {
    try{
    db.query('INSERT INTO  batch_file_detail_claim SET ?', claimRecord, function (error, results, fields) {
        if (error) {
            console.log("error inserting ",error)
            //throw error;
            callback(error);
            return;
        } else {
           

            callback(null, results)

        }
    });
}catch(error){
    console.log("error inserting ",error)
    callback("error");

}
}
