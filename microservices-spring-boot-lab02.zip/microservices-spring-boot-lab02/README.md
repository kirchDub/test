# FTE Novice Microservices Course
## Description
In this module, learners will develop a microservice with Spring Boot. As they create the service, they will learn about microservice architecture, principles of microservice design, RESTful API, and securing microservices.
## Learning Objectives
* Define microservices 
* The benefits of microservices 
* The Five principles of microservice design
* The Spring Framework for microservices
* REST principles, basics, components, and design principles
* Creating REST API with Spring Framework
* Spring Boot Security practices
## Duration: 4 Hours

## Lab 01 - Spring Initializr
 
