import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { Snack } from '../shared/snack.model';

@Component({
  selector: 'app-snack-detail',
  templateUrl: './snack-detail.component.html',
  styles: [
  ]
})
export class SnackDetailComponent implements OnChanges {

  @Input()
  title: string;

  @Input()
  snack: Snack;

  constructor() { }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.snack) {
      this.snack = changes.snack.currentValue;
    }
  }
}
