package com.optum.bootcamp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import com.optum.bootcamp.entity.SnackEntity;
import com.optum.bootcamp.model.Snack;
import com.optum.bootcamp.service.SnackService;
import com.optum.bootcamp.transformer.SnackTransformer;

@RestController
public class SnackController {
  @Autowired SnackService snackService;

  @GetMapping(value = "/v1/snacks/{snackId}", produces = MediaType.APPLICATION_JSON_VALUE)
  public Snack getSnackById(@PathVariable("snackId") Integer id) {

    return SnackTransformer.toSnack(snackService.getSnackById(id));
  }

  @GetMapping(value = "/v1/snacks", produces = MediaType.APPLICATION_JSON_VALUE)
  public List<Snack> getAllSnacks() {
    List<SnackEntity> snackEntities = snackService.getAllSnacks();

    return SnackTransformer.toSnack(snackEntities);
  }

  @PostMapping(
      value = "/v1/snacks",
      consumes = MediaType.APPLICATION_JSON_VALUE,
      produces = MediaType.APPLICATION_JSON_VALUE)
  public Snack createSnack(@RequestBody Snack snack) {

    SnackEntity snackToCreate = SnackTransformer.toSnackEntity(snack);
    SnackEntity createdSnack = snackService.createSnack(snackToCreate);

    return SnackTransformer.toSnack(createdSnack);
  }

  @PutMapping(
      value = "/v1/snacks",
      consumes = MediaType.APPLICATION_JSON_VALUE,
      produces = MediaType.APPLICATION_JSON_VALUE)
  public Snack updateSnack(@RequestBody Snack snackToUpdate) {
    SnackEntity snackEntityToUpdate = SnackTransformer.toSnackEntity(snackToUpdate);
    SnackEntity updatedSnackEntity = snackService.updateSnack(snackEntityToUpdate);

    return SnackTransformer.toSnack(updatedSnackEntity);
  }

  @DeleteMapping(value = "/v1/snacks/{snackId}", produces = MediaType.APPLICATION_JSON_VALUE)
  public Snack deleteSnackById(@PathVariable("snackId") Integer id) {
    SnackEntity snackEntity = snackService.deleteSnackById(id);

    return SnackTransformer.toSnack(snackEntity);
  }
}
