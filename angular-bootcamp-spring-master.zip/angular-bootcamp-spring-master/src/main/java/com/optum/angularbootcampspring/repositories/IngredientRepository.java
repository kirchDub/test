package com.optum.angularbootcampspring.repositories;

import com.optum.angularbootcampspring.entities.Ingredient;
import com.optum.angularbootcampspring.entities.Snack;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface IngredientRepository extends JpaRepository<Ingredient, Integer> {

    @Query("SELECT i FROM Ingredient i WHERE i.snack = :snack")
    List<Ingredient> findIngredientBySnack(@Param("snack") Snack snack);

}
