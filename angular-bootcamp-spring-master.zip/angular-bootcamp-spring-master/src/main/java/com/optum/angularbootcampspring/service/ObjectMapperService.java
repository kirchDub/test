package com.optum.angularbootcampspring.service;

import com.optum.angularbootcampspring.domain.SnackDto;
import com.optum.angularbootcampspring.entities.Snack;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import static java.util.stream.Collectors.toList;

@Service
public class ObjectMapperService {

    private ModelMapper modelMapper;

    @Autowired
    ObjectMapperService(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public SnackDto toSnackDto(Snack snack) {

        return modelMapper.map(snack, SnackDto.class);
    }

    public Snack toSnackEntity(SnackDto snackDto) {
        return modelMapper.map(snackDto, Snack.class);
    }

    public List<SnackDto> toSnackDtos(List<Snack> snacks) {
       return snacks.stream().map( snack -> toSnackDto(snack)).collect(toList());
    }
}
