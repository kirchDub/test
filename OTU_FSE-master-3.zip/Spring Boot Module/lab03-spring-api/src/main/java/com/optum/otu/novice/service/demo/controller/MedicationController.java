package com.optum.otu.novice.service.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.optum.otu.novice.service.demo.model.MedicationResponse;
import com.optum.otu.novice.service.demo.service.MedicationService;

@RestController
@RequestMapping("/demo/medication")
public class MedicationController {

    @Autowired
    MedicationService medicationService;

    @PostMapping(path = "find")
    public @ResponseBody
    MedicationResponse findByType(String typeName) {
        return medicationService.findByName(typeName);
    }

}
