import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-snacks-container',
  templateUrl: './snacks-container.component.html',
  styles: [
  ]
})
export class SnacksContainerComponent implements OnInit {

  snacksTableTitle = 'Snacks Table View';
  snacksTreeTitle = 'Snacks Tree View';
  snackDetailTitle = 'Snack Detail';

  constructor() {}

  ngOnInit(): void {}

  onSwitchTab(event: any): void {}
}
