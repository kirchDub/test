import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UITKFooterModule, UITKNavigationModule } from '@uitk/angular';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    UITKNavigationModule,
    UITKFooterModule,
  ]
})
export class CoreModule { }
