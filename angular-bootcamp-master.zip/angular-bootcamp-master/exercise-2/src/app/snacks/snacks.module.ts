import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UITKTabbedPanelsModule, UITKTableModule, UITKTreeModule } from '@uitk/angular';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    UITKTabbedPanelsModule,
    UITKTableModule,
    UITKTreeModule,
  ]
})
export class SnacksModule { }
