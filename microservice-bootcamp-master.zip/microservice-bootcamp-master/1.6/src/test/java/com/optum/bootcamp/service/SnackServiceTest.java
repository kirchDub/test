package com.optum.bootcamp.service;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.optum.bootcamp.model.Snack;

@SpringBootTest
public class SnackServiceTest {

  @Autowired private SnackService snackService;

  @Test
  public void getSnackByIdTest() {
    Integer id = 1;
    Snack snack = snackService.getSnackById(id);

    assertThat(snack.getId()).isEqualTo(id);
    assertThat(snack.getName()).isEqualTo("Butterfingers");
  }
}
