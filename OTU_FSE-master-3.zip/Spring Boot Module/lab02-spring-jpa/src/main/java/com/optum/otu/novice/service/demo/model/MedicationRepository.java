package com.optum.otu.novice.service.demo.model;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;


public interface MedicationRepository extends JpaRepository<Medication, Long> {
    Medication findByName(String name);

    Collection<Medication> findByDrugType(MedicationType type);
}


