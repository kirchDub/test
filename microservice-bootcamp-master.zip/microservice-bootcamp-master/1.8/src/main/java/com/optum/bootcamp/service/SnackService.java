package com.optum.bootcamp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.optum.bootcamp.entity.SnackEntity;
import com.optum.bootcamp.repository.SnackRepository;

@Service
public class SnackService {

  @Autowired SnackRepository snackRepository;

  public SnackEntity getSnackById(Integer id) {
    Optional<SnackEntity> mySnack = snackRepository.findById(id);

    return mySnack.orElseThrow();
  }

  public List<SnackEntity> getAllSnacks() {
    return snackRepository.findAll();
  }

  public SnackEntity createSnack(SnackEntity snackToCreate) {

    return snackRepository.save(snackToCreate);
  }

  public SnackEntity updateSnack(SnackEntity snackEntityToUpdate) {
    SnackEntity currentSnackEntity = getSnackById(snackEntityToUpdate.getId());

    currentSnackEntity.setName(snackEntityToUpdate.getName());

    return snackRepository.save(currentSnackEntity);
  }

  public SnackEntity deleteSnackById(Integer id) {
    SnackEntity snackEntityToBeDeleted = getSnackById(id);

    snackRepository.deleteById(id);

    return snackEntityToBeDeleted;
  }
}
