package com.optum.bootcamp.transformer;

import com.optum.bootcamp.entity.SnackEntity;
import com.optum.bootcamp.model.Snack;

public class SnackTransformer {

  public static Snack toSnack(SnackEntity fromSnack) {
    Snack snack = new Snack();
    snack.setId(fromSnack.getId());
    snack.setName(fromSnack.getName());

    return snack;
  }

  public static SnackEntity toSnackEntity(Snack fromSnack) {
    SnackEntity snackEntity = new SnackEntity();
    snackEntity.setId(fromSnack.getId());
    snackEntity.setName(fromSnack.getName());

    return snackEntity;
  }
}
