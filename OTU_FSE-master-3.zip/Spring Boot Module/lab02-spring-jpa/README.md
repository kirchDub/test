# FTE Novice Microservices Course
## Lab 02 - Spring JPA
 
