package com.optum.bootcamp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import com.optum.bootcamp.entity.SnackEntity;
import com.optum.bootcamp.model.Snack;
import com.optum.bootcamp.service.SnackService;
import com.optum.bootcamp.transformer.SnackTransformer;

@RestController
public class SnackController {
  @Autowired SnackService snackService;

  @GetMapping(value = "/v1/snacks/{snackId}", produces = MediaType.APPLICATION_JSON_VALUE)
  public Snack getSnackById(@PathVariable("snackId") Integer id) {

    return SnackTransformer.toSnack(snackService.getSnackById(id));
  }

  @PostMapping(
      value = "/v1/snacks",
      consumes = MediaType.APPLICATION_JSON_VALUE,
      produces = MediaType.APPLICATION_JSON_VALUE)
  public Snack createSnack(@RequestBody Snack snack) {

    SnackEntity snackToCreate = SnackTransformer.toSnackEntity(snack);
    SnackEntity createdSnack = snackService.createSnack(snackToCreate);

    return SnackTransformer.toSnack(createdSnack);
  }
}
