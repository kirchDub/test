package com.optum.bootcamp.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.optum.bootcamp.entity.SnackEntity;
import com.optum.bootcamp.repository.SnackRepository;

@Service
public class SnackService {
  @Autowired SnackRepository snackRepository;

  public SnackEntity getSnackById(Integer id) {
    Optional<SnackEntity> mySnack = snackRepository.findById(id);

    return mySnack.orElseThrow();
  }

  public SnackEntity createSnack(SnackEntity snackToCreate) {

    return snackRepository.save(snackToCreate);
  }
}
