package com.optum;

public class Prescription {
  private String drugName;
  private double cost;
}
