import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { shareReplay } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Snack } from './snack.model';

const GET_ALL_SNACKS_URL = `${environment.apiBaseUrl}/snacks`;

@Injectable({
  providedIn: 'root'
})
export class SnackService {
  private allSnacksCache$: Observable<Snack[]>;
  constructor(private httpClient: HttpClient) {}

  get allSnacks(): Observable<Snack[]> {
    if (!this.allSnacksCache$) {
      this.allSnacksCache$ = this.getAllSnacks().pipe(
        shareReplay(1)
      );
    }
    return this.allSnacksCache$;
  }

  private getAllSnacks(): Observable<Snack[]> {
    return this.httpClient.get<Snack[]>(GET_ALL_SNACKS_URL);
  }
}
