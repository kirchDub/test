import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UITKTabbedPanelsModule, UITKTableModule, UITKTreeModule } from '@uitk/angular';
import { SnacksContainerComponent } from './snacks-container/snacks-container.component';
import { SnacksTableComponent } from './snacks-table/snacks-table.component';
import { SnacksTreeComponent } from './snacks-tree/snacks-tree.component';
import { SnackDetailComponent } from './snack-detail/snack-detail.component';



@NgModule({
  declarations: [SnacksContainerComponent, SnacksTableComponent, SnacksTreeComponent, SnackDetailComponent],
  imports: [
    CommonModule,
    UITKTabbedPanelsModule,
    UITKTableModule,
    UITKTreeModule,
  ],
  exports: [SnacksContainerComponent],
})
export class SnacksModule { }
