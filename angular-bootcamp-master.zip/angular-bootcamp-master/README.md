# Angular Bootcamp Examples

Each example included in this repository illustrates what your code should look like at the end of that step of the 
[angular bootcamp](https://gp-docs.optum.com/docs/bootcamp/angular/prerequisites). 

## Note to instructors

The API used by this UI exists at [gp-sandbox/snacks](https://github.optum.com/gp-sandbox/snacks). Click [here](http://snacks-nonprod-route-gtm-snacks-nonprod.origin-ctc-core-nonprod.optum.com/api/actuator/health) to check if there is a live deployment. If there is no live deployment, [create an OpenShift project](https://tech.optum.com/products/openshift/create-osfi-origin-project) using the config in [pipeline.yml](https://github.optum.com/gp-sandbox/snacks/blob/master/pipeline.yml), then [trigger a deployment](https://jenkins-gp-sandbox.origin-elr-core-nonprod.optum.com/job/gp-sandbox/job/snacks/view/tags/). 

Once the deployment is live, make sure the snack database is set up properly by hitting the `generate-snacks` endpoint once:  

```bash
curl -X POST -H 'Content-Type: application/json' http://snacks-nonprod-route-gtm-snacks-nonprod.origin-ctc-core-nonprod.optum.com/api/v1/generate-snacks
```
