var Teradata = require('node-teradata');

var config = {
  url: process.env.TERRADATA_URL,
  username: process.env.TERRADATA_UNAME,
  password: process.env.TERRADATA_PWD,
  driver: './jars/',
  minPoolSize: 1,
  maxPoolSize: 100,
};

var teradata = new Teradata(config);

// var sql = "CREATE volatile TABLE AR_TOOL ( excel_row_id integer, sub_id varchar(100), fst_nm varchar(100), lst_nm varchar(100), dob date, dos date, src_sys_id varchar(100), mbr_pty_id varchar(100), cpin varchar(100), src_sbscr_id varchar(100), src_cust_contr_id varchar(100), src_mbr_id varchar(100), match_step varchar(100) ) PRIMARY INDEX(sub_id) ON COMMIT preserve rows;";
// teradata.write(sql)
//     .then(function (result) {
//     });

module.exports = teradata;