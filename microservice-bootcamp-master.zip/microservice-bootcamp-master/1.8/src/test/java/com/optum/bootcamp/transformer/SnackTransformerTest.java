package com.optum.bootcamp.transformer;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.optum.bootcamp.entity.SnackEntity;
import com.optum.bootcamp.model.Snack;

public class SnackTransformerTest {

  @Test
  public void toSnackTest() {
    Integer id = 1;
    String name = "Veggie Straws";
    SnackEntity snackEntity = new SnackEntity(id, name);

    Snack snack = SnackTransformer.toSnack(snackEntity);

    assertThat(snack.getId()).isEqualTo(id);
    assertThat(snack.getName()).isEqualTo(name);
  }

  @Test
  public void toSnackEntityTest() {
    Integer id = 1;
    String name = "Veggie Straws";
    Snack snack = new Snack(id, name);

    SnackEntity snackEntity = SnackTransformer.toSnackEntity(snack);

    assertThat(snackEntity.getId()).isEqualTo(id);
    assertThat(snackEntity.getName()).isEqualTo(name);
  }

  @Test
  public void toSnackListTest() {
    Integer id1 = 1;
    String name1 = "Veggie Straws";
    SnackEntity snackEntity1 = new SnackEntity(id1, name1);

    Integer id2 = 2;
    String name2 = "Apple Straws";
    SnackEntity snackEntity2 = new SnackEntity(id2, name2);

    List<SnackEntity> snackEntitiesList = new ArrayList<>();
    snackEntitiesList.add(snackEntity1);
    snackEntitiesList.add(snackEntity2);

    List<Snack> snacks = SnackTransformer.toSnack(snackEntitiesList);

    assertThat(snacks.size()).isEqualTo(2);

    Snack snack1 = snacks.get(0);
    Snack snack2 = snacks.get(1);

    assertThat(snack1.getId()).isEqualTo(id1);
    assertThat(snack1.getName()).isEqualTo(name1);

    assertThat(snack2.getId()).isEqualTo(id2);
    assertThat(snack2.getName()).isEqualTo(name2);
  }
}
