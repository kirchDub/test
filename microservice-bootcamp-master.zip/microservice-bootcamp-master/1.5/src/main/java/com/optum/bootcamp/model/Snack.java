package com.optum.bootcamp.model;

public class Snack {
  private Integer id;

  private String name;

  public Snack() {}

  public Snack(Integer id, String name) {
    this.id = id;
    this.name = name;
  }

  public Integer getId() {
    return id;
  }

  public String getName() {
    return name;
  }
}
