package com.optum.angularbootcampspring.entities;

import com.optum.angularbootcampspring.domain.SnackTypes;
import lombok.Data;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;

@Data
@ToString
@Slf4j
@Entity
public class Snack implements Serializable {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int id;

    @NotBlank
    @Column(unique = true, updatable = false)
    private String name;

    @NotBlank
    private String review;

    @Enumerated(EnumType.STRING)
    @Column(length = 13, columnDefinition = "varchar(13) default 'Uncategorized'",  updatable = false)
    private SnackTypes type = SnackTypes.Uncategorized;


    private int rating;

    @Embedded
    private NutritionFacts nutritionFacts;

    @ToString.Exclude
    @OneToMany(mappedBy = "snack",cascade = CascadeType.ALL)
    private List<Ingredient> ingredients;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Snack snack = (Snack) o;
        return name.equals(snack.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
}
