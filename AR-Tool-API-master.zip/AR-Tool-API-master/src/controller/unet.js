const ohttp = require('../http');
//const x2j = require('xml2js');
const oSoapWSHeader = require('../commonHttpLib');
var teradata = require('../config/teradata.config.js');
var db = require('../config/db.config.js');
var async = require('async');
var convert = require('xml-js');



exports.insertUnetClaims = function (load_file_id, cb) {
    console.log("Getting file details and file data");
    //let quer = "select * from batch_file_input_detail b2 where b2.load_file_detail_id = " + file_detail_id;

    getLatestFileData(load_file_id, function (err, fileRecords) {
        //getClaims(load_file_id);
        async.eachSeries(fileRecords, function (fileData, callback) {
            async.waterfall([function (callbk) {
                callbk(null, fileData.load_file_detail_id)
            },
                getMemberRecord,
                getClaimId,
            function (memRecord, unetClaims, call) {
                async.eachSeries(unetClaims, function (claim, callk) {
                    async.waterfall([
                        function (call) { call(null, memRecord, claim) },
                        buildRequest,
                        invokeUPMSecuritySvc,
                        getUpmSecurityToken,
                        invokeUPMV6Svc,
                        processClaimData,
                        insertClaimRecord
                    ], function (err, result) {
                        callk(null, "done");
                    });
                },
                    function (err, res) {
                        call(null, "done");
                    });
            }], function (err, res) { callback(null, "Done"); });


        }, function (err, result) {
            cb(null, "done");
        });

    });

}


function getLatestFileData(load_file_id, callback) {
    let quer = "select * from batch_file_input_detail b2 where b2.load_file_id = ?";
    // let quer = "select * from batch_file_input_detail b2 where b2.load_file_id = 903";

    db.query(quer, load_file_id, function (err, fileData, fields) {
        if (err) {
            throw err;
        } else {
            fileData = JSON.parse(JSON.stringify(fileData));
            callback(null, fileData);
        }
    });

}


function getMemberRecord(file_detail_id, callback) {
    var sql = "SELECT b2.prov_tax_id AS tin,b2.subscriber_id,b2.from_date_of_service AS dos,b1.member_id,b1.mbr_pty_id,b1.subscriber_id AS employer_id,b2.load_file_id,b2.load_file_detail_id,b1.source_system,b1.load_file_detail_member_id, b1.group_policy_number FROM batch_file_detail_member b1 JOIN batch_file_input_detail b2 ON b1.load_file_detail_id = b2.load_file_detail_id WHERE b1.source_system='CES' and b2.load_file_detail_id=" + file_detail_id;
    console.log("query", sql);
    db.query(sql, function (err, memRecord, fields) {
        if (err) {
            console.log("error getting member record ", err);
            throw err;
        } else {
            memRecord = JSON.parse(JSON.stringify(memRecord));
            if (memRecord && memRecord.length > 0) {
                console.log("member record", memRecord);
                callback(null, file_detail_id, memRecord[0]);
            } else {
                callback("no records");
            }
        }
    });
}

function getClaimId(file_detail_id, memRecord, callback) {
    var sql = "SELECT * from batch_file_unet_ids WHERE load_file_detail_id=" + file_detail_id;
    db.query(sql, function (err, results, fields) {
        if (err) {
            console.log("error getting unet record ", err);
            throw err;
        } else {
            var unetClaims = JSON.parse(JSON.stringify(results));
            if (unetClaims.length > 0) {
                
                callback(null, memRecord,unetClaims);
            } else {
                callback("no records");
            }
        }
    });
    


}

function buildRequest(memRecord, claim, callback) {
    var req = {};
    console.log("policy number", memRecord.group_policy_number);
    req.policyNumber = memRecord.group_policy_number.substring(1,7);//clm.PD_POL_NUM;// from the member table 
    console.log("policy number", req.policyNumber);
    
    req.icn = claim.tops_icn;
    console.log("icn", req.icn);
    req.icnSuffix = claim.tops_suffix;

    // generate employeeid from src_subscriber_id
    req.employeeId = "S" + memRecord.employer_id.substring(2, 11);
    console.log("employee id", req.employeeId);
    req.system = "";

    callback(null,memRecord, req);
}

function invokeUPMSecuritySvc(memRecord, request, callback) {
   

    var oSOAPEnvelop = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:v7="http://upm3.uhc.com/security/readuserprofileandtokens/v7">
    <soapenv:Header>
                    <wsse:Security soapenv:mustUnderstand="1" xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
                                    <wsse:UsernameToken wsu:Id="UsernameToken-PDAT">
                                                    <wsse:Username>pdat_upm_prd</wsse:Username>
                                                    <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">AEQH92Nu</wsse:Password>
                                                    <wsse:Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">WScqanjCEAC4mQoBE07sAQ==</wsse:Nonce>
                                                    <wsu:Created>2018-12-17T21:59:36.889Z</wsu:Created>
                                    </wsse:UsernameToken>
                    </wsse:Security>
    </soapenv:Header>
    <soapenv:Body>
                    <v7:invokeService>
                                    <arg0>
                                                    <requestHeader>
                                                                    <applicationName>PDAT</applicationName>
                                                                    <applicationInstanceName>PDAT</applicationInstanceName>
                                                                    <logLevel>0</logLevel>
                                                    </requestHeader>
                                                    <controlModifiers>
                                                                    <getTopsToken>true</getTopsToken>
                                                                    <topsSystemParameters>
                                                                                    <userId>999130473</userId>
                                                                                    <userPassword>99913@bc</userPassword>
                                                                    </topsSystemParameters>
                                                    </controlModifiers>
                                    </arg0>
                    </v7:invokeService>
    </soapenv:Body>
</soapenv:Envelope>
`;



    ohttp.postMessage(process.env.UNET_URL, "/upm3/security/ReadUserProfileAndTokensV7", null, oSOAPEnvelop, false, false,
        function (data) {
            if(data === null || data === undefined ||(data && data.err)){
                callback("token not found");
            }else{
                callback(null, memRecord, request, data);
            }
        }
    );
}

function getUpmSecurityToken(memRecord, req, data, callback) {
    if (data.err == null) {
        try{
            var result = JSON.parse(convert.xml2json(data.result, { compact: true, spaces: 4 }));
            var oResult = result["soap:Envelope"]["soap:Body"]["ns1:invokeServiceResponse"]["return"];
            if (oResult != undefined) {
                if (oResult["responseHeader"]["serviceCallStatus"]["_text"] === "SUCCESS") {
                    callback(null, memRecord, req, oResult["userTokens"]["userToken"]["_text"]);
                }
                else {
                    callback(oResult["responseHeader"]["statusMessages"]);
                }
            } else {
                callback("error in getting token");
            }
        }catch(error)
        {
            callback("error " +error);
        }
    }
    else {
        callback("error");
    }
};

function invokeUPMV6Svc(memberRecord, request, token, callback) {
    if (token != null) {
        var oRequest = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:v6="http://upm3.uhc.com/unetclaim/readunetclaimdetailbyicn/v6">
            <soapenv:Header>
            <wsse:Security soapenv:mustUnderstand="1" xmlns:wsse="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd">
                 <wsse:UsernameToken wsu:Id="UsernameToken-PDAT">
                    <wsse:Username>pdat_upm_prd</wsse:Username>
                    <wsse:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText">AEQH92Nu</wsse:Password>
                    <wsse:Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary">d6zrRrsSdfulAUmTq6VAtQ==</wsse:Nonce>
                    <wsu:Created>2018-10-26T11:30:00.006Z</wsu:Created>
                 </wsse:UsernameToken>
              </wsse:Security>
           </soapenv:Header>
           <soapenv:Body>
           <v6:invokeService>
                 <arg0>
            <requestHeader>
            <applicationName>PDAT</applicationName>
            <applicationInstanceName>PDAT</applicationInstanceName>
            <logLevel>0</logLevel>
            </requestHeader>
            <readUnetClaimDetailByIcnControlModifiers>
            <topsSystemParameters>
            <securityToken>`+token+`</securityToken>
            </topsSystemParameters>
            </readUnetClaimDetailByIcnControlModifiers>
                                       <employeeId>`+ request.employeeId+`</employeeId>
                                        <policyNumber>`+ request.policyNumber+`</policyNumber>
                                        <icn>`+request.icn+`</icn>
                                        <icnSuffix>`+request.icnSuffix+`</icnSuffix>
            
            <system></system>
               </arg0>
            </v6:invokeService>
           </soapenv:Body>
        </soapenv:Envelope>`
            ;

        //var oSOAPEnvelop = oSoapWSHeader.getSOAPEnvelopRequest("v6", "http://upm3.uhc.com/unetclaim/readunetclaimdetailbyicn/v6", oRequest);

        ohttp.postMessage(process.env.UNET_URL, "/upm3/unetclaim/ReadUnetClaimDetailByIcnV6", null, oRequest, false, false,
            function (data) {
                if((data && data.err) || data === null || data === undefined){
                    callback("token not found");
                }else{
                    console.log("got claims details ");
                    callback(null, memberRecord, request, data);
                }
                
            });
    }
    else {
        callback("token not found");
    }

};



function processClaimData(memRecord, request, claimData, callback) {

    var result = JSON.parse(convert.xml2json(claimData.result, { compact: true, spaces: 4 }));
    console.log("result", result);

    var oResult = idx(["soap:Envelope","soap:Body","ns1:invokeServiceResponse","return"], result);
    //var oResult = result["soap:Envelope"]["soap:Body"]["ns1:invokeServiceResponse"]["return"];
    if(oResult == null){
        console.log("unable to get claim data");
        callback("error getting claim data");
        return;
    }
    if (oResult
        && oResult["responseHeader"]
        && oResult["responseHeader"]["serviceCallStatus"]
        && oResult["responseHeader"]["serviceCallStatus"]["_text"]
        && oResult["responseHeader"]["serviceCallStatus"]["_text"] === "SUCCESS") {
        //var check_num = resp.checks.FirstOrDefault()?.checkNumber;
        var patient_last_name = oResult["lastName"]["_text"];
        var patient_first_name = oResult["firstName"]["_text"];
        var claim_last_service_date = oResult["lastServiceDate"]["_text"];
        var claim_first_service_date = oResult["firstServiceDate"]["_text"];
        var par_status = oResult["providerType"]["_text"];
        var account_num = oResult["patientAccountNumber"]["_text"];
        var provider_mpin = oResult["providerMpin"]["_text"];
        var provider_name = oResult["providerName"]["_text"];
        var prov_sate = oResult["providerState"]["_text"];
        var claim_provider_tin = oResult["providerTin"]["_text"];
        //var ors = resp.ors
        var tops_relationship_cd = oResult["relationshipCode"]["_text"];
        var claim_allow_amt = oResult["totalAllowedAmount"]["_text"];
        var claim_billed_amt = oResult["totalChargeAmount"]["_text"];
        var claim_copay_amt = oResult["totalCopayAmount"]["_text"];
        var claim_ded_amt = oResult["totalDeductibleAmount"]["_text"];
        var claim_disallow_amt = oResult["totalNotCoveredAmount"]["_text"];
        var claim_paid_amt = oResult["totalPaidAmount"]["_text"];
        var claim_pat_resp_amt = oResult["totalPatientResponsibilityAmount"]["_text"];
        var abc = oResult["totalWriteOffAmount"]["_text"];
        var funding = oResult["fundingResponsibility"]["_text"];
        var capitation = oResult["capitationFundingIndicator"]["_text"];
        var TOPS_ENGINE = oResult["system"]["_text"];
        var drg = oResult["drgCode"]["_text"];
        if (Array.isArray(oResult["checks"]))
        {
            var checkNum = oResult["checks"][0]["draftNumber"]["_text"];    
        }
        else{
            var checkNum = "";    
        }
        

        var tin = oResult["providerTin"]["_text"];
        var claim_type = oResult["claimType"]["_text"];
        var filmOffice = oResult["filmOffice"]["_text"];

        //var claim_id = memberRecords[0].TOPS_ICN;

        var claim_id = request.icn;
        var remarkCodeSet = new Set();
        var claim_process_date;
        var original_claim_process_date;
        var place_of_service;

        var detail_billed = Number(0.00);
        var detail_notCovered = Number(0.00);
        var detail_paid = Number(0.00);
        var patResp = Number(0.00);
        patResp = Number(oResult["totalAllowedAmount"]["_text"]) -  Number(oResult["totalPaidAmount"]["_text"]) + Number(oResult["totalCopayAmount"]["_text"]);

        if(Array.isArray(oResult["claimDetailLineItems"])){
            oResult["claimDetailLineItems"].forEach((claimLine) => {
                remarkCodeSet.add(claimLine["remarkCode"]["_text"]);
                if (claimLine["remarkCode"]["_text"] != "70")
                    {
                        detail_paid += Number(claimLine["basePaidAmount"]["_text"]);
                    }
                    if (claimLine["remarkCode"]["_text"] != "70" && claimLine["serviceCode"]["_text"] != "CXINT" && claimLine["serviceCode"]["_text"] != "OI")
                    {
                        detail_billed += Number(claimLine["chargeAmount"]["_text"]);
                        detail_notCovered += Number(claimLine["notCoveredAmount"]["_text"]);
                        console.log('detail_billed added ', claimLine["chargeAmount"]["_text"], '' , detail_billed);
                        console.log('detail_notCovered added ', claimLine["notCoveredAmount"]["_text"], '' , detail_notCovered);
                    }
            });
             claim_process_date = oResult["claimDetailLineItems"][0]["processedDate"]["_text"];
             original_claim_process_date = oResult["claimDetailLineItems"][0]["originalProcessedDate"]["_text"];
             place_of_service = oResult["claimDetailLineItems"][0]["placeOfService"]["_text"];
             
            
             
        }else{

            detail_paid += Number(oResult["claimDetailLineItems"]["basePaidAmount"]["_text"]);
            detail_billed += Number(oResult["claimDetailLineItems"]["chargeAmount"]["_text"]);
            detail_notCovered += Number(oResult["claimDetailLineItems"]["notCoveredAmount"]["_text"]);

            claim_process_date = oResult["claimDetailLineItems"]["processedDate"]["_text"];
            original_claim_process_date = oResult["claimDetailLineItems"]["originalProcessedDate"]["_text"];
            place_of_service = oResult["claimDetailLineItems"]["placeOfService"]["_text"];
            remarkCodeSet.add(oResult["claimDetailLineItems"]["remarkCode"]["_text"]);

        }
        var remark_cd = Array.from(remarkCodeSet).join(',');

        


        var post = {        
            claim_id: claim_id,
            claim_billed_amt: detail_billed,
            claim_ded_amt: claim_ded_amt,
            claim_copay_amt: claim_copay_amt,
            //  claim_coins_amt: claim_coins_amt,
            claim_first_service_date: claim_first_service_date,
            claim_last_service_date: claim_last_service_date,
            place_of_service: place_of_service,
            claim_tin: tin,
            claim_type: claim_type,
            claim_disallow_amt: detail_notCovered,
            //       denial_cd: dr,
            claim_process_date: claim_process_date,
            // claim_received_date: claimSearchData[0].rcvd_dt,
            check_num: checkNum,
            //claim_paid_amt: detail_paid,
            claim_paid_amt: claim_paid_amt, 
            prov_state: prov_sate,

            load_file_id: memRecord.load_file_id,
            load_file_detail_id: memRecord.load_file_detail_id,
            // load_file_detail_id: memberRecords[0].load_file_detail_id,
            // //load_file_detail_id: fileData[k].load_file_detail_id? fileData[k].load_file_detail_id : '',
            // load_file_detail_member_id: memberRecords[0].load_file_detail_member_id,
            load_file_detail_member_id: memRecord.load_file_detail_member_id,
            tops_relationship_cd: tops_relationship_cd,
            provider_grp_name: provider_name,
            drg_code: drg,

            par_status: par_status,
            account_num: account_num,
            provider_mpin: provider_mpin,
        
            claim_pat_resp_amt: patResp,
            financial_arrangement: funding,
            original_claim_process_date: original_claim_process_date,
            unet_engine: TOPS_ENGINE,
            unet_payloc: filmOffice,
            remark_cd: remark_cd
        };

        callback(null, post);

    } else {
        callback("error at getting claim data");
    }



}

function insertClaimRecord(claimRecord, callback) {
    db.query('INSERT INTO  batch_file_detail_claim SET ?', claimRecord, function (error, results, fields) {
        if (error) {

            throw error;
            callback(error);
            return;
        } else {
            console.log('Claim details inserted ', claimRecord);

            callback(null, results)

        }
    });
}


const idx = (props, object) => props.reduce((prefix, val) => (prefix && prefix[val]) ? prefix[val] : null, object);