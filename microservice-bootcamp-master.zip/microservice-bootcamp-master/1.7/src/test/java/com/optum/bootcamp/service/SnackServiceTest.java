package com.optum.bootcamp.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.NoSuchElementException;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.optum.bootcamp.entity.SnackEntity;
import com.optum.bootcamp.repository.SnackRepository;

@SpringBootTest
public class SnackServiceTest {

  @Autowired private SnackService snackService;
  @MockBean private SnackRepository snackRepository;

  @Test
  public void getSnackByIdTest() {
    Integer id = 1;
    String name = "Milk Chocolate";
    SnackEntity snackEntityToReturn = new SnackEntity(id, name);

    Mockito.when(snackRepository.findById(id)).thenReturn(Optional.of(snackEntityToReturn));

    SnackEntity snackEntity = snackService.getSnackById(id);

    assertThat(snackEntity.getId()).isEqualTo(id);
    assertThat(snackEntity.getName()).isEqualTo(name);
  }

  @Test
  public void getSnackByIdNotFoundTest() {
    Integer id = 1;

    Mockito.when(snackRepository.findById(id)).thenReturn(Optional.empty());

    assertThatThrownBy(() -> snackService.getSnackById(id))
        .isExactlyInstanceOf(NoSuchElementException.class);
  }

  @Test
  public void createSnackTest() {
    Integer id = 1;
    String name = "Dark Chocolate";

    SnackEntity snackEntityToCreate = new SnackEntity();
    snackEntityToCreate.setName(name);

    SnackEntity snackEntityToReturn = new SnackEntity(id, name);

    Mockito.when(snackRepository.save(snackEntityToCreate)).thenReturn(snackEntityToReturn);

    SnackEntity snackEntity = snackService.createSnack(snackEntityToCreate);

    assertThat(snackEntity.getId()).isEqualTo(id);
    assertThat(snackEntity.getName()).isEqualTo(name);
  }
}
