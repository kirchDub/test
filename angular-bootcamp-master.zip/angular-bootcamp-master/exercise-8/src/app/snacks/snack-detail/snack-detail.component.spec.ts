import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { Snack, SnackType } from '../shared/snack.model';

import { SnackDetailComponent } from './snack-detail.component';

const snack: Snack = {
  id: 1,
  name: 'Hummus',
  description: 'A dip, spread, or savory dish made from cooked, mashed chickpeas',
  snackType: SnackType.Umami,
  calories: 177,
  fat: 8.59,
  protein: 4.8,
  carbohydrates: 20.1,
}

const newSnack: Snack = {
  id: 2,
  name: 'Broccoli',
  description: 'An edible green plant in the cabbage family',
  snackType: SnackType.Bitter,
  calories: 34,
  fat: 0.0,
  protein: 4.7,
  carbohydrates: 80.4,
};

describe('SnackDetailComponent', () => {
  let component: SnackDetailComponent;
  let fixture: ComponentFixture<SnackDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SnackDetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SnackDetailComponent);
    component = fixture.componentInstance;
    // Set initial snack
    component.snack = snack;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display new snack when input changes', () => {
    const snackName: DebugElement = fixture.debugElement.query(By.css('h3'));
    
    expect(snackName.nativeElement.textContent).toEqual(snack.name);

    component.snack = newSnack;

    fixture.detectChanges();

    expect(snackName.nativeElement.textContent).toEqual(newSnack.name);
  });
});
