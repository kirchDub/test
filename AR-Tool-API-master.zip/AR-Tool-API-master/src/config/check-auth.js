const jwt = require('jsonwebtoken');


module.exports = (req, res, next) => {
    try{
        const token = req.headers.authorization;
        
        if (token != undefined && token.indexOf("Bearer") == 0)
        {
            const decoded = jwt.verify(token.split(" ")[1], process.env.JWT_KEY);

            req.userAuthInfo = decoded;
            
            next();
        }
        else
        {
            return res.status(401).json({
                message : "Invalid Token Format. Valid Format 'Bearer {Token}'"
            });    
        }
    }
    catch(error)
    {
        return res.status(401).json({
            message : "Authorization Failed."
        });
    }
};



