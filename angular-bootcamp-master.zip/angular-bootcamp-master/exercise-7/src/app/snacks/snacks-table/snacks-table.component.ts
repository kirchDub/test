import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Snack } from '../shared/snack.model';

@Component({
  selector: 'app-snacks-table',
  templateUrl: './snacks-table.component.html',
  styles: [
  ]
})
export class SnacksTableComponent implements OnInit {

  @Input()
  title: string;

  @Input()
  data: Snack[];

  @Output()
  selectedSnack = new EventEmitter<Snack>();

  selected: Snack;

  headers = ['Name', 'Description', 'Calories / 100g'];

  constructor() { }

  ngOnInit(): void {
  }

  onSnackSelect(snack: Snack) {
    this.selected = snack;
    this.selectedSnack.emit(snack);
  }
}
