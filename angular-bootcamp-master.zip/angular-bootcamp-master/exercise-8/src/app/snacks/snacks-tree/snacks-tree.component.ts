import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { IUITKTreeData, IUITKChildNode } from '@uitk/angular';
import { Snack, SnackType } from '../shared/snack.model';

@Component({
  selector: 'app-snacks-tree',
  templateUrl: './snacks-tree.component.html',
  styles: [
  ]
})
export class SnacksTreeComponent implements OnChanges {

  @Input()
  title: string;

  @Input()
  data: Snack[];

  @Output()
  selectedSnack = new EventEmitter<Snack>();

  snacksTreeData: IUITKTreeData;

  constructor() {
    // We have to initialize this here or it wil try to populate the tree with a null object before ngOnInit completes, causing an error
    this.snacksTreeData = {
      label: 'All Snacks',
      state: 'expanded',
      description: 'A tree view of all snacks',
      rootnode: true,
      children: [],
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.data && this.data) {
      this.snacksTreeData = this.populateTree();
    }
  }

  onNodeSelectListener(event: any) {
    if(event.state === 'leaf') {
      const snack = this.data.find((snack) => `${snack.id}` === event.description);
      this.selectedSnack.emit(snack);
    }
  }

  private populateTree(): IUITKTreeData {
    let root: IUITKTreeData = {
      label: 'All Snacks',
      state: 'expanded',
      description: 'A tree view of all snacks',
      rootnode: true,
      children: [],
    }

    Object.keys(SnackType).map((type) => {
      let node: IUITKChildNode = {
        label: type,
        state: 'collapsed',
        description: `A subcategory of ${type} snacks`,
        children: [],
      }

      this.data.filter((snack) => snack.snackType === SnackType[type]).map((snack) => {
        node.children.push({
          label: snack.name,
          state: 'leaf',
          description: `${snack.id}`,
        });
      });

      root.children.push(node);
    });

    return root;
  }
}
