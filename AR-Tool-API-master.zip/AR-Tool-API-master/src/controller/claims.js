var db = require('../config/db.config.js')
var facetProcess = require('../controller/facets.js');
var cosmosProcess = require('../controller/cosmos.js');
var unetProcess = require('../controller/unet.js');
var emailService = require('../config/email-service.js');


exports.insertAllClaims = function (loadFileId, res) {
    console.log("Calling insert claims");
    try {
        isFileAlreadyProcessed(loadFileId, function (err, result) {
            if (result) {
                queryClaimData(res, loadFileId);
            } else {
                updateStatusOfFile(loadFileId, 4, function (err, result) {
                    facetProcess.insertClaims(loadFileId, function (err, result) {
                        console.log("done inserting facet claim data");

                        unetProcess.insertUnetClaims(loadFileId, function (error, result) {
                            console.log("done inserting unet claim data");

                            cosmosProcess.insertCosmosClaims(loadFileId, function (error, result) {
                                console.log("done inserting cosmos claim data");
                                aggregateClaimsCosmos(loadFileId, function (err, result) {
                                    calcOrigClaimReceivedDateCosmos(loadFileId, function (err, result) {
                                        aggregateClaimsUnet(loadFileId, function (err, result) {
                                            updateStatusOfFile(loadFileId, 5, function (err, result) {
                                                queryClaimData(res, loadFileId);
                                                emailService.sendEmail(loadFileId);
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            }
        });

    } catch (error) {
        res.send({
            status: 500,
            result: 'failure',
            response: 'error'
        })
    }
}


function updateStatusOfFile(load_file_id, status_id, callback) {
    db.query("update batch_file_input set status_id="+ status_id+ " where load_file_id=?", load_file_id, function (err, resultt) {

        if (err) {
            callback(err);
        } else {
            callback(null, resultt);

        }
    });
}

function isFileAlreadyProcessed(load_file_id, callback) {
    console.log("result ",load_file_id);
    db.query("select status_id from batch_file_input where load_file_id=? and status_id >= 4", load_file_id, function (err, result) {
        console.log("result forload_file_id ", result);
        if (err) {
            console.log("error while cheking ",err);
            callback(err);
        } else {
            try {
                result = JSON.parse(JSON.stringify(result));
                console.log("result after parse ", result);
                if (result != null && result.length > 0) {
                    callback(null, true);
                } else {
                    callback(false);
                }
            } catch (err) {
                callback(false);
            }

        }
    });
}


function queryClaimData(res, load_file_id) {
    //let query ="select * from batch_file_detail_claim b1 right join (select * from batch_file_input_detail where load_file_id = (select max(load_file_id) as load_file_id from batch_file_input)) b2 on b1.load_file_detail_id = b2.load_file_detail_id";
    let query = " select " +
        " A.load_file_id " +
        " ,A.plan_name " +
        " ,A.load_file_detail_id " +
        " ,A.product " +
        " ,A.patient_last_name " +
        " ,A.patient_first_name" +
        " ,A.patient_dob " +
        " ,A.patient_group_policy " +
        " , A.subscriber_id" +
        " ,A.patient_account_number" +
        " ,A.prov_natl_prov_id" +
        " ,A.prov_tax_id" +
        " ,A.prov_name" +
        " ,A.claim_number" +
        " ,A.from_date_of_service" +
        " ,A.to_date_of_service" +
        " ,A.claim_billed_charges" +
        " ,A.claim_contractual_adjustments" +
        " ,A.claim_non_covered_charges" +
        " ,A.claim_deductible" +
        " ,A.claim_copay" +
        " ,A.claim_coins" +
        " ,A.claim_total_payment" +
        " ,A.claim_expected_payment" +
        " ,A.area" +
        " ,A.claim_provider_comments" +
        " ,SUBSTRING(A.claim_provider_comments,1,250) as claim_provider_comments_1" +
        " ,CASE WHEN CHAR_LENGTH(A.claim_provider_comments) > 250 then SUBSTRING(A.claim_provider_comments,251,250) END as claim_provider_comments_2" +
        " ,CASE WHEN CHAR_LENGTH(A.claim_provider_comments) > 500 then SUBSTRING(A.claim_provider_comments,5001,250) END as claim_provider_comments_3" +
        " ,CASE WHEN CHAR_LENGTH(A.claim_provider_comments) > 750 then SUBSTRING(A.claim_provider_comments,751,250) END as claim_provider_comments_4" +
        " ,A.claim_reason_codes" +
        " ,A.claim_paid_date" +
        " ,A.claim_last_reconsideration_date" +
        " ,A.ExtractField1" +
        " ,A.ExtractField2" +
        " ,A.ExtractField3" +
        " ,A.ExtractField4" +
        " ,A.ExtractField5" +
        " ,B.file_name" +
        " ,A.load_file_detail_id" +
        " ,M.load_file_detail_member_id" +
        " ,M.mbr_pty_id" +
        " ,M.consumer_id" +
        " ,DATE_FORMAT(M.dob, '%Y-%m-%d') as dob" +
        " ,M.source_system" +
        " ,M.subscriber_id as M_subscriber_id" +
        " ,M.member_id" +
        " ,M.fam_nm" +
        " ,M.giv_nm" +
        " ,M.midl_nm" +
        " ,M.tops_icn" +
        " ,coalesce(M.FAM_NM,A.patient_last_name) as export_last_name" +
        " ,coalesce(M.GIV_NM,A.patient_first_name) as export_first_name" +
        " ,coalesce(C.claim_first_service_date,A.from_date_of_service) as export_first_service_date" +
        " ,coalesce(M.DOB,A.patient_dob) as export_dob" +
        " ,coalesce(M.subscriber_id,A.subscriber_id) as export_sub" +
        " ,coalesce(M.group_policy_number,A.patient_group_policy) as export_policy" +
        " ,coalesce(C.account_num,A.patient_account_number) as export_account" +
        " ,coalesce(C.claim_last_service_date,A.to_date_of_service) as export_last_service_date" +
        " ,coalesce(C.claim_billed_amt,A.claim_billed_charges) as export_billed_charges" +
        " ,coalesce(C.claim_pat_resp_amt,coalesce(C.claim_copay_amt,0) + coalesce(C.claim_ded_amt,0)+coalesce(C.claim_coins_amt,0)) as export_patient_resp" +
        " ,M.group_policy_number" +
        " ,M.lob" +
        " ,C.claim_id" +
        " ,C.claim_received_date" +
        " ,C.claim_process_date" +
        " ,C.original_claim_received_date" +
        " ,C.original_claim_process_date" +
        " ,C.claim_first_service_date" +
        " ,C.claim_last_service_date" +
        " ,C.claim_billed_amt" +
        " ,C.claim_paid_amt" +
        " ,C.claim_copay_amt" +
        " ,C.claim_ded_amt" +
        " ,C.claim_coins_amt" +
        " ,C.claim_pat_resp_amt" +
        " ,C.claim_disallow_amt" +
        " ,C.claim_sequestration_amt" +
        " ,C.check_num" +
        " ,C.cosmos_provider_id" +
        " ,C.cosmos_div" +
        " ,C.cosmos_panel" +
        " ,C.par_status" +
        " ,C.member_state" +
        " ,C.place_of_service" +
        " ,C.claim_type" +
        " ,C.claim_status" +
        " ,C.unet_payloc" +
        " ,C.unet_engine" +
        " ,C.tops_relationship_cd" +
        " ,C.service_form_number" +
        " ,C.ORS_Record" +
        " ,C.DRG_Code" +
        " ,C.financial_arrangement" +
        " ,C.third_party" +
        " ,C.remark_cd" +
        " ,CONCAT(coalesce(CONCAT(C.remark_cd,' '),'')  , coalesce(C.denial_cd)) as D_denial_remark" +
        " ,C.account_num" +
        " ,C.denial_cd" +
        " ,C.provider_num" +
        " ,C.provider_mpin" +
        " ,C.prov_state" +
        " ,C.dec_num" +
        " ,C.claim_plan as C_plan" +
        " ,C.claim_product as C_product" +
        " ,C.claim_record_code" +
        " ,C.provider_grp_name" +
        " ,case when coalesce(A.patient_first_name,'') <> '' and A.patient_first_name <> M.GIV_NM then 'FNAME MISMATCH' else '' end as patient_first_name_warn" +
        " ,case when coalesce(A.patient_last_name,'') <> '' and A.patient_last_name <> M.FAM_NM then 'LNAME MISMATCH' else '' end as patient_last_name_warn" +
        " ,case when coalesce(patient_group_policy,'') <> '' and patient_group_policy <> M.group_policy_number then 'POLICY MISMATCH' else '' end as group_policy_warn" +
        " ,case when coalesce(A.subscriber_id,'') <> '' and A.subscriber_id <> M.subscriber_id then 'SUBSCRIBER ID MISMATCH' else '' end as subscriber_id_warn" +
        " ,case when coalesce(A.patient_account_number,'') <> '' and A.patient_account_number <> C.account_num then 'ACCOUNT NUM MISMATCH' else '' end as account_id_warn" +
        " ,case when coalesce(A.from_date_of_service,'') <> '' and A.from_date_of_service <> C.claim_first_service_date then 'FROM DOS MISMATCH' else '' end as from_dos_warn" +
        " ,case when coalesce(A.to_date_of_service,'') <> '1900-01-01' and A.to_date_of_service <> C.claim_last_service_date then 'THRU DOS MISMATCH' else '' end as thru_dos_warn" +
        " ,case when coalesce(A.patient_dob,'') <> '' and A.patient_dob <> M.DOB then 'DOB MISMATCH' else '' end as dob_warn" +
        " ,case when M.source_system is null then 'MEMBER NOT FOUND' " +
        "      when S.status_comment is not null then S.status_comment " +
        "      when C.load_file_detail_id is  null then 'CLAIM NOT FOUND' END as overall_status " +
        " ,'\\\\\\\\\\\\\\\\nasv0200\\\\\\\\onbaseloadprd\\\\\\\\ARTeam_Files\\\\\\\\arteam.tif' as onbasePath " +
        " , case when instr(B.file_name,'_')  > 0 AND instr(B.file_name,'_')  < 10 then substr(B.file_name,1,instr(B.file_name,'_')-1) else null end as issue_id " +
        " from batch_file_input_detail A" +
        " left outer join batch_file_input B" +
        " on A.load_file_id = B.load_file_id" +
        " left outer join batch_file_detail_member M" +
        " on A.load_file_detail_id = M.load_file_detail_id" +
        " left outer join batch_file_detail_status S" +
        " on A.load_file_detail_id = S.load_file_detail_id" +
        " left outer join batch_file_detail_claim C" +
        " on A.load_file_detail_id = C.load_file_detail_id" +
        " and M.load_file_detail_member_id = C.load_file_detail_member_id" +
        " and A.prov_tax_id = C.claim_tin" +
        " where M.load_file_id=?" +
        " order by M.load_file_detail_id,abs(cast(REPLACE(A.claim_billed_charges,',','') as decimal(10,2)) - cast(C.claim_billed_amt as decimal(10,2))),C.claim_process_date desc ";





    // let query = "select * from batch_file_detail_claim b1 join (select * from batch_file_input_detail b2 where b2.load_file_id = 903) b3 on b1.load_file_detail_id = b3.load_file_detail_id";
    console.log("claim query", query);
    db.query(query, load_file_id, function (err, records) {
        console.log("records",records.length)



        if (err) {
            res.send({
                status: 404,
                result: 'failure',
                response: 'no records found'
            })
        }
        else {

            if (records.length > 0) {
                var currLoadFileDetailID = 0;
                var recsToReturn= [];

                for(var i in records) 
                {
                    if(records[i].load_file_detail_id != currLoadFileDetailID){

                        recsToReturn.push(records[i]);
                    }else{

                    }
                    currLoadFileDetailID = records[i].load_file_detail_id
                }

                res.send({
                    status: 200,
                    result: 'success',
                    response: recsToReturn
                })
            }
            else {
                res.send({
                    status: 200,
                    result: 'failure',
                    response: 'no records found'
                })
            }

        }
    });
}

function aggregateClaimsCosmos(load_file_id, callback) {
    db.query('insert into batch_file_detail_claim(load_file_detail_claim_id,load_file_detail_member_id,load_file_detail_id,load_file_id,claim_id,claim_received_date,claim_process_date,original_claim_received_date,original_claim_process_date,claim_first_service_date,claim_last_service_date,claim_billed_amt,claim_paid_amt,claim_copay_amt,claim_ded_amt,claim_coins_amt,claim_pat_resp_amt,claim_disallow_amt,claim_sequestration_amt,check_num,cosmos_provider_id,cosmos_div,cosmos_panel,par_status,member_state,claim_type,claim_status,unet_payloc,unet_engine,tops_relationship_cd,service_form_number,ORS_Record,Place_Of_Service,DRG_Code,financial_arrangement,third_party,remark_cd,account_num,denial_cd,provider_num,provider_mpin,prov_state,dec_num,provider_grp_name,claim_fetch_user_id,claim_fetch_dttm,claim_tin,claim_npi,claim_product,claim_plan) ' +
        'select null,load_file_detail_member_id,load_file_detail_id,load_file_id,substr(claim_id,1,8),min(claim_received_date),max(claim_process_date),min(original_claim_received_date),max(original_claim_process_date),min(claim_first_service_date),max(claim_last_service_date) ' +
        ',sum(claim_billed_amt),sum(claim_paid_amt),sum(claim_copay_amt),sum(claim_ded_amt),sum(claim_coins_amt),sum(claim_pat_resp_amt),sum(claim_disallow_amt),sum(claim_sequestration_amt) ' +
        ',max(check_num),min(cosmos_provider_id),min(cosmos_div),min(cosmos_panel),min(par_status),min(member_state),min(claim_type),min(claim_status),min(unet_payloc),min(unet_engine),min(tops_relationship_cd), sum(service_form_number) ' +        
        ',min(ors_record),min(place_of_service),min(drg_code),min(financial_arrangement),min(third_party),min(remark_cd),min(account_num),group_concat(distinct denial_cd),min(provider_num),min(provider_mpin) ' +
        ',min(prov_state),min(dec_num),min(provider_grp_name),min(claim_fetch_user_id),min(claim_fetch_dttm),min(claim_tin),min(claim_npi),min(claim_product),min(claim_plan)  ' +
        'from batch_file_detail_claim where cosmos_div is not null  ' +
        'and load_file_id =   ' + load_file_id +
        ' and (load_file_detail_id,substr(claim_id,1,8)) in (select load_file_detail_id,substr(claim_id,1,8) from batch_file_detail_claim where load_file_id = ' + load_file_id + '  group by load_file_detail_id,substr(claim_id,1,8) having count(*) > 1) ' +
        'group by load_file_detail_id,load_file_id,load_file_detail_id,load_file_detail_member_id,substr(claim_id,1,8)'
        , function (error, results, fields) {
            if (error) {

                throw error;
                callback(error);
                return;
            } else {

                callback(null, results)

            }
        });
}

function calcOrigClaimReceivedDateCosmos(load_file_id, callback) {
    db.query('update batch_file_detail_claim c '+
    'inner join  '+
    '(select load_file_id,load_file_detail_member_id,claim_billed_amt,min(claim_received_date) as oldDate from batch_file_detail_claim Old group by load_file_id,load_file_detail_member_id,claim_billed_amt) old '+
    'set original_claim_received_date = old.oldDate '+
    'where cosmos_div is not null '+
    'and c.load_file_id = old.load_file_id and c.load_file_detail_member_id = old.load_file_detail_member_id and c.claim_billed_amt = old.claim_billed_amt '+
    'and c.load_file_id = ' + load_file_id
        , function (error, results, fields) {
            if (error) {

                throw error;
                callback(error);
                return;
            } else {

                callback(null, results)

            }
        });
}

function aggregateClaimsUnet(load_file_id, callback) {
    db.query('insert into batch_file_detail_claim(load_file_detail_claim_id,load_file_detail_member_id,load_file_detail_id,load_file_id,claim_id,claim_received_date,claim_process_date,original_claim_received_date,original_claim_process_date,claim_first_service_date,claim_last_service_date,claim_billed_amt,claim_paid_amt,claim_copay_amt,claim_ded_amt,claim_coins_amt,claim_pat_resp_amt,claim_disallow_amt,claim_sequestration_amt,check_num,cosmos_provider_id,cosmos_div,cosmos_panel,par_status,member_state,claim_type,claim_status,unet_payloc,unet_engine,tops_relationship_cd,service_form_number,ORS_Record,Place_Of_Service,DRG_Code,financial_arrangement,third_party,remark_cd,account_num,denial_cd,provider_num,provider_mpin,prov_state,dec_num,provider_grp_name,claim_fetch_user_id,claim_fetch_dttm,claim_tin,claim_npi,claim_product,claim_plan) ' +
        'select null,load_file_detail_member_id,load_file_detail_id,load_file_id,claim_id,min(claim_received_date),max(claim_process_date),min(original_claim_received_date),max(original_claim_process_date),min(claim_first_service_date),max(claim_last_service_date) ' +
        ',sum(claim_billed_amt),sum(claim_paid_amt),sum(claim_copay_amt),sum(claim_ded_amt),sum(claim_coins_amt),sum(claim_pat_resp_amt),sum(claim_disallow_amt),sum(claim_sequestration_amt) ' +
        ',max(check_num),min(cosmos_provider_id),min(cosmos_div),min(cosmos_panel),min(par_status),min(member_state),min(claim_type),min(claim_status),min(unet_payloc),min(unet_engine),min(tops_relationship_cd), sum(service_form_number) ' +
        ',min(ors_record),min(place_of_service),min(drg_code),min(financial_arrangement),min(third_party),min(remark_cd),min(account_num),group_concat(distinct denial_cd),min(provider_num),min(provider_mpin) ' +
        ',min(prov_state),min(dec_num),min(provider_grp_name),min(claim_fetch_user_id),min(claim_fetch_dttm),min(claim_tin),min(claim_npi),min(claim_product),min(claim_plan)  ' +
        'from batch_file_detail_claim where tops_relationship_cd is not null  ' +
        'and load_file_id =   ' + load_file_id +
        ' and (load_file_detail_id,claim_id) in (select load_file_detail_id,claim_id from batch_file_detail_claim where load_file_id = ' + load_file_id + '  group by load_file_detail_id,claim_id having count(*) > 1) ' +
        'group by load_file_detail_id,load_file_id,load_file_detail_id,load_file_detail_member_id,claim_id '
        , function (error, results, fields) {
            if (error) {

                throw error;
                callback(error);
                return;
            } else {

                callback(null, results)

            }
        });
}
