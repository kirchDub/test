const http = require('https');

oHttpService = {
    postMessage: function (_host, _path, _authtoken, _message, _isRequestTypeJSON, _isOutputTypeJSON, callback) {
        var options = {
            host: _host,
            path: _path,
            method: 'POST',
            headers: {
                //                'Content-Type': 'application/json',
                'User-Agent': 'Apache-HttpClient/4.1.1 (java 1.5)',
                'content-type': 'application/json', 'Accept': 'application/json', 'charset': 'utf-8',
                'Access-Control-Allow-Origin': '*',


            },
            
            rejectUnauthorized: false,
            requestCert: false,
            agent: false,
            'Accept-Encoding': 'gzip,deflate',
            SOAPAction: "",
        };
        if (_isRequestTypeJSON == "json") {
            options.headers["Content-Type"] = "application/json";
        }
        else if (_isRequestTypeJSON == "x-www-form-urlencoded") {
            options.headers["Content-Type"] = "application/x-www-form-urlencoded";
        }
        else {
            options.headers["Content-Type"] = "application/xml";
        }

        if (_authtoken != null) {
            options.headers["Authorization"] = "Bearer " + _authtoken;
            options.headers["Actor"] = "PDAT";
        }

        var req = http.request(options, function (res) {
            var body = '';

            res.setEncoding('utf8');

            res.on('data', function (data) {
                body += data;
            });

            res.on('end', function () {
                // Data reception is done
                var parsed;

                if (_isOutputTypeJSON == true) {
                    parsed = JSON.parse(body);
                }
                else {
                    parsed = body;
                }

                if (res.statusCode == 200) {
                    callback({
                        err: null,
                        result: parsed
                    });
                }
                else {
                    callback(parsed);
                }
            });
        });

        req.on('error', function (e) {
            callback({
                err: e.message
            });
        });

        if (_isRequestTypeJSON == true) {
            req.write(JSON.stringify(_message));
        }
        else {
            req.write(_message);
        }

        // write data to request body

        req.end();
    }
};

module.exports = oHttpService;