# What does this do

This repo creates a **Java Library** and **Avro Schema** generated from a Java POJO that you write.
The library gets pushed to Artifactory via the Jenkins pipeline.
The library can be consumed in Kafka Producer and Consumer applications.

## Create Artifactory Namespace

Go to the [Tech Hub](https://tech.optum.com/products/artifactory/create-artifactory-namespace) and create a Maven repository named `gp-bootcamp` and grant the user `gpbootcamp` deploy permissions.

## Add your Java class

This class should reflect what type of message is produced on the avro Kafka topic.

Add your Kafka message class to `src/test/com/optum` (or subdirectory if you want your class to have a different package e.g. `src/test/com/optum/dto/KafkaMessage.java` would have a `package com.optum.dto`)

## Generate avsc file and auto generated Java class
Once you have added your Java class you can run:

```
./gradlew test generateAvro
```

Using an example of a class called `KafkaMessage.class` this will generate two files (it could generate more depending on how complex your Java class is e.g. using nested classes):
* src/main/resources/avro/KafkaMessage.avsc
* src/main/java/com/optum/KafkaMessage.java

## Jenkins pipeline
The Jenkinsfile will run in any Jenkins server and build a libary to be used in a Java application to produce data to a Kafka avro topic or consume data using a topic with the avro schema published.

The library will be published to Artifactory in the provided namespace: gp-bootcamp

### Snapshot releases
Each run of the `master` branch will produce a SNAPSHOT release published to UHG-Snapshots on [Artifactory](https://repo1.uhc.com/artifactory/webapp/#/home).

[Snapshots](https://repo1.uhc.com/artifactory/list/UHG-Snapshots/com/optum/gp-bootcamp/bootcamp-claims-avro)

### Production releases
Production releases are finalized versions of the avro class to be used by applications.

You can create a release version of the library by creating a tag in Github.  [Read more](https://help.github.com/en/enterprise/2.19/user/github/administering-a-repository/managing-releases-in-a-repository)

[Releases](https://repo1.uhc.com/artifactory/list/UHG-Releases/com/optum/gp-bootcamp/bootcamp-claims-avro)


## Example
Add below to a file named `KafkaMessage.java` in `src/test/java/com/optum`:
```java
package com.optum;
public class KafkaMessage {

    private String hello;

    public String getHello() {
        return hello;
    }

    public void setHello(String hello) {
        this.hello = hello;
    }
}
```

Execute `./gradlew test generateAvro`

View raw avro schema file at `src/main/resources/avro/KafkaMessage.avsc`

View generated class file at `src/main/java/com/optum/KafkaMessage.java`
