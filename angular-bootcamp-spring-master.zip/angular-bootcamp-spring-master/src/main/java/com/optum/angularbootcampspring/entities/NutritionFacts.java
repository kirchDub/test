package com.optum.angularbootcampspring.entities;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Data
@Slf4j
@Embeddable
public class NutritionFacts implements Serializable {

    private int totalCalories;

    private int numberOfServings;

    private String allergicNotice;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        NutritionFacts that = (NutritionFacts) o;
        return totalCalories == that.totalCalories &&
                numberOfServings == that.numberOfServings &&
                allergicNotice.equals(that.allergicNotice);
    }

    @Override
    public int hashCode() {
        return Objects.hash(totalCalories, numberOfServings, allergicNotice);
    }
}
