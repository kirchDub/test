const express = require('express');
const router = express.Router();
var fs = require('fs');
const Upload = require('../models/upload.model.js');
var db = require('../config/db.config.js');
var XLSX = require('xlsx');

var uploads = require('../config/multer.config.js')

router.post('/', function (req, res) {
    try{
    var exceltojson;
    // res.connection.setTimeout(0);
    uploads(req, res, function (err) {
        if (err) {
            return res.end('Error Upload file')
        }
        else {
            var workbook = XLSX.read(req.file.buffer, {type:'buffer',cellDates: true});
            var sheet_name_list = workbook.SheetNames;
            var result = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]], {raw: true, defval:""}); 
                    if(result.length > 1) {
                        var filedetail = [];
                        for (var i = 0, len = result.length; i < len; i++) {
                            if (Object.values(result[i]).some(ele => ele !== "")) {
                                filedetail.push(result[i]);
                            };
                        };
                        
                        var metadata = JSON.stringify(filedetail);
                        var receivedrecords = filedetail.length;
                        // Inserting Filename and metadata to DB
                        Upload.addFile([req.file.originalname, metadata, receivedrecords, 1], function (err, records) {
                            if (err) throw err;
                            console.log("Number of records inserted: ", records.affectedRows)
                            var x = Object.keys(result[0]);
                            var headers = JSON.stringify(x);
                            console.log("result",headers);
                            var primarykey = records.insertId;
                            // Inserting HEADERS to DB
                            if (records.affectedRows > 0) {
                                Upload.addHeaders([primarykey, headers], function (err, result) {
                                    if (err) throw err;
                                    // console.log("Number of header records inserted: " + result.affectedRows);
                                    else {
                                        console.log("Number of records inserted: " + result.affectedRows);
                                        res.status(200).json({ message: 'uploaded successfully', load_file_id: primarykey });
                                    }
                                });
                            }
                        });
                    
                    }
                    else {
                        res.status(415).json({ message: 'unable to parse' });
                    }
           
        }
    });
}catch(error) 
{
    res.send({
        status: 500,
        result: 'failure',
        response: 'error'
    })
}
});


router.get('/getUploadedFiles', function (req, res, next) {
    try{
    console.log("get called for review file");
    let query = 'SELECT t1.load_file_id, load_dttm, file_name, file_comment, load_user_id, t2.valid_value_text as status_id, received_rec_cnt, rejected_rec_cnt, analysis_rec_cnt, t1.status_id as status_step, r2.processed_rec_count FROM pdat01.batch_file_input t1 left join pdat01.valid_values t2 on t1.status_id = t2.valid_value_id and t2.valid_value_type_id=2 left join (select load_file_id, count(distinct load_file_detail_id) as processed_rec_count from (select c.load_file_id,c.load_file_detail_id from batch_file_input i join batch_file_detail_claim c on i.load_file_id = c.load_file_id and c.claim_id is not null) t group by load_file_id) r2 on t1.load_file_id = r2.load_file_id  order by t1.load_file_id desc';

    db.query(query, function (err, records, fields) {

        if (err) {
            console.log(err);
            res.end('Error getting file data')
        }
        else {
            if (records.length > 0) {
                res.send({
                    status: 200,
                    result: 'success',
                    response: records
                })
            }
            else {
                res.send({
                    status: 404,
                    result: 'failure',
                    response: 'no records found'
                })
            }

        }
    });
}catch(error) 
{
    res.send({
        status: 500,
        result: 'failure',
        response: 'error'
    })
}
});

router.get('/getFile/:load_file_id', function (req, res) {
    try{
    console.log("get called in get file ", req.params.load_file_id);
    let query = 'SELECT * FROM pdat01.batch_file_input where load_file_id=?';

    db.query(query, req.params.load_file_id, function (err, records, fields) {

        if (err) {
            console.log(err);
            res.end('Error getting file data')
        }
        else {
            if (records.length > 0) {
                res.send({
                    status: 200,
                    result: 'success',
                    response: records
                })
            }
            else {
                res.send({
                    status: 404,
                    result: 'failure',
                    response: 'no records found'
                })
            }

        }
    });
}catch(error) 
{
    res.send({
        status: 500,
        result: 'failure',
        response: 'error'
    })
}
});
router.get('/getAnalysis/:load_file_id', function (req, res) {
    try{
    //console.log("get called in get file ",req.params.load_file_id);
    let query = 'SELECT * FROM pdat01.batch_file_input where load_file_id=?';

    db.query(query, req.params.load_file_id, function (err, records, fields) {

        if (err) {
            console.log(err);
            res.end('Error getting file data')
        }
        else {
            if (records.length > 0) {
                res.send({
                    status: 200,
                    result: 'success',
                    response: records
                })
            }
            else {
                res.send({
                    status: 404,
                    result: 'failure',
                    response: 'no records found'
                })
            }

        }
    });
}catch(error) 
{
    res.send({
        status: 500,
        result: 'failure',
        response: 'error'
    })
}
});

router.post('/comment/:load_file_id', function (req, res) {
    try{
    var data = JSON.parse(JSON.stringify(req.body));
    comment = data.userComment;
    user = data.userId;
    db.query("update batch_file_input set file_comment=?, load_user_id = ? where load_file_id=?", [comment, user, req.params.load_file_id], function (err, resultt) {
        if (err) {
            console.log(err);
            res.end('Error')
        }
        else {
            res.status(200).json({ message: 'Success' });
        }
    });
}catch(error) 
{
    res.send({
        status: 500,
        result: 'failure',
        response: 'error'
    })
}
});

module.exports = router