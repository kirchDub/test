var db = require('../config/db.config.js')

const Upload = {
    addFile:function (data, callback) {
        
        return db.query("INSERT INTO batch_file_input (load_dttm,file_name,file_metdata,received_rec_cnt,status_id) values (curdate(), ?)", [data], callback)
    },
    addHeaders:function (data, callback) {
        
        return db.query("INSERT INTO batch_file_input_headers (load_file_id,load_file_headers) VALUES (?)", [data], callback)
    },
}

module.exports = Upload
