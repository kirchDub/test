package com.optum.angularbootcampspring.service;

import com.optum.angularbootcampspring.entities.Ingredient;
import com.optum.angularbootcampspring.entities.Snack;
import com.optum.angularbootcampspring.repositories.IngredientRepository;
import com.optum.angularbootcampspring.repositories.SnackRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SnackService {
    private SnackRepository snackRepository;
    private IngredientRepository ingredientRepository;


    @Autowired
    SnackService(SnackRepository snackRepository, IngredientRepository ingredientRepository) {
        this.snackRepository = snackRepository;
        this.ingredientRepository = ingredientRepository;
    }


    @Transactional
    public Snack saveSnack(Snack snack) {
        Snack savedSnack = snackRepository.saveAndFlush(snack);
        List<Ingredient> ingredientList = savedSnack.getIngredients();
        ingredientList.forEach(ingredient -> {
            ingredient.setSnack(savedSnack);
            ingredientRepository.saveAndFlush(ingredient);
        });
        return savedSnack;
    }

    @Transactional
    public List<Snack> getAllSnacks() {
        List<Snack> snacks = snackRepository.findAll();
        snacks.forEach(snack -> {
            List<Ingredient> ingredients = ingredientRepository.findIngredientBySnack(snack);
            snack.setIngredients(ingredients);
        });
        return snacks;
    }

    @Transactional
    public void deleteAllSnacks() {
        snackRepository.deleteAll();
    }

    @Transactional
    public void deleteSnack(Snack snack) {
        snackRepository.delete(snack);
    }

    @Transactional
    public void deleteBySnackId(int id) {
        snackRepository.deleteById(id);
    }

    public List<String> ingredientList() {
        return ingredientRepository.findAll().stream()
                .map(ingredient -> ingredient.getName()).distinct().sorted().collect(Collectors.toList());
    }

}


