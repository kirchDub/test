package com.optum.angularbootcampspring.controller;

import com.optum.angularbootcampspring.domain.SnackDto;
import com.optum.angularbootcampspring.entities.Snack;
import com.optum.angularbootcampspring.service.ObjectMapperService;
import com.optum.angularbootcampspring.service.SnackService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping(value = "/api/v1/angular-bootcamp/",produces = MediaType.APPLICATION_JSON_VALUE)
public class SnackController {

    private SnackService snackService;
    private ObjectMapperService objectMapperService;

    @Autowired
    SnackController(SnackService snackService, ObjectMapperService objectMapperService) {
        this.snackService = snackService;
        this.objectMapperService = objectMapperService;
    }

    @PostMapping(value = "snack", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<SnackDto> saveSnack(@RequestBody SnackDto snackDto) {
        try {
            log.info("Processing SnackDto {}", snackDto);
            Snack snack = objectMapperService.toSnackEntity(snackDto);
            log.info("Converted to Snack  {} and ready to save", snack);
            Snack entity = snackService.saveSnack(snack);
            SnackDto _snackDto = objectMapperService.toSnackDto(entity);
            return new ResponseEntity(_snackDto,HttpStatus.CREATED);
        } catch (Exception e) {
            log.error("Failed to create snack {}, error - {} ",snackDto, e.getMessage() );
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("snacks/{id}")
    public ResponseEntity deleteSnack(@PathVariable int id) {
        try {
            snackService.deleteBySnackId(id);
            return new ResponseEntity(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            log.error("Failed to delete resource {} ,  {} ",id, e.getMessage());
            return new ResponseEntity(HttpStatus.NOT_FOUND);
        }
    }


    @GetMapping(value = "snacks", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<SnackDto> getSnacks() {
        List<Snack> snacks = snackService.getAllSnacks();
        return objectMapperService.toSnackDtos(snacks);
    }

    @GetMapping(value = "ingredients")
    public List<String> getIngredients() {
        return snackService.ingredientList();
    }
}
