import { SimpleChange, DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { UITKTreeModule } from '@uitk/angular';
import { Snack, SnackType } from '../shared/snack.model';

import { SnacksTreeComponent } from './snacks-tree.component';

let testData: Snack[] = [
  {
    id: 1,
    name: 'Hummus',
    description: 'A dip, spread, or savory dish made from cooked, mashed chickpeas',
    snackType: SnackType.Umami,
    calories: 177,
    fat: 8.59,
    protein: 4.8,
    carbohydrates: 20.1,
  },
  {
    id: 2,
    name: 'Broccoli',
    description: 'An edible green plant in the cabbage family',
    snackType: SnackType.Bitter,
    calories: 34,
    fat: 0.0,
    protein: 4.7,
    carbohydrates: 80.4,
  },
];

describe('SnacksTreeComponent', () => {
  let component: SnacksTreeComponent;
  let fixture: ComponentFixture<SnacksTreeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        BrowserAnimationsModule,
        UITKTreeModule,
      ],
      declarations: [ SnacksTreeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SnacksTreeComponent);
    component = fixture.componentInstance;
    component.data = testData;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should populate tree', () => {
    component.ngOnChanges({
      data: new SimpleChange([], testData, false)
    });
    expect(component.snacksTreeData.children).not.toEqual([]);
  });

  it('should emit selectedSnack', () => {
    let selectedSnack: Snack;
    component.selectedSnack.subscribe((snack: Snack) => selectedSnack = snack);
    
    fixture.detectChanges();

    component.ngOnChanges({
      data: new SimpleChange([], testData, false)
    });

    fixture.detectChanges();

    const tree: DebugElement = fixture.debugElement.query(By.css('uitk-c-tree'));
    
    tree.triggerEventHandler('onNodeSelect', {
      state: 'leaf',
      description: '1',
    });

    expect(selectedSnack).toEqual(testData[0]);
  });
});
