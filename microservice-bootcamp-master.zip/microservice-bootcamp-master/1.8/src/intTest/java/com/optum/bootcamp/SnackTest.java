package com.optum.bootcamp;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.when;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

import java.util.Arrays;
import java.util.List;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.optum.bootcamp.model.Snack;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class SnackTest {

  @BeforeAll
  static void setup() {
    RestAssured.baseURI = Config.baseURI;
    RestAssured.port = Config.port;
    RestAssured.useRelaxedHTTPSValidation();
  }

  @Test
  public void invalidEndpointTest() {
    when().get("/api/v1/not/valid").then().assertThat().statusCode(404);
  }

  @Test
  public void getAllSnacksTest() {
    // Create snacks to add to the database
    Snack snack1 = new Snack();
    String name1 = "Twix";
    snack1.setName(name1);

    Snack snack2 = new Snack();
    String name2 = "Twizzlers";
    snack2.setName(name2);

    // Make POST requests to add two snacks to the database
    Integer snack1Id =
        given()
            .contentType(ContentType.JSON)
            .body(snack1)
            .when()
            .post("/api/v1/snacks")
            .then()
            .assertThat()
            .statusCode(200)
            .body("id", notNullValue())
            .body("name", equalTo(name1))
            .extract()
            .path("id");

    Integer snack2Id =
        given()
            .contentType(ContentType.JSON)
            .body(snack2)
            .when()
            .post("/api/v1/snacks")
            .then()
            .assertThat()
            .statusCode(200)
            .body("id", notNullValue())
            .body("name", equalTo(name2))
            .extract()
            .path("id");

    // Make the GET request, check that the response is valid, and extract the list
    List<Snack> responseSnackList =
        Arrays.asList(
            when()
                .get("/api/v1/snacks")
                .then()
                .assertThat()
                .statusCode(200)
                .body("size()", greaterThanOrEqualTo(2))
                .extract()
                .as(Snack[].class));

    // Verify that the list contains the snacks we added
    assertThat(responseSnackList, hasItem(hasProperty("name", equalTo(name1))));
    assertThat(responseSnackList, hasItem(Matchers.hasProperty("id", equalTo(snack1Id))));
    assertThat(responseSnackList, hasItem(hasProperty("name", equalTo(name2))));
    assertThat(responseSnackList, hasItem(Matchers.hasProperty("id", equalTo(snack2Id))));
  }

  @Test
  public void createAndGetSnackByIdTest() {
    String name = "Gummi Bears";
    Snack snack = new Snack();
    snack.setName(name);

    // Make a POST request to add a snack to the database and extract the new ID from the response
    Integer id =
        given()
            .contentType(ContentType.JSON)
            .body(snack)
            .when()
            .post("/api/v1/snacks")
            .then()
            .assertThat()
            .statusCode(200)
            .body("id", notNullValue())
            .body("name", equalTo(name))
            .extract()
            .path("id");

    // Make the GET request and check that the response is what we expect
    when()
        .get("/api/v1/snacks/{snackId}", id)
        .then()
        .assertThat()
        .statusCode(200)
        .body("id", equalTo(id))
        .body("name", equalTo(name));

    /* Alternatively, we can run the assertions separately like so:
    Response getResponse = when().get("/api/v1/snacks/{snackId}", id).thenReturn();
    assertThat(getResponse.getStatusCode()).isEqualTo(200);
    Snack getResponseSnack = getResponse.getBody().as(Snack.class);
    assertThat(getResponseSnack.getId()).isEqualTo(id);
    assertThat(getResponseSnack.getName()).isEqualTo(name);
    */
  }

  @Test
  public void updateSnackTest() {
    String originalName = "Licorice";
    String newName = "Jelly Beans";

    Snack originalSnack = new Snack();
    originalSnack.setName(originalName);

    // Make a POST request to add a snack to the database and extract the new ID from the response
    Integer id =
        given()
            .contentType(ContentType.JSON)
            .body(originalSnack)
            .when()
            .post("/api/v1/snacks")
            .then()
            .assertThat()
            .statusCode(200)
            .body("id", notNullValue())
            .body("name", equalTo(originalName))
            .extract()
            .path("id");

    // Create DTO for PUT
    Snack snackToUpdate = new Snack(id, newName);

    // Make the PUT request and check that the response is what we expect
    given()
        .contentType(ContentType.JSON)
        .body(snackToUpdate)
        .when()
        .put("/api/v1/snacks")
        .then()
        .assertThat()
        .statusCode(200)
        .body("id", equalTo(id))
        .body("name", equalTo(newName));
  }

  @Test
  public void deleteSnackTest() {
    String name = "Kit Kat";
    Snack originalSnack = new Snack();
    originalSnack.setName(name);

    // Make a POST request to add a snack to the database and extract the new ID from the response
    Integer id =
        given()
            .contentType(ContentType.JSON)
            .body(originalSnack)
            .when()
            .post("/api/v1/snacks")
            .then()
            .assertThat()
            .statusCode(200)
            .body("id", notNullValue())
            .body("name", equalTo(name))
            .extract()
            .path("id");

    // Make the DELETE request and check that the response is what we expect
    when()
        .delete("/api/v1/snacks/{snackId}", id)
        .then()
        .assertThat()
        .statusCode(200)
        .body("id", equalTo(id))
        .body("name", equalTo(name));

    // Verify snack no longer exists
    when().get("/api/v1/snacks/{snackId}", id).then().assertThat().statusCode(500);
  }
}
