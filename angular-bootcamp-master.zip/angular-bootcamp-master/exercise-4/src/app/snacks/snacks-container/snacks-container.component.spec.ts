import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { UITKTabbedPanelsModule } from '@uitk/angular';

import { SnacksContainerComponent } from './snacks-container.component';

describe('SnacksContainerComponent', () => {
  let component: SnacksContainerComponent;
  let fixture: ComponentFixture<SnacksContainerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ UITKTabbedPanelsModule ],
      declarations: [ SnacksContainerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SnacksContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display tab titles', () => {
    const tabs: DebugElement[] = fixture.debugElement.queryAll(By.css('[role=tab]'));
    
    expect(tabs[0].nativeElement.textContent.trim()).toEqual(component.snacksTableTitle);
    expect(tabs[1].nativeElement.textContent.trim()).toEqual(component.snacksTreeTitle);
    expect(tabs[2].nativeElement.textContent.trim()).toEqual(component.snackDetailTitle);
  });
});
