var express = require('express')
var router = express.Router()
var ActiveDirectory = require('activedirectory')
var jwt = require('jsonwebtoken');
var db = require('../config/db.config.js');

var config = {
    //url: "ldap://ad-ldap-prod.uhc.com:389",
    url: "ldap://ad-ldap-mn053.uhc.com:389",
    baseDN: 'CN=Users,DC=ms,DC=ds,DC=uhc,DC=com',
    username: '',
    password: 'password',
    bindDN: '',
    bindCredentials: ''
};

var ad = new ActiveDirectory(config);

var currentUser = "";

//Http method: POST
//URI: /utils/login
//Authenticates the credentials given by a user (username, password) against LDAP
router.post('/login', function (req, res) {
    try {
        currentUser = req.body.u;
        config.username = req.body.u;
        config.bindDN = req.body.u;

        config.password = req.body.p;
        config.bindCredentials = req.body.p;
        ad = new ActiveDirectory(config);

        ad.authenticate(req.body.u, req.body.p, function (err, auth) {
            if (err) {
                res.send({
                    value: false
                });
            } else if (auth) {
                groupName = 'part_user';
                ad.isUserMemberOf(config.username.substring(3), groupName, function (err, isMember) {
                    if (err) {
                        res.send({
                            value: false
                        });
                    } else { //user is authorized
                        if(isMember) 
                        {
                        var token = jwt.sign({
                            value: isMember
                            , userName: req.body.u
                            , group: groupName
                        }, process.env.JWT_KEY, {
                                expiresIn: "12h",
                                algorithm: "HS512"
                            });
                        
                        res.send({
                            value: isMember,
                            tk: token
                        });
                        getUserInformation(ad, config.username.substring(3));
                    }
                    else{
                        res.send({
                            value: false
                        });
                    }
                    }
                });
            } else {
                res.send({
                    value: false
                })
            }
        });
        // getUserInformation(ad, config.username.substring(3));
    } catch (error) {
        res.send({
            status: 500,
            result: 'failure',
            response: 'error'
        })
    }
}); //end login

//Http method: GET
//URI: /utils/auth
//Verifies secure group membership
router.get('/auth', function (req, res) {
    try {
        groupName = 'part_user';
        ad.isUserMemberOf(config.username.substring(3), groupName, function (err, isMember) {
            if (err) {
                res.send({
                    value: false
                });
            } else { //user is authorized
                var token = jwt.sign({
                    value: isMember
                    , userName: req.body.u
                    , group: groupName
                }, process.env.JWT_KEY, {
                        expiresIn: "12h",
                        algorithm: "HS512"
                    });
                
                res.send({
                    value: isMember,
                    tk: token
                });
                getUserInformation(ad, config.username.substring(3));
            }
        });
    } catch (error) {
        res.send({
            status: 500,
            result: 'failure',
            response: 'error'
        })
    }
});

function getUserInformation(ad, username) {

    ad.findUser(username, function (err, user) {
        if (err) {
            console.log("Not found user")
            return;
        }
        else {
            var currentdate = new Date();
            var post = {
                login_name: username,
                display_name: user.displayName,
                first_name: user.givenName,
                last_name: user.sn,
                last_login_dttm: currentdate,
                email: user.mail
            }
            db.query("INSERT INTO users SET ?", post, function (err, result) {

            });
        };
    })

}

module.exports = router;
