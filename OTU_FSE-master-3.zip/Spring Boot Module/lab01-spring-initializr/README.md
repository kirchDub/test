# FTE Novice Microservices Course
## Lab 01 - Spring Initializr
 
