import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-not-found',
  templateUrl: './page-not-found.component.html',
  styles: [
  ]
})
export class PageNotFoundComponent implements OnInit {

  titleText = 'Page Not Found!'; 
  bodyText = "Sorry, it looks like this page doesn't exist.";

  constructor() { }

  ngOnInit(): void {
  }

}
