package com.optum.claimsprocessor.services;

import java.util.List;

import org.apache.kafka.common.PartitionInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.optum.PatientSummary;
import com.optum.SubmittedClaim;

@Service
public class ClaimsProcessorServiceImpl implements ClaimsProcessor {

  private @Value("${claims.kafka.topic}") String claimsTopic;

  private @Value("${patient.summary.topic}") String claimsUutputTopic;

  private KafkaTemplate<String, Object> kafkaTemplate;

  private Logger LOG = LoggerFactory.getLogger(ClaimsProcessor.class);

  @Autowired
  public ClaimsProcessorServiceImpl(KafkaTemplate kafkaTemplate) {

    this.kafkaTemplate = kafkaTemplate;
  }

  @Override
  public void publishPatientSummary(PatientSummary patientSummary) {
    kafkaTemplate.send(claimsUutputTopic, patientSummary);
  }

  @Override
  public void publishClaim(SubmittedClaim submittedClaim) {

    List<PartitionInfo> partitionInfoList = kafkaTemplate.partitionsFor(claimsTopic);

    LOG.info("Partition Information {} ", partitionInfoList);

    LOG.info("About to publish submitted claim ");

    kafkaTemplate.send(claimsTopic, submittedClaim.getPatientName(), submittedClaim);

    LOG.info("Published message to queue complete");
  }
}
