package com.optum.otu.novice.service.demo.model;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
class MedicationTypeRepositoryTest {

//    TODO: Uncomment these tests and ensure that they run correctly after adding the MedicationType functionality
//    @Autowired
//    MedicationTypeRepository medicationTypeRepository;
//
//    @Test
//    void testSave() {
//        MedicationType medicationType = new MedicationType();
//        medicationType.setTypename("TestDrugType");
//
//        medicationTypeRepository.save(medicationType);
//
//        assertNotNull(medicationType.getId());
//    }
//
//    @Test
//    void testFindByTypeName() {
//        MedicationType medicationType = medicationTypeRepository.findByTypename("RoutedDrug");
//
//        assertNotNull(medicationType);
//        assertEquals(medicationType.getId(), 1L);
//    }

}
