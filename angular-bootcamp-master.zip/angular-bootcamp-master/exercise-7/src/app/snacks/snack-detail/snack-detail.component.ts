import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-snack-detail',
  templateUrl: './snack-detail.component.html',
  styles: [
  ]
})
export class SnackDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
