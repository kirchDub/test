import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-snacks-tree',
  templateUrl: './snacks-tree.component.html',
  styles: [
  ]
})
export class SnacksTreeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
