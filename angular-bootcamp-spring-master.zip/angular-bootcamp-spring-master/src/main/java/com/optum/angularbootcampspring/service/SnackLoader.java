package com.optum.angularbootcampspring.service;

import com.optum.angularbootcampspring.domain.Classification;
import com.optum.angularbootcampspring.domain.SnackTypes;
import com.optum.angularbootcampspring.entities.Ingredient;
import com.optum.angularbootcampspring.entities.NutritionFacts;
import com.optum.angularbootcampspring.entities.Snack;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

@Slf4j
@Component
public class SnackLoader {

    private String [] tacoIngredients = new String [] {"Flour", "Beef", "Chillo", "Oregano","Cumin","Salt"};
    private String [] cheeseCurdIngredients = new String [] {"Cheese", "Flour", "Eggs", "Milk","Vegetable Oil"};
    private String [] fruitSaladIngredients = new String [] {"Strawberries", "Pineapple", "Blueberries", "Honey","Lime"};
    private String [] roastedPotatoSaladIngredients = new String [] {"Potatoes", "Eggs", "Red Onions", "Dill","Mustard","Mayonnaise","Salt"};
    private String [] butteredVegetablesIngredients = new String [] {"Brussel Sprouts", "Cabbage", "Carrots", "Leeks","Green Beans","Asparagus","Butter", "Olive Oil","Salt"};
    private String [] peanutButterCookiesIngredients = new String [] {"Flour", "Butter", "Milk", "Coconut Oil","Sugar","Peanut Butter","Vanilla Extract","Salt"};
    private String [] chocolateBillionaireIngredients = new String [] {"Rice Krispies", "Pecans", "Milk", "Chocolate","Sugar","Caramel","Vanilla Extract"};
    private String [] peanutbutterKissIngredients = new String [] {"Chocolate", "Peanut", "Milk", "Eggs","Sugar","Vanilla Extract"};
    private String [] chocolateMousseIngredients = new String [] {"Whipping Cream","Chocolate" ,"Eggs", "Raspberries", "Eggs","Sugar","Vanilla Extract"};
    private String [] vanillaMeringueCookiesIngredients = new String [] {"Egg Whites","Tartar" ,"Eggs", "Sugar","Vanilla Extract"};
    private String [] pecanCaramelIngredients = new String [] {"Pecans","Caramel" ,"Eggs","Pretzel","Sugar","Vanilla Extract"};
    private String [] frenchMadeleineCookiesIngredients = new String [] {"Pecans","Caramel" ,"Eggs","Pretzel","Sugar","Vanilla Extract"};
    private String [] challahBreadPuddingIngredients = new String [] {"Brown Sugar","Half and Half Cream","Butter","Eggs","Nutmeg","Challah Bread","Vanilla Extract","Walnut","Raisins"};
    private String [] chocolateDateEnergyBallsIngredients = new String [] {"Medjool Dates","Cherries","Chocolate Flakes","Eggs","Sunflower Seeds","Vanilla Extract"};
    private String [] stickyHoneyChickenWingsIngredients = new String [] {"Orange Blossom Honey","White Vinegar","Chicken Wings","Paprika","Pepper","Salt"};
    private String [] raisinNutComboIngredients = new String [] {"Raisins", "Macadamia Nuts", "Cashew Nut", "Pistachios","Salt","Honey"};
    private String [] blackBeanStuffedPotatoesIngredients = new String [] {"Sweet Potatoes", "Black Beans", "Avocado", "Basil","Salt","Cayenne"};


    private Random ratingGenerator = new Random();
    private static final int MIN = 1;
    private static int MAX = 5;

    private SnackLoader(){

    }

    public List<Snack>snacksForLoading(){
         List<Snack> snacks = new ArrayList<>();
         snacks.add(buildTacoSnack());
         snacks.add(buildCheeseCurdSnack());
         snacks.add(buildFruitSaladSnack());
         snacks.add(buildRoastedPotatoSaladSnack());
         snacks.add(buildButteredVegetablesSnack());
         snacks.add(buildPeanutButterCookiesSnack());
         snacks.add(buildPeanutButterKissSnack());
         snacks.add(buildChocolateMousseSnack());
         snacks.add(buildChocolateBillionairesSnack());
         snacks.add(buildVanillaMeringueCookiesSnack());
         snacks.add(buildPecanCaramelSnack());
         snacks.add(buildFrenchMadeleineCookiesSnack());
         snacks.add(buildChallahBreadPuddingSnack());
         snacks.add(buildChocolateDateEnergyBallsSnack());
         snacks.add(buildStickyHoneyChickenWingsSnack());
         snacks.add(buildRaisinNutComboSnack());
         snacks.add(buildBlackBeanStuffedPotatoesSnack());
        return snacks;

     }


     public void logSnacks(){
         log.info("And the Snacks are: \n");
         snacksForLoading().forEach(snack -> {
             log.info("{}", snack);
             log.info("\n");
         });
     }

    private Snack buildTacoSnack(){
        Snack tacos = new Snack();
        tacos.setName("Tacos");
        List<Ingredient> ingredients = Arrays.stream(tacoIngredients).map( name -> {
            Ingredient ingredient = new Ingredient();
            ingredient.setName(name);
            ingredient.setClassification(Classification.Natural);
            ingredient.setPercent(20);
            return ingredient;
        }).collect(Collectors.toList());
        tacos.setIngredients(ingredients);
        tacos.setReview("Finger Licking good!");
        tacos.setType(SnackTypes.Savoury);
        tacos.setRating(ratingGenerator.nextInt(MAX - MIN + 1) + MIN);
        NutritionFacts facts = new NutritionFacts();
        facts.setAllergicNotice("May contain traces of peanut");
        facts.setTotalCalories(800);
        facts.setNumberOfServings(4);
        tacos.setNutritionFacts(facts);
        return tacos;
    }

    private Snack buildCheeseCurdSnack(){
        Snack cheeseCurds = new Snack();
        cheeseCurds.setName("Cheese Curds");
        List<Ingredient> ingredients = Arrays.stream(cheeseCurdIngredients).map( name -> {
            Ingredient ingredient = new Ingredient();
            ingredient.setName(name);
            ingredient.setClassification(Classification.Natural);
            ingredient.setPercent(20);
            return ingredient;
        }).collect(Collectors.toList());
        cheeseCurds.setIngredients(ingredients);
        cheeseCurds.setType(SnackTypes.Savoury);
        cheeseCurds.setReview("These are so cheesy, I mean tasty!");
        cheeseCurds.setRating(ratingGenerator.nextInt(MAX - MIN + 1) + MIN);
        NutritionFacts facts = new NutritionFacts();
        facts.setAllergicNotice("May contain traces of soy");
        facts.setTotalCalories(800);
        facts.setNumberOfServings(4);
        cheeseCurds.setNutritionFacts(facts);
        return cheeseCurds;
    }

    private Snack buildFruitSaladSnack(){
        Snack fruitSalad = new Snack();
        fruitSalad.setName("Fruit Salad");
        List<Ingredient> ingredients = Arrays.stream(fruitSaladIngredients).map( name -> {
            Ingredient ingredient = new Ingredient();
            ingredient.setName(name);
            ingredient.setClassification(Classification.Natural);
            ingredient.setPercent(20);
            return ingredient;
        }).collect(Collectors.toList());
        fruitSalad.setIngredients(ingredients);
        fruitSalad.setType(SnackTypes.Sweet);
        fruitSalad.setRating(ratingGenerator.nextInt(MAX - MIN + 1) + MIN);
        fruitSalad.setReview("So, so delectable, I keep smacking my lips matey!!");
        NutritionFacts facts = new NutritionFacts();
        facts.setAllergicNotice("Contains natural fillers");
        facts.setTotalCalories(250);
        facts.setNumberOfServings(6);
        fruitSalad.setNutritionFacts(facts);
        return fruitSalad;
    }

    private Snack buildRoastedPotatoSaladSnack(){
        Snack roastedPotatoSalad = new Snack();
        roastedPotatoSalad.setName("Roasted Potato Salad");
        List<Ingredient> ingredients = Arrays.stream(roastedPotatoSaladIngredients).map( name -> {
            Ingredient ingredient = new Ingredient();
            ingredient.setName(name);
            ingredient.setClassification(Classification.Natural);
            ingredient.setPercent(20);
            return ingredient;
        }).collect(Collectors.toList());
        roastedPotatoSalad.setIngredients(ingredients);
        roastedPotatoSalad.setType(SnackTypes.Savoury);
        roastedPotatoSalad.setReview("Wow weee Wow!");
        roastedPotatoSalad.setRating(ratingGenerator.nextInt(MAX - MIN + 1) + MIN);
        NutritionFacts facts = new NutritionFacts();
        facts.setAllergicNotice("Allergy Friendly, no nuts or dairy");
        facts.setTotalCalories(750);
        facts.setNumberOfServings(3);
        roastedPotatoSalad.setNutritionFacts(facts);
        return roastedPotatoSalad;
    }

    private Snack buildButteredVegetablesSnack(){
        Snack butteredVeggies = new Snack();
        butteredVeggies.setName("Buttered Vegetables");
        List<Ingredient> ingredients = Arrays.stream(butteredVegetablesIngredients).map( name -> {
            Ingredient ingredient = new Ingredient();
            ingredient.setName(name);
            ingredient.setClassification(Classification.Natural);
            ingredient.setPercent(20);
            return ingredient;
        }).collect(Collectors.toList());
        butteredVeggies.setIngredients(ingredients);
        butteredVeggies.setType(SnackTypes.Savoury);
        butteredVeggies.setReview("Yummy buttery tasty delight. I like the sweetness of the carrots and the contrast of the red onions, it's certainly a treat");
        butteredVeggies.setRating(ratingGenerator.nextInt(MAX - MIN + 1) + MIN);
        NutritionFacts facts = new NutritionFacts();
        facts.setAllergicNotice("Allergy Friendly, all natural ingredients");
        facts.setTotalCalories(750);
        facts.setNumberOfServings(3);
        butteredVeggies.setNutritionFacts(facts);
        return butteredVeggies;
    }

    private Snack buildPeanutButterCookiesSnack(){
        Snack peanutButterCookies = new Snack();
        peanutButterCookies.setName("Peanut Butter Cookies");
        List<Ingredient> ingredients = Arrays.stream(peanutButterCookiesIngredients).map( name -> {
            Ingredient ingredient = new Ingredient();
            ingredient.setName(name);
            ingredient.setClassification(Classification.Natural);
            ingredient.setPercent(20);
            return ingredient;
        }).collect(Collectors.toList());
        peanutButterCookies.setIngredients(ingredients);
        peanutButterCookies.setType(SnackTypes.Sweet);
        peanutButterCookies.setRating(ratingGenerator.nextInt(MAX - MIN + 1) + MIN);
        peanutButterCookies.setReview("Chocolate and Peanuts, this is a winning combo!");
        NutritionFacts facts = new NutritionFacts();
        facts.setAllergicNotice("USDA Certified Organic products only");
        facts.setTotalCalories(750);
        facts.setNumberOfServings(3);
        peanutButterCookies.setNutritionFacts(facts);
        return peanutButterCookies;
    }

    private Snack buildChocolateBillionairesSnack(){
        Snack chocBillionaires = new Snack();
        chocBillionaires.setName("Chocolate Billionaires");
        List<Ingredient> ingredients = Arrays.stream(chocolateBillionaireIngredients).map( name -> {
            Ingredient ingredient = new Ingredient();
            ingredient.setName(name);
            ingredient.setClassification(Classification.Natural);
            ingredient.setPercent(20);
            return ingredient;
        }).collect(Collectors.toList());
        chocBillionaires.setType(SnackTypes.Savoury);
        chocBillionaires.setIngredients(ingredients);
        chocBillionaires.setType(SnackTypes.Sweet);
        chocBillionaires.setReview("Love it so much!!, just give me the packet, give me the packet, now!!");
        chocBillionaires.setRating(ratingGenerator.nextInt(MAX - MIN + 1) + MIN);
        NutritionFacts facts = new NutritionFacts();
        facts.setAllergicNotice("Contains nuts and other oils");
        facts.setTotalCalories(1250);
        facts.setNumberOfServings(7);
        chocBillionaires.setNutritionFacts(facts);
        return chocBillionaires;
    }

    private Snack buildPeanutButterKissSnack(){
        Snack kissCookies = new Snack();
        kissCookies.setName("Peanut Butter Kiss Cookies");
        List<Ingredient> ingredients = Arrays.stream(peanutbutterKissIngredients).map( name -> {
            Ingredient ingredient = new Ingredient();
            ingredient.setName(name);
            ingredient.setClassification(Classification.Natural);
            ingredient.setPercent(20);
            return ingredient;
        }).collect(Collectors.toList());
        kissCookies.setIngredients(ingredients);
        kissCookies.setType(SnackTypes.Sweet);
        kissCookies.setReview("Simply wonderful, love them a lot");
        kissCookies.setRating(ratingGenerator.nextInt(MAX - MIN + 1) + MIN);
        NutritionFacts facts = new NutritionFacts();
        facts.setAllergicNotice("Contains nuts and traces dairy products");
        facts.setTotalCalories(1250);
        facts.setNumberOfServings(7);
        kissCookies.setNutritionFacts(facts);
        return kissCookies;
    }

    private Snack buildChocolateMousseSnack(){
        Snack mousse = new Snack();
        mousse.setName("Chocolate Mousse");
        List<Ingredient> ingredients = Arrays.stream(chocolateMousseIngredients).map( name -> {
            Ingredient ingredient = new Ingredient();
            ingredient.setName(name);
            ingredient.setClassification(Classification.Natural);
            ingredient.setPercent(20);
            return ingredient;
        }).collect(Collectors.toList());
        mousse.setIngredients(ingredients);
        mousse.setType(SnackTypes.Sweet);
        mousse.setReview("This mousse is just luscious, silky smooth creamy, just amazingly rich chocolatey velvet");
        mousse.setRating(ratingGenerator.nextInt(MAX - MIN + 1) + MIN);
        NutritionFacts facts = new NutritionFacts();
        facts.setAllergicNotice("Contains no nuts");
        facts.setTotalCalories(1250);
        facts.setNumberOfServings(7);
        mousse.setNutritionFacts(facts);
        return mousse;
    }

    private Snack buildVanillaMeringueCookiesSnack(){
        Snack vanillaMeringues = new Snack();
        vanillaMeringues.setName("Vanilla Meringue Cookies");
        List<Ingredient> ingredients = Arrays.stream(vanillaMeringueCookiesIngredients).map( name -> {
            Ingredient ingredient = new Ingredient();
            ingredient.setName(name);
            ingredient.setClassification(Classification.Natural);
            ingredient.setPercent(20);
            return ingredient;
        }).collect(Collectors.toList());
        vanillaMeringues.setIngredients(ingredients);
        vanillaMeringues.setType(SnackTypes.Sweet);
        vanillaMeringues.setReview("great cookies, love em");
        vanillaMeringues.setRating(ratingGenerator.nextInt(MAX - MIN + 1) + MIN);
        NutritionFacts facts = new NutritionFacts();
        facts.setAllergicNotice("Contains nuts and other oils");
        facts.setTotalCalories(650);
        facts.setNumberOfServings(5);
        vanillaMeringues.setNutritionFacts(facts);
        return vanillaMeringues;
    }

    private Snack buildPecanCaramelSnack(){
        Snack pecanCaramel = new Snack();
        pecanCaramel.setName("Pecan Caramel Candy");
        List<Ingredient> ingredients = Arrays.stream(pecanCaramelIngredients).map( name -> {
            Ingredient ingredient = new Ingredient();
            ingredient.setName(name);
            ingredient.setClassification(Classification.Natural);
            ingredient.setPercent(20);
            return ingredient;
        }).collect(Collectors.toList());
        pecanCaramel.setIngredients(ingredients);
        pecanCaramel.setType(SnackTypes.Sweet);
        pecanCaramel.setReview("Best candy by a mile, can I have some more? Well, you just yourself a fan.");
        pecanCaramel.setRating(ratingGenerator.nextInt(MAX - MIN + 1) + MIN);
        NutritionFacts facts = new NutritionFacts();
        facts.setAllergicNotice("May contain traces of dairy");
        facts.setTotalCalories(650);
        facts.setNumberOfServings(5);
        pecanCaramel.setNutritionFacts(facts);
        return pecanCaramel;
    }

    private Snack buildFrenchMadeleineCookiesSnack(){
        Snack frenchMadeleines = new Snack();
        frenchMadeleines.setName("French Madeleine Cookies");
        List<Ingredient> ingredients = Arrays.stream(frenchMadeleineCookiesIngredients).map( name -> {
            Ingredient ingredient = new Ingredient();
            ingredient.setName(name);
            ingredient.setClassification(Classification.Natural);
            ingredient.setPercent(20);
            return ingredient;
        }).collect(Collectors.toList());
        frenchMadeleines.setIngredients(ingredients);
        frenchMadeleines.setType(SnackTypes.Sweet);
        frenchMadeleines.setReview("Cakes are not my thing, but i must say, these are the exception, i'm heading straight to the cake isle to get some");
        frenchMadeleines.setRating(ratingGenerator.nextInt(MAX - MIN + 1) + MIN);
        NutritionFacts facts = new NutritionFacts();
        facts.setAllergicNotice("Contains soy and dairy products");
        facts.setTotalCalories(650);
        facts.setNumberOfServings(5);
        frenchMadeleines.setNutritionFacts(facts);
        return frenchMadeleines;
    }

   private Snack buildChallahBreadPuddingSnack(){
        Snack challahPudding = new Snack();
        challahPudding.setName("Challah Bread Pudding");
        List<Ingredient> ingredients = Arrays.stream(challahBreadPuddingIngredients).map( name -> {
            Ingredient ingredient = new Ingredient();
            ingredient.setName(name);
            ingredient.setClassification(Classification.Natural);
            ingredient.setPercent(20);
            return ingredient;
        }).collect(Collectors.toList());
        challahPudding.setIngredients(ingredients);
        challahPudding.setType(SnackTypes.Sweet);
        challahPudding.setReview("i love it, i simply love it. ");
        challahPudding.setRating(ratingGenerator.nextInt(MAX - MIN + 1) + MIN);
        NutritionFacts facts = new NutritionFacts();
        facts.setAllergicNotice("May contain additional fillers");
        facts.setTotalCalories(650);
        facts.setNumberOfServings(5);
        challahPudding.setNutritionFacts(facts);
        return challahPudding;
    }

    private Snack buildChocolateDateEnergyBallsSnack(){
        Snack energyBalls = new Snack();
        energyBalls.setName("Chocolate Date Energy Balls");
        List<Ingredient> ingredients = Arrays.stream(chocolateDateEnergyBallsIngredients).map( name -> {
            Ingredient ingredient = new Ingredient();
            ingredient.setName(name);
            ingredient.setClassification(Classification.Natural);
            ingredient.setPercent(20);
            return ingredient;
        }).collect(Collectors.toList());
        energyBalls.setIngredients(ingredients);
        energyBalls.setType(SnackTypes.Sweet);
        energyBalls.setReview("I've got me some energy now, that's for sure. What's in these things?");
        energyBalls.setRating(ratingGenerator.nextInt(MAX - MIN + 1) + MIN);
        NutritionFacts facts = new NutritionFacts();
        facts.setAllergicNotice("Certified USDA Organic products and all natural fillers");
        facts.setTotalCalories(650);
        facts.setNumberOfServings(5);
        energyBalls.setNutritionFacts(facts);
        return energyBalls;
    }

    private Snack buildStickyHoneyChickenWingsSnack(){
        Snack honeyChicken = new Snack();
        honeyChicken.setName("Sticky Honey Chicken Wings");
        List<Ingredient> ingredients = Arrays.stream(stickyHoneyChickenWingsIngredients).map( name -> {
            Ingredient ingredient = new Ingredient();
            ingredient.setName(name);
            ingredient.setClassification(Classification.Natural);
            ingredient.setPercent(20);
            return ingredient;
        }).collect(Collectors.toList());
        honeyChicken.setIngredients(ingredients);
        honeyChicken.setReview("With chicken so good, I might fly!");
        honeyChicken.setType(SnackTypes.Savoury);
        honeyChicken.setRating(ratingGenerator.nextInt(MAX - MIN + 1) + MIN);
        NutritionFacts facts = new NutritionFacts();
        facts.setAllergicNotice("Contains Monosodium Glutamate");
        facts.setTotalCalories(650);
        facts.setNumberOfServings(5);
        honeyChicken.setNutritionFacts(facts);
        return honeyChicken;
    }

    private Snack buildRaisinNutComboSnack(){
        Snack raisinPeanuts = new Snack();
        raisinPeanuts.setName("Raisin Nut Combo");
        List<Ingredient> ingredients = Arrays.stream(raisinNutComboIngredients).map( name -> {
            Ingredient ingredient = new Ingredient();
            ingredient.setName(name);
            ingredient.setClassification(Classification.Natural);
            ingredient.setPercent(20);
            return ingredient;
        }).collect(Collectors.toList());
        raisinPeanuts.setIngredients(ingredients);
        raisinPeanuts.setType(SnackTypes.Savoury);
        raisinPeanuts.setReview("This treat is certainly raising the bar, no pun intended!");
        raisinPeanuts.setRating(ratingGenerator.nextInt(MAX - MIN + 1) + MIN);
        NutritionFacts facts = new NutritionFacts();
        facts.setAllergicNotice("May contain additional nuts");
        facts.setTotalCalories(650);
        facts.setNumberOfServings(5);
        raisinPeanuts.setNutritionFacts(facts);
        return raisinPeanuts;
    }

    private Snack buildBlackBeanStuffedPotatoesSnack(){
        Snack blackBeanStuffedPotatoes = new Snack();
        blackBeanStuffedPotatoes.setName("Black Bean Stuffed Potatoes");
        List<Ingredient> ingredients = Arrays.stream(blackBeanStuffedPotatoesIngredients).map( name -> {
            Ingredient ingredient = new Ingredient();
            ingredient.setName(name);
            ingredient.setClassification(Classification.Natural);
            ingredient.setPercent(20);
            return ingredient;
        }).collect(Collectors.toList());
        blackBeanStuffedPotatoes.setIngredients(ingredients);
        blackBeanStuffedPotatoes.setType(SnackTypes.Savoury);
        blackBeanStuffedPotatoes.setReview("Wonderful, delightful, sumptuous, what more can I say!");
        blackBeanStuffedPotatoes.setRating(ratingGenerator.nextInt(MAX - MIN + 1) + MIN);
        NutritionFacts facts = new NutritionFacts();
        facts.setAllergicNotice("Contains no nut products, USDA certified organic ingredients");
        facts.setTotalCalories(450);
        facts.setNumberOfServings(5);
        blackBeanStuffedPotatoes.setNutritionFacts(facts);
        return blackBeanStuffedPotatoes;
    }
}
