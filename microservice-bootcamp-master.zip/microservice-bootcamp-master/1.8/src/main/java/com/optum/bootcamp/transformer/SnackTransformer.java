package com.optum.bootcamp.transformer;

import java.util.ArrayList;
import java.util.List;

import com.optum.bootcamp.entity.SnackEntity;
import com.optum.bootcamp.model.Snack;

public class SnackTransformer {

  public static Snack toSnack(SnackEntity fromSnack) {
    Snack snack = new Snack();
    snack.setId(fromSnack.getId());
    snack.setName(fromSnack.getName());

    return snack;
  }

  public static SnackEntity toSnackEntity(Snack fromSnack) {
    SnackEntity snackEntity = new SnackEntity();
    snackEntity.setId(fromSnack.getId());
    snackEntity.setName(fromSnack.getName());

    return snackEntity;
  }

  public static List<Snack> toSnack(List<SnackEntity> snackEntities) {
    List<Snack> snacks = new ArrayList<>();
    for (SnackEntity snackEntity : snackEntities) {
      snacks.add(toSnack(snackEntity));
    }

    return snacks;
  }
}
