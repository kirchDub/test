package com.optum.claimsprocessor.services;

import com.optum.PatientSummary;
import com.optum.SubmittedClaim;

public interface ClaimsProcessor {

  public void publishPatientSummary(PatientSummary patientSummary);

  public void publishClaim(SubmittedClaim submittedClaim);
}
