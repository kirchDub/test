exports.convertDate = function(userDate){
    return userDate.substring(2,4) + userDate.substring(5,7) + userDate.substring(8,10);
};

exports.formatDate = function(sDate){
    var dValue = Math.floor((new Date()).getFullYear()/100) + sDate.substring(0, 2) + "-" + sDate.substring(4, 2) + "-" + sDate.substring(4);
    return new Date(dValue);
};

exports.formatAmount = function(sValue){
    var oResult = parseFloat(sValue.substring(0, sValue.length - 2) + "." + sValue.substring(sValue.length - 2)).toFixed(2);

    if (oResult == "NaN"){
        return sValue;
    }

    return oResult;
};
