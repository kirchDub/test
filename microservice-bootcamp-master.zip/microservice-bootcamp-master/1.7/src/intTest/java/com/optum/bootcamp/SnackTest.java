package com.optum.bootcamp;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.when;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.optum.bootcamp.model.Snack;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class SnackTest {

  @BeforeAll
  static void setup() {
    RestAssured.baseURI = Config.baseURI;
    RestAssured.port = Config.port;
    RestAssured.useRelaxedHTTPSValidation();
  }

  @Test
  public void invalidEndpointTest() {
    when().get("/api/not/valid").then().assertThat().statusCode(404);
  }

  @Test
  public void createAndGetSnackByIdTest() {
    String name = "Twix";
    Snack snack = new Snack();
    snack.setName(name);

    // Make a POST request to add a snack to the database and extract the new ID from the response
    Integer id =
        given()
            .contentType(ContentType.JSON)
            .body(snack)
            .when()
            .post("/api/v1/snacks")
            .then()
            .assertThat()
            .statusCode(200)
            .body("id", notNullValue())
            .body("name", equalTo(name))
            .extract()
            .path("id");

    // Make the GET request and check that the response is what we expect
    when()
        .get("/api/v1/snacks/{snackId}", id)
        .then()
        .assertThat()
        .statusCode(200)
        .body("id", equalTo(id))
        .body("name", equalTo(name));

    /* Alternatively, we can run the assertions separately like so:
    Response getResponse = when().get("/api/v1/snacks/{snackId}", id).thenReturn();

    assertThat(getResponse.getStatusCode()).isEqualTo(200);

    Snack getResponseSnack = getResponse.getBody().as(Snack.class);

    assertThat(getResponseSnack.getId()).isEqualTo(id);
    assertThat(getResponseSnack.getName()).isEqualTo(name);
    */
  }
}
