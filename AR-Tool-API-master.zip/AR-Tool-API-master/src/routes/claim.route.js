var express = require('express');
var router = express.Router();
var db = require('../config/db.config.js')
const request = require('request');
var async = require('async');
var unetProcess = require('../controller/unet.js');
const claimProcess = require('../controller/claims.js');


/* Post  */
//claim_search;

router.get('/:load_file_id', function (req, res) {

    res.connection.setTimeout(0);
    console.log("get called in claim");
    const loadFileId = req.params.load_file_id;

    claimProcess.insertAllClaims(loadFileId,res);

   
});

router.get('/unetTest/:load_file_id', function (req, res) {
    try{
    res.connection.setTimeout(0);
    console.log("get called in claim");

    unetProcess.getClaims(req.params.load_file_id);
    res.send({
        status: 202,
        result: 'success',
        response: 'complete'
    })
}catch(error) 
{
    res.send({
        status: 500,
        result: 'failure',
        response: 'error'
    })
}
});



module.exports = router;