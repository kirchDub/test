package com.optum.otu.novice.service.demo.model;

// TODO: Extend the proper interface to make this function as a repository for the MedicationType entity
public interface MedicationTypeRepository {

    // TODO: Add a finder function to find a MedicationType by its typename attribute
}
