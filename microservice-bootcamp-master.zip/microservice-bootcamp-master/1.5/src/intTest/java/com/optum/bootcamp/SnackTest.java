package com.optum.bootcamp;

import static io.restassured.RestAssured.when;
import static org.hamcrest.Matchers.equalTo;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;

public class SnackTest {

  @BeforeAll
  static void setup() {
    RestAssured.baseURI = Config.baseURI;
    RestAssured.port = Config.port;
    RestAssured.useRelaxedHTTPSValidation();
  }

  @Test
  public void getSnackTest() {
    Integer id = 1;
    String name = "Butterfingers";

    // Make the request and check that the response is what we expect
    when()
        .get("/api/v1/snacks/{snackId}", id)
        .then()
        .assertThat()
        .statusCode(200)
        .body("id", equalTo(id))
        .body("name", equalTo(name));

    /* Alternatively, we can run the assertions separately like so:
    Response response = when().get("/api/v1/snacks/{snackId}", id).thenReturn();

    assertThat(response.getStatusCode()).isEqualTo(200);

    Snack snack = response.getBody().as(Snack.class);

    assertThat(snack.getId()).isEqualTo(id);
    assertThat(snack.getName()).isEqualTo(name);
    */
  }
}
