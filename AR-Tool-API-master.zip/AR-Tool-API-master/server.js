var express = require('express');
var http = require('http');
var app = express();
var logger = require('morgan');
var cors = require('cors');
var path = require('path');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var checkAuth = require('./src/config/check-auth.js');
var index = require('./src/routes/index.route.js');
var uploadRoute = require('./src/routes/upload.route.js');
var utils = require('./src/routes/utils.route.js');
var excelheaders = require('./src/routes/headers.route.js');
var claimSearch = require('./src/routes/claim.route.js');
var fileData = require('./src/routes/filedata.route.js');
var attributes = require('./src/routes/attributes.route.js');
var fieldMapping = require('./src/routes/fieldMapping.route.js');


app.server = http.createServer(app);

app.use(logger('dev'));
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', index);
app.use('/api/upload', checkAuth, uploadRoute);
app.use('/api/utils', utils);
app.use('/api/headers', checkAuth, excelheaders);
app.use('/api/claim', checkAuth, claimSearch);
app.use('/api/filedata', checkAuth, fileData);
app.use('/api/attributes', checkAuth, attributes);
app.use('/api/fieldMapping', checkAuth, fieldMapping);




// catch 404 and forward to error handler
app.use(function (req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// CHG0587209 - password change
// Handle CORS Errors
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');

    if (req.method == 'OPTIONS')
    {
        res.header('Access-Control-Allow-Methods', 'PUT, POST, PATCH, DELETE, GET');
        return res.status(200).json({});
    }

    res.setHeader('Content-Type', 'text/html');
    res.end();


    next();
});
// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  // render the error page
  res.status(err.status || 500);
  res.json({
    message: err.message,
    error: err
  });
});

var server = app.listen(8082, function () {

  var host = server.address().address
  var port = server.address().port
  server.setTimeout(1000000);

  console.log("App listening at http://%s:%s", host, port)

})

module.exports = app;
