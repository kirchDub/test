package com.optum.bootcamp.service;

import org.springframework.stereotype.Service;

import com.optum.bootcamp.model.Snack;

@Service
public class SnackService {
  public Snack getSnackById(Integer id) {
    return new Snack(id, "Butterfingers");
  }
}
