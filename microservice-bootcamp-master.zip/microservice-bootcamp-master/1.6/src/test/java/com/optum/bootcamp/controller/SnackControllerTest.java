package com.optum.bootcamp.controller;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.optum.bootcamp.model.Snack;
import com.optum.bootcamp.service.SnackService;

@SpringBootTest
public class SnackControllerTest {

  @Autowired private SnackController snackController;
  @MockBean private SnackService snackService;

  @Test
  public void getSnackByIdTest() {
    Integer id = 1;
    String name = "Butterfingers";
    Snack snackToReturn = new Snack(id, name);

    Mockito.when(snackService.getSnackById(id)).thenReturn(snackToReturn);

    Snack snack = snackController.getSnackById(id);

    assertThat(snack.getId()).isEqualTo(id);
    assertThat(snack.getName()).isEqualTo(name);
  }
}
