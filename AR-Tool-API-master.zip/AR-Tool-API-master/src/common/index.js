var db = require('../config/db.config.js');
var teradata = require('../config/teradata.config.js');
var async = require('async');
const claims = require('../controller/claims');


exports.memberInsert = function (res, response, insertId, filedetailInsertId, cb) {
    var memberdata = response;
    
    for (var i = 0; i < memberdata.length; i++) {
        memberdata[i].load_file_id = insertId;
        memberdata[i].load_file_detail_id = filedetailInsertId + i;
        if(memberdata[i].src_sys_id == 'APF'){
            memberdata[i].lob = 'C&S'
        }
        if(memberdata[i].src_sys_id == 'CES'){
            memberdata[i].lob = 'E&I'
        }
        if(memberdata[i].src_sys_id == 'COS'){
            memberdata[i].lob = 'M&R'
        }
    }

    var excluded = [];
    for (var i in memberdata) {
        if (['AR', 'SH', 'UM', 'SR', 'GR'].indexOf(memberdata[i].src_sys_id) + 1) {
            memberdata[i].status_id = 1;
            memberdata[i].status_comment = 'Excluded by Member Platform';
            excluded.push([memberdata[i].load_file_id, memberdata[i].load_file_detail_id, memberdata[i].status_id, memberdata[i].status_comment]);
        }
    }
    for (var i in memberdata) {
        if (['30500'].indexOf(memberdata[i].src_cust_contr_id) + 1) {
            memberdata[i].status_id = 1;
            memberdata[i].status_comment = 'Excluded Empire Employer Group ';
            excluded.push([memberdata[i].load_file_id, memberdata[i].load_file_detail_id, memberdata[i].status_id, memberdata[i].status_comment]);
        }
    }
    for (var i in memberdata) {
        if (['304000', '303000'].indexOf(memberdata[i].src_cust_contr_id) + 1) {
            memberdata[i].status_id = 1;
            memberdata[i].status_comment = 'Excluded GE Employer Group ';
            excluded.push([memberdata[i].load_file_id, memberdata[i].load_file_detail_id, memberdata[i].status_id, memberdata[i].status_comment]);
        }
    }
    for (var i in memberdata) {
        if (['029421'].indexOf(memberdata[i].src_cust_contr_id) + 1) {
            memberdata[i].status_id = 1;
            memberdata[i].status_comment = 'Excluded Optum/WelMed Group ';
            excluded.push([memberdata[i].load_file_id, memberdata[i].load_file_detail_id, memberdata[i].status_id, memberdata[i].status_comment]);
        }
    }
    for (var i in memberdata) {
        if (['168504', '742546'].indexOf(memberdata[i].src_cust_contr_id) + 1) {
            memberdata[i].status_id = 1;
            memberdata[i].status_comment = 'Excluded UHG Employee Group ';
            excluded.push([memberdata[i].load_file_id, memberdata[i].load_file_detail_id, memberdata[i].status_id, memberdata[i].status_comment]);
        }
    }
    console.log("excludedmembers", excluded);
    var members = [];
    for (var i = 0; i < memberdata.length; i++) {
        members.push([memberdata[i].load_file_id, memberdata[i].load_file_detail_id, memberdata[i].cpin, memberdata[i].src_sys_id, memberdata[i].src_sbscr_id, memberdata[i].src_mbr_id, memberdata[i].src_cust_contr_id, memberdata[i].mbr_pty_id, memberdata[i].fam_nm, memberdata[i].giv_nm, memberdata[i].lob, memberdata[i].dob]);
    }
    // Inserting Excluded members to Status Table
    if (excluded.length > 0) {
        var sql = "INSERT INTO batch_file_detail_status (load_file_id,load_file_detail_id,status_id,status_comment) VALUES ?";
        db.query(sql, [excluded], function (err, result) {
            if (err) throw err;
            else {
                console.log("Completed Status Insert");
            }
        });
    }
    // Inserting Member Records
    var sql = "INSERT INTO batch_file_detail_member (load_file_id,load_file_detail_id,consumer_id, source_system, subscriber_id, member_id, group_policy_number, mbr_pty_id, FAM_NM, GIV_NM, lob, DOB) VALUES ?";
    db.query(sql, [members], function (err, result) {
        if (err) throw err;
        else {
            db.query("select A.load_file_detail_id,B.load_file_detail_member_id,mbr_pty_id,from_date_of_service,prov_tax_id from batch_file_input_detail A, batch_file_detail_member B where A.load_file_detail_id = B.load_file_detail_id and source_system = 'CES' and  A.load_file_id = ?", insertId, function (err, resultt) {

                var unetRecord = JSON.parse(JSON.stringify(resultt));
                if (unetRecord.length > 0) {
                    getUnetDetails(insertId, unetRecord, function (error, response) {
                        db.query("update batch_file_input set status_id=3 where load_file_id=?", insertId, function (err, resultt) {
                            claims.insertAllClaims(insertId,res);
                        });
                        console.log("Completed member insert");
                        // insertClaims(filedetailInsertId, function (er, resp) {
                        cb(null, result);
                        //res.status(200).json({ message: 'Members inserted successfully' });
                        // });
                    });
                }
                else {
                    db.query("update batch_file_input set status_id=3 where load_file_id=?", insertId, function (err, resultt) {
                        claims.insertAllClaims(insertId,res);
                    });
                    cb(null, result);
                    console.log("Completed member insert after callback");
                   //  res.status(200).json({ message: 'Members inserted successfully' });
                }
            });

        }
    });
}

function getUnetDetails(insertId, unetRecord, callback) {
    async.series([
        function (callback) {
            var sql = "CREATE volatile TABLE AR_TOOL_CLAIM_" + insertId + " ( load_file_id integer, load_file_detail_id integer, load_file_detail_member_id integer, mbr_pty_id bigint, dos date, tin varchar(100) ) PRIMARY INDEX(mbr_pty_id) ON COMMIT preserve rows;";
            console.log('sql q' + sql);
            teradata.write(sql)
                .then(function (result) {
                    console.log(result);

                    callback(null, result);
                });

        },
        function (callback) {
            async.eachSeries(unetRecord, function (gname, cb) {
                if (gname.from_date_of_service == "")
                {
                    gname.from_date_of_service  = '1900-01-01';
                }
                var sql = "INSERT INTO AR_TOOL_CLAIM_" + insertId + " (load_file_id,load_file_detail_id,load_file_detail_member_id,mbr_pty_id,TIN,DOS) VALUES (" + insertId + "," + gname.load_file_detail_id + "," + gname.load_file_detail_member_id + "," + gname.mbr_pty_id + ",'" + gname.prov_tax_id + "','" + gname.from_date_of_service + "');"

                teradata.write(sql)
                    .then(function (result) {
                        cb(null, result);
                    });

            }, function (err) {
                // if any of the file processing produced an error, err would equal that error
                if (err) {
                    // One of the iterations produced an error.
                    // All processing will now stop.
                    console.log('A file failed to process');
                } else {
                    console.log('All files have been processed successfully');
                    callback();
                }
            });
        },
        function (callback) {
            var sql = "select A.load_file_id,A.load_file_detail_id,A.load_file_detail_member_id,A.MBR_PTY_ID, " +
                "M.BTH_DT,M.CPIN,M.DEPN_NBR,M.DEPN_SEQ_NUM,M.FAM_NM,M.GIV_NM,M.MIDL_NM,M.REL_CD,M.SRC_MBR_ID,MCE.ADJD_SBSCR_NUM,M.SRC_SYS_CD,M.ORIG_SRC_SYS_CD,MCE.CLM_ENT_DT " +
                ",MCE.CLM_RECV_DT,MCE.ERLY_SRVC_DT,MCE.LT_SRVC_DT,MCE.ORIG_PAY_TM,MCE.ORIG_PAY_DT,MCE.PTNT_ACCT_NUM,MCE.PROC_DT,MCE.SRC_CLM_ID " +
                ",MCE.UDW_ADJD_MCE_ID,MCE.UDW_MED_CLM_ID,PROV.ADJD_PROV_TIN,PROV.NAT_PROV_ID_NUM,PROV.PROV_NM,PROV.SRC_PROV_ID,PROV.PROC_DT,PROV.ORIG_SRC_SYS_CD,PROV.SRC_SYS_CD " +
                ",UNETMAP.SRC_MED_CLM_ID as TOPS_ICN,UNETMAP.CLM_SUFX_CD " +
                "from AR_TOOL_CLAIM_" + insertId + " A join UDWBASESECUREVIEW1.MBR M on A.MBR_PTY_ID = M.MBR_PTY_ID " +
                "join UDWBASESECUREVIEW1.MBR_COV MC " +
                "on M.MBR_PTY_ID = MC.MBR_PTY_ID  " +
                "and M.ROW_EXPIR_DT = '9999-12-31' " +
                "and M.SRC_ROW_STS_CD = 'A' " +
                "and MC.ROW_EXPIR_DT = '9999-12-31' " +
                "and MC.SRC_ROW_STS_CD = 'A' " +
                "and MC.COV_TYP_CD = 'M' " +
                "and A.DOS between MC.COV_EFF_DT and MC.COV_EXPIR_DT " +
                "join UDWBASESECUREVIEW1.ADJD_MCE MCE " +
                "on M.MBR_PTY_ID = MCE.MBR_PTY_ID " +
                "and A.DOS between ERLY_SRVC_DT and LT_SRVC_DT " +
                "and MC.MBR_PTY_ID = MCE.MBR_PTY_ID " +
                "and MCE.SRC_ROW_EXPIR_DT = '9999-12-31' " +
                "and MCE.SRC_ROW_STS_CD = 'A' " +
                "join UDWBASESECUREVIEW1.ADJD_MCE_PROV PROV " +
                "on MCE.UDW_MED_CLM_ID = PROV.UDW_MED_CLM_ID " +
                "and MCE.UDW_ADJD_MCE_ID = PROV.UDW_ADJD_MCE_ID " +
                "and PROV.SRC_ROW_EXPIR_DT = '9999-12-31' " +
                "and PROV.SRC_ROW_STS_CD = 'A' " +
                "and CLM_PROV_ROLE_TYP_CD = 'BILL' " +
                "join UDWBASESECUREVIEW1.ADJD_MCE_UCR_KEY_MAP UNETMAP " +
                "on UNETMAP.UDW_ADJD_MCE_ID = MCE.UDW_ADJD_MCE_ID " +
                "and UNETMAP.UDW_MED_CLM_ID = MCE.UDW_MED_CLM_ID " +
                "where ADJD_PROV_TIN = A.TIN " +
                "and MC.MBR_PTY_ID =  A.MBR_PTY_ID " +
                "and MCE.MBR_PTY_ID = A.MBR_PTY_ID " +
                "and M.MBR_PTY_ID = A.MBR_PTY_ID ;"


            teradata.read(sql)
                .then(function (response) {
                    if (response.length > 0) {
                        insertUnetDetails(response, function (error, response) {
                            callback(null, response);
                        })
                    }
                    else {
                        callback(null, response);
                    }

                });
        },
        function (callback) {
            var sql = "DROP TABLE AR_TOOL_CLAIM_" + insertId + ";";

            teradata.write(sql)
                .then(function (result) {

                    callback(null, result);
                });

        }
    ], function (err, res) { callback(null, "done"); });

}

function insertUnetDetails(claimIDRec, cb) {
    var unetclaim = []
    for (var i = 0; i < claimIDRec.length; i++) {
        unetclaim.push([claimIDRec[i].load_file_id, claimIDRec[i].load_file_detail_id, claimIDRec[i].mbr_pty_id, claimIDRec[i].TOPS_ICN, claimIDRec[i].CLM_SUFX_CD])
    }
    db.query('INSERT INTO  batch_file_unet_ids (load_file_id,load_file_detail_id,mbr_pty_id,tops_icn,tops_suffix) VALUES ?', [unetclaim], function (error, results, fields) {
        if (error) {

            throw error;
            callback(error);
        } else {
            console.log('Claim ID inserted', results);

            cb(null, results);

        }
    });
}

exports.memberSearch = function (res, filedata, insertId, filedetailInsertId) {
    async.series([
        function (callback) {
            var sql = "CREATE volatile TABLE AR_TOOL_" + insertId + " ( excel_row_id integer, sub_id varchar(100), fst_nm varchar(100), lst_nm varchar(100), dob date, dos date, src_sys_id varchar(100), mbr_pty_id varchar(100), cpin varchar(100), giv_nm varchar(100),fam_nm varchar(100),src_sbscr_id varchar(100), src_cust_contr_id varchar(100), src_mbr_id varchar(100), match_step varchar(100) ) PRIMARY INDEX(sub_id) ON COMMIT preserve rows;";
            console.log('sql q' + sql);
            teradata.write(sql)
                .then(function (result) {

                    callback(null, result);
                });

        },
        function (callback) {
            async.eachSeries(filedata, function (gname, cb) {
                if (gname.from_date_of_service == "")
                {
                    gname.from_date_of_service  = '1900-01-01';
                }
                if (gname.patient_dob == "")
                {
                    gname.patient_dob  = '1900-01-01';
                }
                
                var sql = "INSERT INTO AR_TOOL_" + insertId + " (EXCEL_ROW_ID,SUB_ID,FST_NM,LST_NM,DOB,DOS) VALUES ('" + gname.EXCEL_ROW_ID + "','" + gname.subscriber_id + "','" + gname.patient_first_name.replace(/'/g,"\''").split(' ')[0] + "','" + gname.patient_last_name.replace(/'/g,"\''") + "','" + gname.patient_dob + "','" + gname.from_date_of_service + "');"

                teradata.write(sql)
                    .then(function (result) {
                        cb(null, result);
                    });

            }, function (err) {
                // if any of the file processing produced an error, err would equal that error
                if (err) {
                    // One of the iterations produced an error.
                    // All processing will now stop.
                    console.log('A file failed to process');
                } else {
                    console.log('All files have been processed successfully');
                    callback();
                }
            });
        },
        // Subscriber ID, DOB, First Name, Last Name
        function (callback) {
            var sql = "update A " +
                "from " +
                "AR_TOOL_" + insertId + " A " +
                ",( " +
                "select distinct FST_NM,LST_NM,DOS,DOB,SUB_ID from ( " +
                "select FST_NM,LST_NM,DOS,DOB,SUB_ID,count(DISTINCT CPIN) CNT from ( " +
                "select A.FST_NM,A.LST_NM,A.DOS,A.DOB,A.SUB_ID,M.CPIN,M.GIV_NM,M.FAM_NM, M.MBR_PTY_ID,M.SRC_MBR_ID,M.SRC_SBSCR_ID,MC.ORIG_SRC_SYS_CD,MC.ORIG_SRC_CUST_CONTR_ID,MC.COV_TYP_CD from UDWBASESECUREVIEW1.MBR  M " +
                "join UDWBASESECUREVIEW1.MBR_COV MC " +
                "on M.MBR_PTY_ID = MC.MBR_PTY_ID  " +
                "and M.ROW_EXPIR_DT = '9999-12-31' " +
                "and MC.ROW_EXPIR_DT = '9999-12-31' " +
                "and M.SRC_ROW_STS_CD = 'A' " +
                " and MC.SRC_ROW_STS_CD = 'A' " +
                " join UDWBASESECUREVIEW1.MBR_ALT_ID AID " +
                " on M.MBR_PTY_ID = AID.MBR_PTY_ID " +
                " and AID.ROW_EXPIR_DT = '9999-12-31' " +
                " and AID.SRC_ROW_STS_CD = 'A' " +
                " and AID.ALT_ID_TYP_CD = 'AID' " +
                "join AR_TOOL_" + insertId + " A " +
                " on A.FST_NM = M.GIV_NM " +
                "and A.LST_NM = M.FAM_NM " +
                "and A.DOB = M.BTH_DT " +
                "and A.DOS between MC.COV_EFF_DT and MC.COV_EXPIR_DT " +
                "and A.SUB_ID = AID.ALT_ID_VAL " +
                "and A.DOS between AID.BUS_EFF_DT and AID.BUS_EXPIR_DT " +
                "and A.MATCH_STEP is null " +
                " where " +
                " MC.COV_TYP_CD = 'M'  ) R group by FST_NM,LST_NM,DOS,DOB,SUB_ID) S where CNT = 1 ) Q " +
                " ,(select FST_NM,LST_NM,DOS,DOB,SUB_ID,GIV_NM,FAM_NM,BTH_DT,CPIN,MBR_PTY_ID,SRC_MBR_ID,SRC_SBSCR_ID,ORIG_SRC_SYS_CD,ORIG_SRC_CUST_CONTR_ID,COV_TYP_CD from ( " +
                "select A.FST_NM,A.LST_NM,A.DOS,A.DOB,A.SUB_ID,M.GIV_NM,M.FAM_NM,M.BTH_DT,M.CPIN,M.MBR_PTY_ID,M.SRC_MBR_ID,M.SRC_SBSCR_ID,MC.ORIG_SRC_SYS_CD,MC.ORIG_SRC_CUST_CONTR_ID,MC.COV_TYP_CD,ROW_NUMBER() OVER(PARTITION BY A.FST_NM,A.LST_NM,A.DOS,A.DOB,A.SUB_ID ORDER BY M.SRC_SYS_CD, MC.COV_EFF_DT DESC) ROWN  from UDWBASESECUREVIEW1.MBR  M " +
                "join UDWBASESECUREVIEW1.MBR_COV MC " +
                "on M.MBR_PTY_ID = MC.MBR_PTY_ID  " +
                "and M.ROW_EXPIR_DT = '9999-12-31' " +
                "and MC.ROW_EXPIR_DT = '9999-12-31' " +
                "and M.SRC_ROW_STS_CD = 'A' " +
                "and MC.SRC_ROW_STS_CD = 'A' " +
                "join UDWBASESECUREVIEW1.MBR_ALT_ID AID " +
                "on M.MBR_PTY_ID = AID.MBR_PTY_ID " +
                "and AID.ROW_EXPIR_DT = '9999-12-31' " +
                "and AID.SRC_ROW_STS_CD = 'A' " +
                "and AID.ALT_ID_TYP_CD = 'AID' " +
                "join AR_TOOL_" + insertId + " A " +
                "on A.FST_NM = M.GIV_NM " +
                "and A.LST_NM = M.FAM_NM " +
                "and  A.DOB = M.BTH_DT " +
                "and A.DOS between MC.COV_EFF_DT and MC.COV_EXPIR_DT " +
                "and A.SUB_ID = AID.ALT_ID_VAL " +
                "and A.DOS between AID.BUS_EFF_DT and AID.BUS_EXPIR_DT " +
                "and A.MATCH_STEP is null " +
                "where " +
                "MC.COV_TYP_CD = 'M' ) G where ROWN = 1 ) U " +
                "set SRC_MBR_ID = U.SRC_MBR_ID " +
                ", SRC_SYS_ID = U.ORIG_SRC_SYS_CD " +
                ", CPIN = U.CPIN " +
                ", GIV_NM = U.GIV_NM " +
                ", FAM_NM = U.FAM_NM " +
                ", DOB = U.BTH_DT " +
                ", SRC_SBSCR_ID = U.SRC_SBSCR_ID " +
                ", SRC_CUST_CONTR_ID = U.ORIG_SRC_CUST_CONTR_ID " +
                ", MBR_PTY_ID = U.MBR_PTY_ID " +
                ", MATCH_STEP = 'FIRST LAST DOB' " +
                "where " +
                "Q.FST_NM = A.FST_NM " +
                "and Q.LST_NM = A.LST_NM " +
                "and Q.SUB_ID = A.SUB_ID " +
                "and Q.DOB = A.DOB " +
                "and Q.DOS = A.DOS " +
                "and U.FST_NM = A.FST_NM " +
                "and U.LST_NM = A.LST_NM " +
                "and U.SUB_ID = A.SUB_ID " +
                "and U.DOB = A.DOB " +
                "and U.DOS = A.DOS " +
                "and A.MATCH_STEP is null;"


            teradata.write(sql)
                .then(function (result) {

                    callback(null, result);
                });

        },
        // Subscriber ID, DOB
        function (callback) {
            var sql = "update A " +
                "from " +
                "AR_TOOL_" + insertId + " A " +
                ",( " +
                "select distinct FST_NM,LST_NM,DOS,DOB,SUB_ID from ( " +
                "select FST_NM,LST_NM,DOS,DOB,SUB_ID,count(DISTINCT CPIN) CNT from ( " +
                "select A.FST_NM,A.LST_NM,A.DOS,A.DOB,A.SUB_ID,M.GIV_NM,M.FAM_NM,M.BTH_DT,M.CPIN,M.MBR_PTY_ID,M.SRC_MBR_ID,M.SRC_SBSCR_ID,MC.ORIG_SRC_SYS_CD,MC.ORIG_SRC_CUST_CONTR_ID,MC.COV_TYP_CD from UDWBASESECUREVIEW1.MBR  M " +
                "join UDWBASESECUREVIEW1.MBR_COV MC " +
                "on M.MBR_PTY_ID = MC.MBR_PTY_ID  " +
                "and M.ROW_EXPIR_DT = '9999-12-31' " +
                "and MC.ROW_EXPIR_DT = '9999-12-31' " +
                "and M.SRC_ROW_STS_CD = 'A' " +
                " and MC.SRC_ROW_STS_CD = 'A' " +
                " join UDWBASESECUREVIEW1.MBR_ALT_ID AID " +
                " on M.MBR_PTY_ID = AID.MBR_PTY_ID " +
                " and AID.ROW_EXPIR_DT = '9999-12-31' " +
                " and AID.SRC_ROW_STS_CD = 'A' " +
                " and AID.ALT_ID_TYP_CD = 'AID' " +
                "join AR_TOOL_" + insertId + " A " +
                " on A.DOB = M.BTH_DT " +
                "and A.SUB_ID = AID.ALT_ID_VAL " +
                "and A.DOS between AID.BUS_EFF_DT and AID.BUS_EXPIR_DT " +
                "and A.DOS between MC.COV_EFF_DT and MC.COV_EXPIR_DT " +
                "and A.MATCH_STEP is null " +
                " where " +
                " MC.COV_TYP_CD = 'M'  ) R group by FST_NM,LST_NM,DOS,DOB,SUB_ID) S where CNT = 1 ) Q " +
                " ,(select FST_NM,LST_NM,DOS,DOB,SUB_ID,GIV_NM,FAM_NM,BTH_DT,CPIN,MBR_PTY_ID,SRC_MBR_ID,SRC_SBSCR_ID,ORIG_SRC_SYS_CD,ORIG_SRC_CUST_CONTR_ID,COV_TYP_CD from ( " +
                "select A.FST_NM,A.LST_NM,A.DOS,A.DOB,A.SUB_ID,M.GIV_NM,M.FAM_NM,M.BTH_DT,M.CPIN,M.MBR_PTY_ID,M.SRC_MBR_ID,M.SRC_SBSCR_ID,MC.ORIG_SRC_SYS_CD,MC.ORIG_SRC_CUST_CONTR_ID,MC.COV_TYP_CD,ROW_NUMBER() OVER(PARTITION BY A.FST_NM,A.LST_NM,A.DOS,A.DOB,A.SUB_ID ORDER BY M.SRC_SYS_CD, MC.COV_EFF_DT DESC) ROWN  from UDWBASESECUREVIEW1.MBR  M " +
                "join UDWBASESECUREVIEW1.MBR_COV MC " +
                "on M.MBR_PTY_ID = MC.MBR_PTY_ID  " +
                "and M.ROW_EXPIR_DT = '9999-12-31' " +
                "and MC.ROW_EXPIR_DT = '9999-12-31' " +
                "and M.SRC_ROW_STS_CD = 'A' " +
                "and MC.SRC_ROW_STS_CD = 'A' " +
                " join UDWBASESECUREVIEW1.MBR_ALT_ID AID " +
                " on M.MBR_PTY_ID = AID.MBR_PTY_ID " +
                " and AID.ROW_EXPIR_DT = '9999-12-31' " +
                " and AID.SRC_ROW_STS_CD = 'A' " +
                " and AID.ALT_ID_TYP_CD = 'AID' " +
                "join AR_TOOL_" + insertId + " A " +
                " on  A.DOB = M.BTH_DT " +
                "and A.SUB_ID = AID.ALT_ID_VAL " +
                "and A.DOS between AID.BUS_EFF_DT and AID.BUS_EXPIR_DT " +
                "and A.DOS between MC.COV_EFF_DT and MC.COV_EXPIR_DT " +
                "and A.MATCH_STEP is null " +
                "where " +
                "MC.COV_TYP_CD = 'M' ) G where ROWN = 1 ) U " +
                "set SRC_MBR_ID = U.SRC_MBR_ID " +
                ", SRC_SYS_ID = U.ORIG_SRC_SYS_CD " +
                ", CPIN = U.CPIN " +
                ", GIV_NM = U.GIV_NM " +
                ", FAM_NM = U.FAM_NM " +
                ", DOB = U.BTH_DT " +
                ", SRC_SBSCR_ID = U.SRC_SBSCR_ID " +
                ", SRC_CUST_CONTR_ID = U.ORIG_SRC_CUST_CONTR_ID " +
                ", MBR_PTY_ID = U.MBR_PTY_ID " +
                ", MATCH_STEP = 'DOB SUB' " +
                "where " +
                "Q.FST_NM = A.FST_NM " +
                "and Q.LST_NM = A.LST_NM " +
                "and Q.SUB_ID = A.SUB_ID " +
                "and Q.DOB = A.DOB " +
                "and Q.DOS = A.DOS " +
                "and U.FST_NM = A.FST_NM " +
                "and U.LST_NM = A.LST_NM " +
                "and U.SUB_ID = A.SUB_ID " +
                "and U.DOB = A.DOB " +
                "and U.DOS = A.DOS " +
                "and A.MATCH_STEP is null;"

            teradata.write(sql)
                .then(function (result) {

                    callback(null, result);
                });

        },
        // Subscriber ID, First Name
        function (callback) {
            var sql = "update A " +
                "from " +
                "AR_TOOL_" + insertId + " A " +
                ",( " +
                "select distinct FST_NM,LST_NM,DOS,DOB,SUB_ID from ( " +
                "select FST_NM,LST_NM,DOS,DOB,SUB_ID,count(DISTINCT CPIN) CNT from ( " +
                "select A.FST_NM,A.LST_NM,A.DOS,A.DOB,A.SUB_ID,M.GIV_NM,M.FAM_NM,M.BTH_DT,M.CPIN,M.MBR_PTY_ID,M.SRC_MBR_ID,M.SRC_SBSCR_ID,MC.ORIG_SRC_SYS_CD,MC.ORIG_SRC_CUST_CONTR_ID,MC.COV_TYP_CD from UDWBASESECUREVIEW1.MBR  M " +
                "join UDWBASESECUREVIEW1.MBR_COV MC " +
                "on M.MBR_PTY_ID = MC.MBR_PTY_ID  " +
                "and M.ROW_EXPIR_DT = '9999-12-31' " +
                "and MC.ROW_EXPIR_DT = '9999-12-31' " +
                "and M.SRC_ROW_STS_CD = 'A' " +
                " and MC.SRC_ROW_STS_CD = 'A' " +
                " join UDWBASESECUREVIEW1.MBR_ALT_ID AID " +
                " on M.MBR_PTY_ID = AID.MBR_PTY_ID " +
                " and AID.ROW_EXPIR_DT = '9999-12-31' " +
                " and AID.SRC_ROW_STS_CD = 'A' " +
                " and AID.ALT_ID_TYP_CD = 'AID' " +
                "join AR_TOOL_" + insertId + " A " +
                " on A.FST_NM = M.GIV_NM " +
                "and A.DOS between MC.COV_EFF_DT and MC.COV_EXPIR_DT " +
                "and A.SUB_ID = AID.ALT_ID_VAL " +
                "and A.DOS between AID.BUS_EFF_DT and AID.BUS_EXPIR_DT " +
                "and A.MATCH_STEP is null " +
                " where " +
                " MC.COV_TYP_CD = 'M'  ) R group by FST_NM,LST_NM,DOS,DOB,SUB_ID) S where CNT = 1 ) Q " +
                " ,(select FST_NM,LST_NM,DOS,DOB,SUB_ID,GIV_NM,FAM_NM,BTH_DT,CPIN,MBR_PTY_ID,SRC_MBR_ID,SRC_SBSCR_ID,ORIG_SRC_SYS_CD,ORIG_SRC_CUST_CONTR_ID,COV_TYP_CD from ( " +
                "select A.FST_NM,A.LST_NM,A.DOS,A.DOB,A.SUB_ID,M.GIV_NM,M.FAM_NM,M.BTH_DT,M.CPIN,M.MBR_PTY_ID,M.SRC_MBR_ID,M.SRC_SBSCR_ID,MC.ORIG_SRC_SYS_CD,MC.ORIG_SRC_CUST_CONTR_ID,MC.COV_TYP_CD,ROW_NUMBER() OVER(PARTITION BY A.FST_NM,A.LST_NM,A.DOS,A.DOB,A.SUB_ID ORDER BY M.SRC_SYS_CD, MC.COV_EFF_DT DESC) ROWN  from UDWBASESECUREVIEW1.MBR  M " +
                "join UDWBASESECUREVIEW1.MBR_COV MC " +
                "on M.MBR_PTY_ID = MC.MBR_PTY_ID  " +
                "and M.ROW_EXPIR_DT = '9999-12-31' " +
                "and MC.ROW_EXPIR_DT = '9999-12-31' " +
                "and M.SRC_ROW_STS_CD = 'A' " +
                "and MC.SRC_ROW_STS_CD = 'A' " +
                " join UDWBASESECUREVIEW1.MBR_ALT_ID AID " +
                " on M.MBR_PTY_ID = AID.MBR_PTY_ID " +
                " and AID.ROW_EXPIR_DT = '9999-12-31' " +
                " and AID.SRC_ROW_STS_CD = 'A' " +
                " and AID.ALT_ID_TYP_CD = 'AID' " +
                "join AR_TOOL_" + insertId + " A " +
                "on A.FST_NM = M.GIV_NM " +
                "and A.DOS between MC.COV_EFF_DT and MC.COV_EXPIR_DT " +
                "and A.SUB_ID = AID.ALT_ID_VAL " +
                "and A.DOS between AID.BUS_EFF_DT and AID.BUS_EXPIR_DT " +
                "and A.MATCH_STEP is null " +
                "where " +
                "MC.COV_TYP_CD = 'M' ) G where ROWN = 1 ) U " +
                "set SRC_MBR_ID = U.SRC_MBR_ID " +
                ", SRC_SYS_ID = U.ORIG_SRC_SYS_CD " +
                ", CPIN = U.CPIN " +
                ", GIV_NM = U.GIV_NM " +
                ", FAM_NM = U.FAM_NM " +
                ", DOB = U.BTH_DT " +
                ", SRC_SBSCR_ID = U.SRC_SBSCR_ID " +
                ", SRC_CUST_CONTR_ID = U.ORIG_SRC_CUST_CONTR_ID " +
                ", MBR_PTY_ID = U.MBR_PTY_ID " +
                ", MATCH_STEP = 'FIRST LAST DOB' " +
                "where " +
                "Q.FST_NM = A.FST_NM " +
                "and Q.LST_NM = A.LST_NM " +
                "and Q.SUB_ID = A.SUB_ID " +
                "and Q.DOB = A.DOB " +
                "and Q.DOS = A.DOS " +
                "and U.FST_NM = A.FST_NM " +
                "and U.LST_NM = A.LST_NM " +
                "and U.SUB_ID = A.SUB_ID " +
                "and U.DOB = A.DOB " +
                "and U.DOS = A.DOS " +
                "and A.MATCH_STEP is null;"

            teradata.write(sql)
                .then(function (result) {

                    callback(null, result);
                });

        },
        // Subscriber ID(SSN), DOB, First Name, Last Name
        function (callback) {
            var sql = "update A " +
                "from " +
                "AR_TOOL_" + insertId + " A " +
                ",( " +
                "select distinct FST_NM,LST_NM,DOS,DOB,SUB_ID from ( " +
                "select FST_NM,LST_NM,DOS,DOB,SUB_ID,count(DISTINCT CPIN) CNT from ( " +
                "select A.FST_NM,A.LST_NM,A.DOS,A.DOB,A.SUB_ID,M.GIV_NM,M.FAM_NM,M.BTH_DT,M.CPIN,M.MBR_PTY_ID,M.SRC_MBR_ID,M.SRC_SBSCR_ID,MC.ORIG_SRC_SYS_CD,MC.ORIG_SRC_CUST_CONTR_ID,MC.COV_TYP_CD from UDWBASESECUREVIEW1.MBR  M " +
                "join UDWBASESECUREVIEW1.MBR_COV MC " +
                "on M.MBR_PTY_ID = MC.MBR_PTY_ID  " +
                "and M.ROW_EXPIR_DT = '9999-12-31' " +
                "and MC.ROW_EXPIR_DT = '9999-12-31' " +
                "and M.SRC_ROW_STS_CD = 'A' " +
                " and MC.SRC_ROW_STS_CD = 'A' " +
                "join AR_TOOL_" + insertId + " A " +
                " on A.FST_NM = M.GIV_NM " +
                "and A.LST_NM = M.FAM_NM " +
                "and A.DOB = M.BTH_DT " +
                "and A.DOS between MC.COV_EFF_DT and MC.COV_EXPIR_DT " +
                "and A.SUB_ID = M.SSN " +
                "and A.MATCH_STEP is null " +
                " where " +
                " MC.COV_TYP_CD = 'M'  ) R group by FST_NM,LST_NM,DOS,DOB,SUB_ID) S where CNT = 1 ) Q " +
                " ,(select FST_NM,LST_NM,DOS,DOB,SUB_ID,GIV_NM,FAM_NM,BTH_DT,CPIN,MBR_PTY_ID,SRC_MBR_ID,SRC_SBSCR_ID,ORIG_SRC_SYS_CD,ORIG_SRC_CUST_CONTR_ID,COV_TYP_CD from ( " +
                "select A.FST_NM,A.LST_NM,A.DOS,A.DOB,A.SUB_ID,M.GIV_NM,M.FAM_NM,M.BTH_DT,M.CPIN,M.MBR_PTY_ID,M.SRC_MBR_ID,M.SRC_SBSCR_ID,MC.ORIG_SRC_SYS_CD,MC.ORIG_SRC_CUST_CONTR_ID,MC.COV_TYP_CD,ROW_NUMBER() OVER(PARTITION BY A.FST_NM,A.LST_NM,A.DOS,A.DOB,A.SUB_ID ORDER BY M.SRC_SYS_CD, MC.COV_EFF_DT DESC) ROWN  from UDWBASESECUREVIEW1.MBR  M " +
                "join UDWBASESECUREVIEW1.MBR_COV MC " +
                "on M.MBR_PTY_ID = MC.MBR_PTY_ID  " +
                "and M.ROW_EXPIR_DT = '9999-12-31' " +
                "and MC.ROW_EXPIR_DT = '9999-12-31' " +
                "and M.SRC_ROW_STS_CD = 'A' " +
                "and MC.SRC_ROW_STS_CD = 'A' " +
                "join AR_TOOL_" + insertId + " A " +
                "on A.FST_NM = M.GIV_NM " +
                "and A.LST_NM = M.FAM_NM " +
                "and  A.DOB = M.BTH_DT " +
                "and A.DOS between MC.COV_EFF_DT and MC.COV_EXPIR_DT " +
                "and A.SUB_ID = M.SSN " +
                "and A.MATCH_STEP is null " +
                "where " +
                "MC.COV_TYP_CD = 'M' ) G where ROWN = 1 ) U " +
                "set SRC_MBR_ID = U.SRC_MBR_ID " +
                ", SRC_SYS_ID = U.ORIG_SRC_SYS_CD " +
                ", CPIN = U.CPIN " +
                ", GIV_NM = U.GIV_NM " +
                ", FAM_NM = U.FAM_NM " +
                ", DOB = U.BTH_DT " +
                ", SRC_SBSCR_ID = U.SRC_SBSCR_ID " +
                ", SRC_CUST_CONTR_ID = U.ORIG_SRC_CUST_CONTR_ID " +
                ", MBR_PTY_ID = U.MBR_PTY_ID " +
                ", MATCH_STEP = 'FIRST LAST DOB' " +
                "where " +
                "Q.FST_NM = A.FST_NM " +
                "and Q.LST_NM = A.LST_NM " +
                "and Q.SUB_ID = A.SUB_ID " +
                "and Q.DOB = A.DOB " +
                "and Q.DOS = A.DOS " +
                "and U.FST_NM = A.FST_NM " +
                "and U.LST_NM = A.LST_NM " +
                "and U.SUB_ID = A.SUB_ID " +
                "and U.DOB = A.DOB " +
                "and U.DOS = A.DOS " +
                "and A.MATCH_STEP is null;"

            teradata.write(sql)
                .then(function (result) {

                    callback(null, result);
                });

        },
        // Subscriber ID(SSN), DOB
        function (callback) {
            var sql = "update A " +
                "from " +
                "AR_TOOL_" + insertId + " A " +
                ",( " +
                "select distinct FST_NM,LST_NM,DOS,DOB,SUB_ID from ( " +
                "select FST_NM,LST_NM,DOS,DOB,SUB_ID,count(DISTINCT CPIN) CNT from ( " +
                "select A.FST_NM,A.LST_NM,A.DOS,A.DOB,A.SUB_ID,M.GIV_NM,M.FAM_NM,M.BTH_DT,M.CPIN,M.MBR_PTY_ID,M.SRC_MBR_ID,M.SRC_SBSCR_ID,MC.ORIG_SRC_SYS_CD,MC.ORIG_SRC_CUST_CONTR_ID,MC.COV_TYP_CD from UDWBASESECUREVIEW1.MBR  M " +
                "join UDWBASESECUREVIEW1.MBR_COV MC " +
                "on M.MBR_PTY_ID = MC.MBR_PTY_ID  " +
                "and M.ROW_EXPIR_DT = '9999-12-31' " +
                "and MC.ROW_EXPIR_DT = '9999-12-31' " +
                "and M.SRC_ROW_STS_CD = 'A' " +
                " and MC.SRC_ROW_STS_CD = 'A' " +
                "join AR_TOOL_" + insertId + " A " +
                " on A.DOB = M.BTH_DT " +
                "and A.SUB_ID = M.SSN " +
                "and A.DOS between MC.COV_EFF_DT and MC.COV_EXPIR_DT " +
                "and A.MATCH_STEP is null " +
                " where " +
                " MC.COV_TYP_CD = 'M'  ) R group by FST_NM,LST_NM,DOS,DOB,SUB_ID) S where CNT = 1 ) Q " +
                " ,(select FST_NM,LST_NM,DOS,DOB,SUB_ID,GIV_NM,FAM_NM,BTH_DT,CPIN,MBR_PTY_ID,SRC_MBR_ID,SRC_SBSCR_ID,ORIG_SRC_SYS_CD,ORIG_SRC_CUST_CONTR_ID,COV_TYP_CD from ( " +
                "select A.FST_NM,A.LST_NM,A.DOS,A.DOB,A.SUB_ID,M.GIV_NM,M.FAM_NM,M.BTH_DT,M.CPIN,M.MBR_PTY_ID,M.SRC_MBR_ID,M.SRC_SBSCR_ID,MC.ORIG_SRC_SYS_CD,MC.ORIG_SRC_CUST_CONTR_ID,MC.COV_TYP_CD,ROW_NUMBER() OVER(PARTITION BY A.FST_NM,A.LST_NM,A.DOS,A.DOB,A.SUB_ID ORDER BY M.SRC_SYS_CD, MC.COV_EFF_DT DESC) ROWN  from UDWBASESECUREVIEW1.MBR  M " +
                "join UDWBASESECUREVIEW1.MBR_COV MC " +
                "on M.MBR_PTY_ID = MC.MBR_PTY_ID  " +
                "and M.ROW_EXPIR_DT = '9999-12-31' " +
                "and MC.ROW_EXPIR_DT = '9999-12-31' " +
                "and M.SRC_ROW_STS_CD = 'A' " +
                "and MC.SRC_ROW_STS_CD = 'A' " +
                "join AR_TOOL_" + insertId + " A " +
                " on  A.DOB = M.BTH_DT " +
                "and A.SUB_ID = M.SSN " +
                "and A.DOS between MC.COV_EFF_DT and MC.COV_EXPIR_DT " +
                "and A.MATCH_STEP is null " +
                "where " +
                "MC.COV_TYP_CD = 'M' ) G where ROWN = 1 ) U " +
                "set SRC_MBR_ID = U.SRC_MBR_ID " +
                ", SRC_SYS_ID = U.ORIG_SRC_SYS_CD " +
                ", CPIN = U.CPIN " +
                ", GIV_NM = U.GIV_NM " +
                ", FAM_NM = U.FAM_NM " +
                ", DOB = U.BTH_DT " +
                ", SRC_SBSCR_ID = U.SRC_SBSCR_ID " +
                ", SRC_CUST_CONTR_ID = U.ORIG_SRC_CUST_CONTR_ID " +
                ", MBR_PTY_ID = U.MBR_PTY_ID " +
                ", MATCH_STEP = 'DOB SUB' " +
                "where " +
                "Q.FST_NM = A.FST_NM " +
                "and Q.LST_NM = A.LST_NM " +
                "and Q.SUB_ID = A.SUB_ID " +
                "and Q.DOB = A.DOB " +
                "and Q.DOS = A.DOS " +
                "and U.FST_NM = A.FST_NM " +
                "and U.LST_NM = A.LST_NM " +
                "and U.SUB_ID = A.SUB_ID " +
                "and U.DOB = A.DOB " +
                "and U.DOS = A.DOS " +
                "and A.MATCH_STEP is null;"

            teradata.write(sql)
                .then(function (result) {

                    callback(null, result);
                });

        },
        // Subscriber ID(SSN), First Name
        function (callback) {
            var sql = "update A " +
                "from " +
                "AR_TOOL_" + insertId + " A " +
                ",( " +
                "select distinct FST_NM,LST_NM,DOS,DOB,SUB_ID from ( " +
                "select FST_NM,LST_NM,DOS,DOB,SUB_ID,count(DISTINCT CPIN) CNT from ( " +
                "select A.FST_NM,A.LST_NM,A.DOS,A.DOB,A.SUB_ID,M.GIV_NM,M.FAM_NM,M.BTH_DT,M.CPIN,M.MBR_PTY_ID,M.SRC_MBR_ID,M.SRC_SBSCR_ID,MC.ORIG_SRC_SYS_CD,MC.ORIG_SRC_CUST_CONTR_ID,MC.COV_TYP_CD from UDWBASESECUREVIEW1.MBR  M " +
                "join UDWBASESECUREVIEW1.MBR_COV MC " +
                "on M.MBR_PTY_ID = MC.MBR_PTY_ID  " +
                "and M.ROW_EXPIR_DT = '9999-12-31' " +
                "and MC.ROW_EXPIR_DT = '9999-12-31' " +
                "and M.SRC_ROW_STS_CD = 'A' " +
                " and MC.SRC_ROW_STS_CD = 'A' " +
                "join AR_TOOL_" + insertId + " A " +
                " on A.FST_NM = M.GIV_NM " +
                "and A.DOS between MC.COV_EFF_DT and MC.COV_EXPIR_DT " +
                "and A.SUB_ID = M.SSN " +
                "and A.MATCH_STEP is null " +
                " where " +
                " MC.COV_TYP_CD = 'M'  ) R group by FST_NM,LST_NM,DOS,DOB,SUB_ID) S where CNT = 1 ) Q " +
                " ,(select FST_NM,LST_NM,DOS,DOB,SUB_ID,GIV_NM,FAM_NM,BTH_DT,CPIN,MBR_PTY_ID,SRC_MBR_ID,SRC_SBSCR_ID,ORIG_SRC_SYS_CD,ORIG_SRC_CUST_CONTR_ID,COV_TYP_CD from ( " +
                "select A.FST_NM,A.LST_NM,A.DOS,A.DOB,A.SUB_ID,M.GIV_NM,M.FAM_NM,M.BTH_DT,M.CPIN,M.MBR_PTY_ID,M.SRC_MBR_ID,M.SRC_SBSCR_ID,MC.ORIG_SRC_SYS_CD,MC.ORIG_SRC_CUST_CONTR_ID,MC.COV_TYP_CD,ROW_NUMBER() OVER(PARTITION BY A.FST_NM,A.LST_NM,A.DOS,A.DOB,A.SUB_ID ORDER BY M.SRC_SYS_CD, MC.COV_EFF_DT DESC) ROWN  from UDWBASESECUREVIEW1.MBR  M " +
                "join UDWBASESECUREVIEW1.MBR_COV MC " +
                "on M.MBR_PTY_ID = MC.MBR_PTY_ID  " +
                "and M.ROW_EXPIR_DT = '9999-12-31' " +
                "and MC.ROW_EXPIR_DT = '9999-12-31' " +
                "and M.SRC_ROW_STS_CD = 'A' " +
                "and MC.SRC_ROW_STS_CD = 'A' " +
                "join AR_TOOL_" + insertId + " A " +
                "on A.FST_NM = M.GIV_NM " +
                "and A.DOS between MC.COV_EFF_DT and MC.COV_EXPIR_DT " +
                "and A.SUB_ID = M.SSN " +
                "and A.MATCH_STEP is null " +
                "where " +
                "MC.COV_TYP_CD = 'M' ) G where ROWN = 1 ) U " +
                "set SRC_MBR_ID = U.SRC_MBR_ID " +
                ", SRC_SYS_ID = U.ORIG_SRC_SYS_CD " +
                ", CPIN = U.CPIN " +
                ", GIV_NM = U.GIV_NM " +
                ", FAM_NM = U.FAM_NM " +
                ", DOB = U.BTH_DT " +
                ", SRC_SBSCR_ID = U.SRC_SBSCR_ID " +
                ", SRC_CUST_CONTR_ID = U.ORIG_SRC_CUST_CONTR_ID " +
                ", MBR_PTY_ID = U.MBR_PTY_ID " +
                ", MATCH_STEP = 'FIRST LAST DOB' " +
                "where " +
                "Q.FST_NM = A.FST_NM " +
                "and Q.LST_NM = A.LST_NM " +
                "and Q.SUB_ID = A.SUB_ID " +
                "and Q.DOB = A.DOB " +
                "and Q.DOS = A.DOS " +
                "and U.FST_NM = A.FST_NM " +
                "and U.LST_NM = A.LST_NM " +
                "and U.SUB_ID = A.SUB_ID " +
                "and U.DOB = A.DOB " +
                "and U.DOS = A.DOS " +
                "and A.MATCH_STEP is null;"

            teradata.write(sql)
                .then(function (result) {

                    callback(null, result);
                });

        },
        // First Name, Last Name and DOB
        function (callback) {
            var sql = "update A " +
                "from " +
                "AR_TOOL_" + insertId + " A " +
                ",( " +
                "select distinct FST_NM,LST_NM,DOS,DOB,SUB_ID from ( " +
                "select FST_NM,LST_NM,DOS,DOB,SUB_ID,count(DISTINCT CPIN) CNT from ( " +
                "select A.FST_NM,A.LST_NM,A.DOS,A.DOB,A.SUB_ID,M.GIV_NM,M.FAM_NM,M.BTH_DT,M.CPIN,M.MBR_PTY_ID,M.SRC_MBR_ID,M.SRC_SBSCR_ID,MC.ORIG_SRC_SYS_CD,MC.ORIG_SRC_CUST_CONTR_ID,MC.COV_TYP_CD from UDWBASESECUREVIEW1.MBR  M " +
                "join UDWBASESECUREVIEW1.MBR_COV MC " +
                "on M.MBR_PTY_ID = MC.MBR_PTY_ID  " +
                "and M.ROW_EXPIR_DT = '9999-12-31' " +
                "and MC.ROW_EXPIR_DT = '9999-12-31' " +
                "and M.SRC_ROW_STS_CD = 'A' " +
                " and MC.SRC_ROW_STS_CD = 'A' " +
                "join AR_TOOL_" + insertId + " A " +
                " on A.FST_NM = M.GIV_NM " +
                "and A.LST_NM = M.FAM_NM " +
                "and A.DOB = M.BTH_DT " +
                "and A.DOS between MC.COV_EFF_DT and MC.COV_EXPIR_DT " +
                "and A.MATCH_STEP is null " +
                " where " +
                " MC.COV_TYP_CD = 'M'  ) R group by FST_NM,LST_NM,DOS,DOB,SUB_ID) S where CNT = 1 ) Q " +
                " ,(select FST_NM,LST_NM,DOS,DOB,SUB_ID,MBR_PTY_ID,GIV_NM,FAM_NM,CPIN,SRC_MBR_ID,SRC_SBSCR_ID,ORIG_SRC_SYS_CD,ORIG_SRC_CUST_CONTR_ID,COV_TYP_CD from ( " +
                "select A.FST_NM,A.LST_NM,A.DOS,A.DOB,A.SUB_ID,M.GIV_NM,M.FAM_NM,M.BTH_DT,M.CPIN,M.MBR_PTY_ID,M.SRC_MBR_ID,M.SRC_SBSCR_ID,MC.ORIG_SRC_SYS_CD,MC.ORIG_SRC_CUST_CONTR_ID,MC.COV_TYP_CD,ROW_NUMBER() OVER(PARTITION BY A.FST_NM,A.LST_NM,A.DOS,A.DOB,A.SUB_ID ORDER BY M.SRC_SYS_CD, MC.COV_EFF_DT DESC) ROWN  from UDWBASESECUREVIEW1.MBR  M " +
                "join UDWBASESECUREVIEW1.MBR_COV MC " +
                "on M.MBR_PTY_ID = MC.MBR_PTY_ID  " +
                "and M.ROW_EXPIR_DT = '9999-12-31' " +
                "and MC.ROW_EXPIR_DT = '9999-12-31' " +
                "and M.SRC_ROW_STS_CD = 'A' " +
                "and MC.SRC_ROW_STS_CD = 'A' " +
                "join AR_TOOL_" + insertId + " A " +
                "on A.FST_NM = M.GIV_NM " +
                "and A.LST_NM = M.FAM_NM " +
                "and  A.DOB = M.BTH_DT " +
                "and A.DOS between MC.COV_EFF_DT and MC.COV_EXPIR_DT " +
                "and A.MATCH_STEP is null " +
                "where " +
                "MC.COV_TYP_CD = 'M' ) G where ROWN = 1 ) U " +
                "set SRC_MBR_ID = U.SRC_MBR_ID " +
                ", SRC_SYS_ID = U.ORIG_SRC_SYS_CD " +
                ", CPIN = U.CPIN " +
                ", GIV_NM = U.GIV_NM " +
                ", FAM_NM = U.FAM_NM " +
                ", SRC_SBSCR_ID = U.SRC_SBSCR_ID " +
                ", SRC_CUST_CONTR_ID = U.ORIG_SRC_CUST_CONTR_ID " +
                ", MBR_PTY_ID = U.MBR_PTY_ID " +
                ", MATCH_STEP = 'FIRST LAST DOB' " +
                "where " +
                "Q.FST_NM = A.FST_NM " +
                "and Q.LST_NM = A.LST_NM " +
                "and Q.SUB_ID = A.SUB_ID " +
                "and Q.DOB = A.DOB " +
                "and Q.DOS = A.DOS " +
                "and U.FST_NM = A.FST_NM " +
                "and U.LST_NM = A.LST_NM " +
                "and U.SUB_ID = A.SUB_ID " +
                "and U.DOB = A.DOB " +
                "and U.DOS = A.DOS " +
                "and A.MATCH_STEP is null;"

            teradata.write(sql)
                .then(function (result) {

                    callback(null, result);
                });

        },
        function (callback) {
            var sql = "select * from AR_TOOL_" + insertId + " ORDER BY excel_row_id ASC;";
            console.log('sql q' + sql);
            teradata.read(sql)
                .then(function (response) {
                    if (response.length > 0) {
                        exports.memberInsert(res, response, insertId, filedetailInsertId, function (error, response) {
                            callback(null, response);
                        })
                    }
                    else {
                        callback(null, response);
                    }
                });
        },
        function (callback) {
            var sql = "DROP TABLE AR_TOOL_" + insertId + ";";

            teradata.write(sql)
                .then(function (result) {

                    callback(null, result);
                });

        }
    ])
}
