# Elasticsearch Architecture

## Node Types

An Elastic cluster contains many different node types. All these nodes types are needed and work together to create a functional cluster.

### Master

The master node is responsible for lightweight cluster-wide actions such as creating or deleting an index, tracking 
which nodes are part of the cluster, and deciding which shards to allocate to which nodes. It is important for cluster
health to have a stable master node.

Ref: https://www.elastic.co/guide/en/elasticsearch/reference/current/modules-node.html#master-node

### Coordinator

If you take away the ability to be able to handle master duties, to hold data, and pre-process documents, then you are left 
with a coordinating node that can only route requests, handle the search reduce phase, and distribute bulk indexing. 
Essentially, coordinating only nodes behave as smart load balancers.

Coordinating only nodes can benefit large clusters by offloading the coordinating node role from data and master-eligible 
nodes. They join the cluster and receive the full cluster state, like every other node, and they use the cluster state to 
route requests directly to the appropriate place(s).

Coordinator nodes are completely stateless and can leave and join the cluster without any data loss or impact. 

Ref: https://www.elastic.co/guide/en/elasticsearch/reference/current/modules-node.html#coordinating-only-node

### Data

Data nodes hold the shards that contain the documents you have indexed. Data nodes handle data related operations like CRUD, 
search, and aggregations. These operations are I/O-, memory-, and CPU-intensive. It is important to monitor these resources 
and to add more data nodes if they are overloaded.

The main benefit of having dedicated data nodes is the separation of the master and data roles.

Ref:  https://www.elastic.co/guide/en/elasticsearch/reference/current/modules-node.html#data-node

### Others

There are other types of nodes like Ingest, Machine learning, and Remote-eligibile however these types are typically not
used unless on very specialized clusters. 

Refs:
* https://www.elastic.co/guide/en/elasticsearch/reference/current/modules-node.html#node-ingest-node
* https://www.elastic.co/guide/en/elasticsearch/reference/current/modules-node.html#ml-node
* https://www.elastic.co/guide/en/elasticsearch/reference/current/modules-node.html#remote-node


### All-in-One

By default Elasticsearch configures all nodes to be Master, Coordinator, and Data nodes. All-in-one nodes are suitable
for smaller clusters usually less than 5 nodes and low throughput. 

However once a cluster needs more than 5 nodes it is recommended to have dedicated nodes for each function. This will
allow the cluster to have a higher throughput and give the ability to scale each function independently.

## Examples

### All-in-One Cluster

Bellow is an example of a cluster where nodes are using the default all-in-one configuration.

![ES Arch Simple](./imgs/elasticsearch_architecture_simple.svg)

### Dedicated Node Cluster

Bellow is an example of a cluster where we have dedicated nodes for Master, Coordinator, and Data.

![ES Arch Advanced](./imgs/elasticsearch_architecture_advanced.svg)

## Indicies and Shards

In Elasticsearch documents are stored in Indecies (plural of Index). An Index is similar to a database from Cassandra or 
other NoSQL like systems. An Index is schema-less* and can hold documents that have different fields.

When creating an index the number of shards need to be specified. Shards are were the data is actually stored. By default 
there will be 1 additional replica of a shard for HA. If a node dies that is storing the shard another node will have it's 
replica and can still serve requests.

It is recommended to set the shard replicas to 2 so there are 3 copies of the shard in total. This will prevent split
brain issues during node and network failures.

Determining the number of shards per index can be very complex and depends on the type of data, number of data nodes, 
performance needed and more. It is recommended to check out this blog post and it's references for more information https://www.elastic.co/blog/how-many-shards-should-i-have-in-my-elasticsearch-cluster

\* A "schema" can still be specified via [Mappings](https://www.elastic.co/guide/en/elasticsearch/reference/current/mapping.html)

![Indicies and Shards](./imgs/elasticsearch_architecture_indices_shards.svg)
