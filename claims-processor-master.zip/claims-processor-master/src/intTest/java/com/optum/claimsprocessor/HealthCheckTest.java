package com.optum.claimsprocessor;

import static io.restassured.RestAssured.when;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;

class HealthCheckTest {

  @BeforeAll
  static void setup() {
    RestAssured.baseURI = Config.baseURI;
    RestAssured.port = Config.port;
    // ignore SSL handshake errors
    RestAssured.useRelaxedHTTPSValidation();
  }

  @Test
  void testHealthCheck() {
    when()
        .request("GET", "/api/actuator/health")
        .then()
        .statusCode(200)
        .body(Matchers.containsString("\"status\":\"UP\""));
  }
}
