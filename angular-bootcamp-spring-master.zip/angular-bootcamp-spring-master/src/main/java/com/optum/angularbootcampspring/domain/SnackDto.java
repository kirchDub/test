package com.optum.angularbootcampspring.domain;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

@Data
public class SnackDto implements Serializable {

    private int id;

    @NotBlank
    private String name;

    @NotBlank
    private String review;

    @NotNull
    private SnackTypes type;

    private int rating;

    private NutritionFactsDto nutritionFacts;

    private List<IngredientDto> ingredients;

}
