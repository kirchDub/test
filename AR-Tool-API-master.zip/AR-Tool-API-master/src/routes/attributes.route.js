var express = require('express');
var router = express.Router();
var db = require('../config/db.config.js');



router.get('/', function (req, res) {
    try{
    db.query('select * from batch_file_field order by seq_nbr', function (err, records, fields) {

        if (err) throw err;
        else {
            if (records.length > 0) {
                res.send({
                    status: 200,
                    result: 'success',
                    response: records
                })
            }
            else {
                res.send({
                    status: 404,
                    result: 'failure',
                    response: 'no records found'
                })
            }

        }


    })
}catch(error) 
{
    res.send({
        status: 500,
        result: 'failure',
        response: 'error'
    })
}
})

module.exports = router;