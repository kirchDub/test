const ohttp = require('../http');
const x2j = require('xml2js');
var express = require('express');
var router = express.Router();
var db = require('../config/db.config.js')
const requestt = require('request');
var async = require('async');
const commonLib = require('../commonLib');


exports.insertCosmosClaims = function (load_file_id, cb) {
    console.log("Getting file details and file data");
    //let quer = "select * from batch_file_input_detail b2 where b2.load_file_detail_id = " + file_detail_id;

    getLatestFileData(load_file_id, function (err, fileRecords) {

        async.eachSeries(fileRecords, function (fileData, callback) {
            async.waterfall([function (callbk) {
                callbk(null, fileData.load_file_detail_id)
            },
                getMemberRecord,
                getCosmosCZ610Inquiry,
                getClaimInfo,
            function (memberRecords, mrResult, call) {
                async.eachSeries(mrResult, function (claim, callk) {
                    async.waterfall([
                        function (call) { call(null, memberRecords, claim) },
                        getCosmosCL611Inquiry,
                        getMRClaimInfo,
                        insertClaimRecord], function (err, result) {
                            callk(null, "done");
                        });
                }, function (err, res) {
                    call(null, "done");
                });
            }

            ], function (err, res) { callback(null, "Done"); });
        }, function (err, result) {
            cb(null, "done");
        });

    });

}

function getLatestFileData(load_file_id, callback) {
    let quer = "select * from batch_file_input_detail b2 where b2.load_file_id = ?";
    // let quer = "select * from batch_file_input_detail b2 where b2.load_file_id = 903";

    db.query(quer, load_file_id, function (err, fileData, fields) {
        if (err) {
            throw err;
        } else {
            fileData = JSON.parse(JSON.stringify(fileData));
            callback(null, fileData);
        }
    });

}

function getMemberRecord(file_detail_id, callback) {
    var sql = "SELECT b2.prov_tax_id AS tin,b2.subscriber_id,b2.from_date_of_service AS dos,b1.member_id,b1.mbr_pty_id,b2.load_file_id,b2.load_file_detail_id,b1.source_system,b1.load_file_detail_member_id, b1.group_policy_number FROM batch_file_detail_member b1 JOIN batch_file_input_detail b2 ON b1.load_file_detail_id = b2.load_file_detail_id WHERE b1.source_system='COS' and b2.load_file_detail_id=" + file_detail_id;

    db.query(sql, function (err, memRecord, fields) {
        if (err) {
            console.log("error getting member record ", err);
            throw err;
        } else {
            memRecord = JSON.parse(JSON.stringify(memRecord));
            if (memRecord && memRecord.length > 0) {

                callback(null, memRecord);
            } else {
                callback("no records");
            }
        }
    });
}

function getCosmosCZ610Inquiry(memberRecords, callback) {
    try{
        var data = '{ "appKey": "l7xx58ae7a31e44a49018877d4991162cbec","secretKey": "eaa1fb2fbafe42079a60f3d1f5028988"}';
        var json_obj = JSON.parse(data);
        requestt.post({
            headers: {
                'content-type': 'application/json', 'Accept': 'application/json', 'charset': 'utf-8',
                'Access-Control-Allow-Origin': '*',
            },
            url: process.env.COSMOS_URL+':4430/api/qsd/jwt/token',
            body: json_obj,
            rejectUnauthorized: false,
            json: true
        }, function (error, response, body) {
            var details = JSON.parse('{"userCode": "", "grpNbr": "","subsNbr": "","depNbr": "","fdos_YYMMDD": "","ldos_YYMMDD": "","prvNbr_TIN": "","division": "","searchType": "","claimType": "","daysThreshold": 0}');
            details.userCode = "90558";
            details.grpNbr = memberRecords[0].member_id.substring(3, 8);
            details.subsNbr = memberRecords[0].member_id.substring(8, 17);
            details.depNbr = memberRecords[0].member_id.substring(17, 19);
            details.fdos_YYMMDD = commonLib.convertDate(memberRecords[0].dos);
            details.ldos_YYMMDD = commonLib.convertDate(memberRecords[0].dos);
            details.prvNbr_TIN = memberRecords[0].tin;
            details.division = memberRecords[0].member_id.substring(0, 3);
            details.searchType = "1";
            details.claimType = "A";
            console.log('CZ610 BODY ', JSON.stringify(details));
            if (error == null) {
                requestt.post({
                    headers: {
                        'content-type': 'application/json', 'Accept': 'application/xml',
                        'Access-Control-Allow-Origin': '*', 'Actor': 'PDAT', 'Authorization': body
                    },
                    url: process.env.COSMOS_URL+':443/api/qsd/cosmos/v1.0/cz610/claims/read',
                    body: details,
                    timeout: 3000,
                    rejectUnauthorized: false,
                    requestCert: false,
                    agent: false,
                    json: true
                }, function (error, response, body) {

                    callback(null, memberRecords, body);
                });
            }
            else {
                callback({
                    error
                });
            }

        });
    }catch(error) 
    {
        callback({
            error
        });
    }
}

function getClaimInfo(memberRecords, body, callback) {


    if (body == undefined) {
        callback("no records");
    }
    else {

        var xmlData = body.replace('<?xml version="1.0" encoding="UTF-8"?>', '').replace('<PAGE-COUNT Value="1" />', '').replace('<PAGE1>', '')
            .replace('</PAGE1>', '').replace('<PAGE-COUNT Value="2" />', '').replace('<PAGE2>', '').replace('</PAGE2>', '');
        x2j.parseString(xmlData, {}, function (err, result) {
            if (result != undefined) {

                var iTotalLineItems = result['Root']['CZ610-O-DATA-OCCURX'][0]['$']['Occurrence'];

                var iLineNumber = 0;
                var mrResult = [];
                for (var iIdx = 0; iIdx <= iTotalLineItems - 1; iIdx++) {
                    iLineNumber = parseInt(result['Root']['CZ610-O-DATA-OCCURX'][0]['CZ610-O-AUDIT-NBR'][iIdx]['$']['Value']);
                    if (!isNaN(iLineNumber) && iLineNumber > 0) {
                        var oInfo = {};
                        oInfo.recordType = result['Root']['CZ610-O-DATA-OCCURX'][0]['CZ610-O-RECORD-TYPE'][iIdx]['$']['Value'];
                        oInfo.clmAuditNbr = result['Root']['CZ610-O-DATA-OCCURX'][0]['CZ610-O-AUDIT-NBR'][iIdx]['$']['Value'];
                        oInfo.subAuditNbr = result['Root']['CZ610-O-DATA-OCCURX'][0]['CZ610-O-ADJ-SEQ-NBR'][iIdx]['$']['Value'];
                        mrResult.push(oInfo);

                    }
                }
                callback(null, memberRecords, mrResult);
            }
            else {
                callback("no records");
            }
        })
    }

};





function getCosmosCL611Inquiry(memberRecords, claim, callback) {
    try{
        var data = '{ "appKey": "l7xx58ae7a31e44a49018877d4991162cbec","secretKey": "eaa1fb2fbafe42079a60f3d1f5028988"}';
        var json_obj = JSON.parse(data);
        var claimData;
        requestt.post({
            headers: {
                'content-type': 'application/json', 'Accept': 'application/json', 'charset': 'utf-8',
                'Access-Control-Allow-Origin': '*',
            },
            url: process.env.COSMOS_URL+':4430/api/qsd/jwt/token',
            body: json_obj,
            rejectUnauthorized: false,
            json: true
        }, function (error, response, body) {
            
            if (error == null) {
                if (claim.recordType == "D") {
                    var details = JSON.parse('{"userCode": "","clmAuditNbr": "","subAuditNbr": "","div": ""}');
                    details.userCode = "90558";
                    details.clmAuditNbr = claim.clmAuditNbr.substring(0, 8);
                    details.subAuditNbr = (claim.clmAuditNbr.length == 10) ? claim.clmAuditNbr.substring(8, 10) : "00";
                    details.div = memberRecords[0].member_id.substring(0, 3);
                    requestt.post({
                        headers: {
                            'content-type': 'application/json', 'Accept': 'application/xml',
                            'Access-Control-Allow-Origin': '*', 'Actor': 'PDAT', 'Authorization': body
                        },
                        url: process.env.COSMOS_URL + ':443/api/qsd/cosmos/v1.0/cl611/claims/read',
                        body: details,
                        rejectUnauthorized: false,
                        requestCert: false,
                        agent: false,
                        json: true
                    }, function (error, response, body) {
                        claimData = body;
                        callback(null, memberRecords, claim, claimData);
                    });
                }
                else if (claim.recordType == "H") {
                    var details = JSON.parse('{"userCode": "","clmAuditNbr": "","div": ""}');
                    details.userCode = "90558";
                    if (claim.clmAuditNbr.length >9)
                    {
                        details.clmAuditNbr = claim.clmAuditNbr.substring(claim.clmAuditNbr.length - 9);
                    }
                    else{
                        details.clmAuditNbr = claim.clmAuditNbr;
                    }
                    
                    
                    details.div = memberRecords[0].member_id.substring(0, 3);
                    requestt.post({
                        headers: {
                            'content-type': 'application/json', 'Accept': 'application/xml',
                            'Access-Control-Allow-Origin': '*', 'Actor': 'PDAT', 'Authorization': body
                        },
                        url: process.env.COSMOS_URL+':443/api/qsd/cosmos/v1.0/hz611/claims/read',
                        body: details,
                        rejectUnauthorized: false,
                        requestCert: false,
                        agent: false,
                        json: true
                    }, function (error, response, body) {
                        claimData = body;
                        callback(null, memberRecords, claim, claimData);
                    });
                }
                else {
                    callback("no records");
                }
            }
            else {
                callback({
                    error
                });
            }

        });
    }catch(error)
    {
        callback({
            error
        });
    }
}

function getMRClaimInfo(memberRecords, claim, claimData, callback) {

    if (claimData == undefined) {
        callback("no records");
        return;
    }
    else {
        var xmlData = claimData.replace('<xml version="1.0" encoding="utf-8">', '').replace('</xml>', '');
        x2j.parseString(xmlData, {}, function (err, result) {
            if (claim.recordType == "D") {
                var claim_number = result['Root']['CL611-O-AUDNBR'][0]['$']['Value'] + '-' + result['Root']['CL611-O-AUDSUB'][0]['$']['Value'];
                var charged_amt = commonLib.formatAmount(result['Root']['CL611-O-TOT-CLAIMED'][0]['$']['Value']);
                var paid_date = commonLib.formatDate(result['Root']['CL611-O-PAID-YMD'][0]['$']['Value']);
                var process_date = commonLib.formatDate(result['Root']['CL611-O-SYS-YMD'][0]['$']['Value']);
                var paid_amt = commonLib.formatAmount(result['Root']['CL611-O-TOT-PAID'][0]['$']['Value']);
                var post_date = commonLib.formatDate(result['Root']['CL611-O-POSTED-YMD'][0]['$']['Value']);
                var check_number = result['Root']['CL611-O-CHECK-EFT-NBR'][0]['$']['Value'];
                var received_date = commonLib.formatDate(result['Root']['CL611-O-RECV-YMD'][0]['$']['Value']);
                var reserve_amt = commonLib.formatAmount(result['Root']['CL611-O-TOT-RESERVES'][0]['$']['Value']);
                var allowed_amt = commonLib.formatAmount(result['Root']['CL611-O-TOT-PAID'][0]['$']['Value']) / 100.00;
                var deductible_amt = commonLib.formatAmount(result['Root']['CL611-O-TOT-DEDUCT'][0]['$']['Value']);
                var copay_amt = commonLib.formatAmount(result['Root']['CL611-O-TOT-COPAY'][0]['$']['Value']) ;
                var diagnosis_code = result['Root']['CL611-O-DIAG-CDE'][0]['$']['Value'];
                var denial_summary = result['Root']['CL611-O-DENIAL-CDE'][0]['$']['Value'];
                //car reason  CL611-O-RSN-CDE
                var remarkCodeSet = new Set();
                if(Array.isArray(result['Root']['CL611-O-DTL-DATA'])){
                    result['Root']['CL611-O-DTL-DATA'].forEach((claimLine) => {
                        remarkCodeSet.add(claimLine['CL611-O-RSN-CDE'][0]['$']['Value']);
                        remarkCodeSet.add(claimLine['CL611-O-RSN-CDE'][1]['$']['Value']);
                        remarkCodeSet.add(claimLine['CL611-O-RSN-CDE'][2]['$']['Value']);
                        remarkCodeSet.add(claimLine['CL611-O-RSN-CDE'][3]['$']['Value']);
                    });

                }else{

        
                }
                var remark_cd = Array.from(remarkCodeSet).join(',');
                var claim_first_service_date = result['Root']['CL611-O-FROM-YMD'][0]['$']['Value'];
                var claim_last_Service_date = result['Root']['CL611-O-THRU-YMD'][0]['$']['Value'];
                var claim_disallow_amt = result['Root']['CL611-O-TOT-DISALLOW'][0]['$']['Value'] / 100.00;
                var claim_sequestration_amt = result['Root']['CL611-O-TOT-SEQSTR-AMT'][0]['$']['Value'] / 100.00;
                var cosmos_provider_id = result['Root']['CL611-O-PROV-NBR'][0]['$']['Value'];
                var cosmos_div = result['Root']['CL611-O-HMO-ID'][0]['$']['Value'];
                var par_status = result['Root']['CL611-O-PAR-CDE'][0]['$']['Value'];
                var claim_type = result['Root']['CL611-O-CLAIM-TYPE'][0]['$']['Value'];
                var claim_status = result['Root']['CL611-O-STATUS'][0]['$']['Value'];
                var financial_arrangement = result['Root']['CL611-O-ASO-FLG'][0]['$']['Value'];
                var provider_num = result['Root']['CL611-O-PROV-NBR'][0]['$']['Value'];
                var provider_grp_name = result['Root']['CL611-O-PROV-NAME'][0]['$']['Value'];
                var prov_state = result['Root']['CL611-O-SRV-STATE'][0]['$']['Value'];
                var product = result['Root']['CL611-O-PRODUCT-TYPE'][0]['$']['Value'];
                var plan = result['Root']['CL611-O-BENEFIT-CDE'][0]['$']['Value'];
                var account_num = result['Root']['CL611-O-PAT-CLNIC-ACT'][0]['$']['Value'];
                var prov_tin = result['Root']['CL611-O-FED-TAX-ID'][0]['$']['Value'];
                var prov_npi = result['Root']['CL611-O-PROV-NPI-ID'][0]['$']['Value'];
                var pos = result['Root']['CL611-O-DTL-DATA'][0]['CL611-O-SITE-CDE'][0]['$']['Value'];

                var post = {
                    claim_id: claim_number,
                    claim_billed_amt: charged_amt,
                    claim_ded_amt: deductible_amt,
                    claim_copay_amt: copay_amt,
                    original_claim_received_date: received_date,
                    original_claim_process_date: post_date,
                    claim_process_date: post_date,
                    claim_paid_amt: allowed_amt,
                    DRG_Code: diagnosis_code,
                    
                    denial_cd: denial_summary,
                    remark_cd: remark_cd,
                    
                    claim_received_date: received_date,
                    check_num: check_number,
                    claim_paid_amt: paid_amt,
                    account_num: account_num,
                    claim_product: product,
                    claim_plan: plan,
                    claim_tin: prov_tin,
                    claim_npi: prov_npi,
                    claim_first_service_date: claim_first_service_date,
                    claim_last_Service_date: claim_last_Service_date,
                    // Waiting for Benefit Data to split denied from disallowed
                    //claim_disallow_amt: claim_disallow_amt,
                    claim_sequestration_amt: claim_sequestration_amt,
                    cosmos_provider_id: cosmos_provider_id,
                    cosmos_div: cosmos_div,
                    par_status: par_status,
                    claim_type: claim_type,
                    claim_status: claim_status,
                    financial_arrangement: financial_arrangement,
                    provider_num: provider_num,
                    provider_grp_name: provider_grp_name,
                    prov_state: prov_state,
                    place_of_service: pos,
                    load_file_id: memberRecords[0].load_file_id,
                    load_file_detail_id: memberRecords[0].load_file_detail_id,
                    load_file_detail_member_id: memberRecords[0].load_file_detail_member_id,


                };
                callback(null, post);
            }
            else if (claim.recordType == "H") {
                var claim_number = result['Root']['HZ611-O-AUDIT-NBR'][0]['$']['Value'] ;
                var charged_amt = commonLib.formatAmount(result['Root']['HZ611-O-TOT-CLAIMED'][0]['$']['Value']);
                var paid_date = commonLib.formatDate(result['Root']['HZ611-O-DTPD-YMD'][0]['$']['Value']);
                //var process_date = commonLib.formatDate(result['Root']['CL611-O-SYS-YMD'][0]['$']['Value']);
                var paid_amt = commonLib.formatAmount(result['Root']['HZ611-O-TOT-PAID'][0]['$']['Value']);
                var post_date = commonLib.formatDate(result['Root']['HZ611-O-POSTED-YMD'][0]['$']['Value']);
                var check_number = result['Root']['HZ611-O-CHECK-EFT-NBR'][0]['$']['Value'];
                var received_date = commonLib.formatDate(result['Root']['HZ611-O-RCV-YMD'][0]['$']['Value']);
                //var reserve_amt = commonLib.formatAmount(result['Root']['CL611-O-TOT-RESERVES'][0]['$']['Value']);
                var allowed_amt = commonLib.formatAmount(result['Root']['HZ611-O-TOT-PAID'][0]['$']['Value']) / 100.00;
                var deductible_amt = commonLib.formatAmount(result['Root']['HZ611-O-TOT-DEDUCT'][0]['$']['Value']) ;
                var copay_amt = commonLib.formatAmount(result['Root']['HZ611-O-TOT-COPAY'][0]['$']['Value']) ;
                //var diagnosis_code = result['Root']['CL611-O-DIAG-CDE'][0]['$']['Value'];
                var denial_summary = result['Root']['HZ611-O-DENIAL-CDE'][0]['$']['Value'];

                var claim_first_service_date = result['Root']['HZ611-O-FROM-YMD'][0]['$']['Value'];
                var claim_last_Service_date = result['Root']['HZ611-O-THRU-YMD'][0]['$']['Value'];
                var claim_disallow_amt = result['Root']['HZ611-O-TOT-DSLW-OTH'][0]['$']['Value'] / 100.00;
                var claim_sequestration_amt = result['Root']['HZ611-O-TOT-SEQSTR-AMT'][0]['$']['Value'] / 10000.00;
                var cosmos_provider_id = result['Root']['HZ611-O-PRV-NBR-HOSP'][0]['$']['Value'];
                var cosmos_div = result['Root']['HZ611-O-HMO-ID'][0]['$']['Value'];
                var par_status = result['Root']['HZ611-O-PRV-PAR-CDE'][0]['$']['Value'];
                var claim_type = result['Root']['HZ611-O-CLAIM-TYPE'][0]['$']['Value'];
                //var claim_status = result['Root']['CL611-O-STATUS'][0]['$']['Value'];
                //var financial_arrangement = result['Root']['CL611-O-ASO-FLG'][0]['$']['Value'];
                var provider_num = result['Root']['HZ611-O-PRV-NBR-HOSP'][0]['$']['Value'];
                var provider_grp_name = result['Root']['HZ611-O-PROV-NAME'][0]['$']['Value'];
                var prov_state = result['Root']['HZ611-O-SRV-STATE'][0]['$']['Value'];
                var prov_tin = result['Root']['HZ611-O-FED-TAX-ID'][0]['$']['Value'];
                var prov_npi = result['Root']['HZ611-O-PROV-NPI-ID'][0]['$']['Value'];
                var product = result['Root']['HZ611-O-PRODUCT-TYPE'][0]['$']['Value'];
                var plan = result['Root']['HZ611-O-BENEFIT-NBR'][0]['$']['Value'];
                var pos = result['Root']['HZ611-O-POS-CDE'][0]['$']['Value'];
                var account_num = result['Root']['HZ611-O-PTNT-ACCT-NBR'][0]['$']['Value'];
                var panel = result['Root']['HZ611-O-PANEL-USED'][0]['$']['Value'];
                
                //var pos = result['Root']['CL611-O-DTL-DATA'][0]['CL611-O-SITE-CDE'][0]['$']['Value'];

                var post = {
                    claim_id: claim_number,
                    claim_billed_amt: charged_amt,
                    claim_ded_amt: deductible_amt,
                    claim_copay_amt: copay_amt,
                    original_claim_received_date: received_date,
                    original_claim_process_date: post_date,
                    claim_process_date: post_date,
                    claim_paid_amt: allowed_amt,
                    DRG_Code: diagnosis_code,
                    denial_cd: denial_summary,
                    claim_received_date: received_date,
                    check_num: check_number,
                    claim_paid_amt: paid_amt,
                    account_num: account_num,
                    claim_tin: prov_tin,
                    claim_npi: prov_npi,
                    claim_product: product,
                    claim_plan: plan,

                    claim_first_service_date: claim_first_service_date,
                    claim_last_Service_date: claim_last_Service_date,
                    // Waiting for Benefit Data to split denied from disallowed
                    //claim_disallow_amt: claim_disallow_amt,
                    claim_sequestration_amt: claim_sequestration_amt,
                    cosmos_provider_id: cosmos_provider_id,
                    cosmos_div: cosmos_div,
                    par_status: par_status,
                    claim_type: claim_type,
                    //claim_status: claim_status,
                    //financial_arrangement: financial_arrangement,
                    provider_num: provider_num,
                    provider_grp_name: provider_grp_name,
                    prov_state: prov_state,
                    place_of_service: pos,
                    load_file_id: memberRecords[0].load_file_id,
                    load_file_detail_id: memberRecords[0].load_file_detail_id,
                    load_file_detail_member_id: memberRecords[0].load_file_detail_member_id,
                    cosmos_panel: panel

                };
                callback(null, post);
            }
            else {
                callback("no records");
            }
        })

    }

};

function insertClaimRecord(claimRecord, callback) {
    db.query('INSERT INTO  batch_file_detail_claim SET ?', claimRecord, function (error, results, fields) {
        if (error) {

            throw error;
            callback(error);
            return;
        } else {


            callback(null, results)

        }
    });
}


