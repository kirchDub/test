package com.optum.angularbootcampspring.domain;

import lombok.Data;

import java.io.Serializable;

@Data
public class NutritionFactsDto implements Serializable {

    private int totalCalories;

    private int numberOfServings;

    private String allergicNotice;
}
