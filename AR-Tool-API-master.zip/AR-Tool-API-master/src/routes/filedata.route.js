var express = require('express');
var router = express.Router();
var db = require('../config/db.config.js')

/* GET home page. */
router.get('/', function(req, res, next) {
    try{
  console.log("get called for file data");
let query = "select A.*,M.source_system,coalesce(S.status_comment,case when M.member_id is null then 'MEMBER NOT FOUND' end) as StatusMsg  from batch_file_input_detail A left outer join batch_file_detail_member M on A.load_file_detail_id = M.load_file_detail_id left outer join batch_file_detail_status S on A.load_file_detail_id = S.load_file_detail_id where A.load_file_id  in (select max(load_file_id) from batch_file_input)";
 // let query = 'select * from batch_file_input_detail where load_file_id =903';

    db.query(query, function (err, records, fields) {

        if (err) {
            console.log(err);
            res.end('Error getting file data')
        }
        else {
            if (records.length > 0) {      
                res.send({
                    status: 200,
                    result: 'success',
                    response: records
                })
            }
            else {
                res.send({
                    status: 404,
                    result: 'failure',
                    response: 'no records found'
                })
            }

        }
      });
    }catch(error) 
    {
        res.send({
            status: 500,
            result: 'failure',
            response: 'error'
        })
    }
});

router.get('/:load_file_id', function(req, res, next) {
    try{
  console.log("get called for file data ",req.params.load_file_id);
let query = "select A.*,M.source_system,coalesce(S.status_comment,case when M.member_id is null then 'MEMBER NOT FOUND' end) as StatusMsg  from batch_file_input_detail A left outer join batch_file_detail_member M on A.load_file_detail_id = M.load_file_detail_id left outer join batch_file_detail_status S on A.load_file_detail_id = S.load_file_detail_id where A.load_file_id ="+req.params.load_file_id;
 // let query = 'select * from batch_file_input_detail where load_file_id =903';

    db.query(query, function (err, records, fields) {

        if (err) {
            console.log(err);
            res.end('Error getting file data')
        }
        else {
            if (records.length > 0) {      
                res.send({
                    status: 200,
                    result: 'success',
                    response: records
                })
            }
            else {
                res.send({
                    status: 404,
                    result: 'failure',
                    response: 'no records found'
                })
            }

        }
      });
    }catch(error) 
    {
        res.send({
            status: 500,
            result: 'failure',
            response: 'error'
        })
    }
});

module.exports = router;