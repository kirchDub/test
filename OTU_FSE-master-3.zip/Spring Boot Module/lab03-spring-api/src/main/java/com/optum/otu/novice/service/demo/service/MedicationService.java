/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.optum.otu.novice.service.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.optum.otu.novice.service.demo.model.Medication;
import com.optum.otu.novice.service.demo.model.MedicationResponse;
import com.optum.otu.novice.service.demo.model.MedicationRepository;

@Service
public class MedicationService {
    @Autowired
    MedicationRepository medicationRepo;
    
    public MedicationResponse findByName(String name){
        MedicationResponse medResponse = new MedicationResponse();
        Medication m = medicationRepo.findByName(name);
        medResponse.setMedication(m);
        return medResponse;
        
    }
}
