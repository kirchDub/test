package com.optum.otu.novice.service.demo.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@Data
@NoArgsConstructor
@RequiredArgsConstructor
// TODO: Annotate this object as a JPA entity
// TODO: Add an annotation to specify the table name for this type
public class MedicationType {

    // TODO: Add fields to this class to represent the fields of the medication_type table
    // You can use the diagram in the lab notes or the medication_type.sql file for reference
}
