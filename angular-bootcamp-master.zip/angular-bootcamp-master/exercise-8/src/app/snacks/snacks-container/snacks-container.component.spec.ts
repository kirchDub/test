import { Component, DebugElement, Input } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { UITKTabbedPanelsModule } from '@uitk/angular';
import { Observable } from 'rxjs';
import { Snack, SnackType } from '../shared/snack.model';
import { SnackService } from '../shared/snack.service';

import { SnacksContainerComponent } from './snacks-container.component';

const snack: Snack = {
  id: 1,
  name: 'Hummus',
  description: 'A dip, spread, or savory dish made from cooked, mashed chickpeas',
  snackType: SnackType.Umami,
  calories: 177,
  fat: 8.59,
  protein: 4.8,
  carbohydrates: 20.1,
};

describe('SnacksContainerComponent', () => {
  let component: SnacksContainerComponent;
  let fixture: ComponentFixture<SnacksContainerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ UITKTabbedPanelsModule ],
      declarations: [ 
        SnacksContainerComponent,
        SnacksTableComponentStub,
        SnacksTreeComponentStub,
        SnackDetailComponentStub,
      ],
      providers: [{ provide: SnackService, useClass: MockSnackService }],
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SnacksContainerComponent);
    component = fixture.componentInstance;
    TestBed.inject(SnackService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should recieve data in ngOnInit', () => {
    expect(component.snacks).toContain(snack);
  });

  it('should display tab titles', () => {
    const tabs: DebugElement[] = fixture.debugElement.queryAll(By.css('[role=tab]'));
    
    expect(tabs[0].nativeElement.textContent.trim()).toEqual(component.snacksTableTitle);
    expect(tabs[1].nativeElement.textContent.trim()).toEqual(component.snacksTreeTitle);
  });
});

class MockSnackService {
  get allSnacks(): Observable<Snack[]> {
    return new Observable<Snack[]>(subscriber => {
      subscriber.next([ snack ]);
    });
  }
}

@Component({selector: 'app-snacks-table', template: ''})
class SnacksTableComponentStub {

  @Input()
  data: Snack[];
}

@Component({selector: 'app-snacks-tree', template: ''})
class SnacksTreeComponentStub {

  @Input()
  data: Snack[];
}

@Component({selector: 'app-snack-detail', template: ''})
class SnackDetailComponentStub {

  @Input()
  snack: Snack;
}
