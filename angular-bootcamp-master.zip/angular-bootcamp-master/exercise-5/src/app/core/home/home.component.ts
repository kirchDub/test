import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styles: [
  ]
})
export class HomeComponent implements OnInit {

  titleText = 'Snack Food, Satiety, and Weight'; 

  bodyText = "In today's society, snacking contributes close to one-third of daily energy intake, with many snacks consisting of energy-dense and nutrient-poor foods. Choices made with regard to snacking are affected by a multitude of factors on individual, social, and environmental levels. Social norms, for example, that emphasize healthful eating are likely to increase the intake of nutrient-rich snacks. In addition, satiety, the feeling of fullness that persists after eating, is an important factor in suppressing overconsumption, which can lead to overweight and obesity. Thus, eating snacks between meals has the potential to promote satiety and suppress overconsumption at the subsequent meal. Numerous studies have explored the relation between snack foods and satiety. These studies concluded that whole foods high in protein, fiber, and whole grains (e.g., nuts, yogurt, prunes, and popcorn) enhance satiety when consumed as snacks. Other foods that are processed to include protein, fiber, or complex carbohydrates might also facilitate satiety when consumed as snacks. However, studies that examined the effects of snack foods on obesity did not always account for satiety and the dietary quality and portion size of the snacks consumed. Thus, the evidence concerning the effects of snack foods on obesity has been mixed, with a number of interventional and observational studies not finding a link between snack foods and increased weight status. Although further prospective studies are warranted to conclusively determine the effects of snack foods on obesity risk, the consumption of healthful snacks likely affects satiety and promotes appetite control, which could reduce obesity.";

  citationText = 'Njike, Valentine & Garvin, Teresa & Shuval, Omree & Shuval, Kerem & Edshteyn, Ingrid & Kalantari, Vahid & Yaroch, Amy. (2016). Snack Food, Satiety, and Weight. Advances in Nutrition: An International Review Journal. 7. 866-878. 10.3945/an.115.009340.';

  constructor() { }

  ngOnInit(): void {
  }

}
