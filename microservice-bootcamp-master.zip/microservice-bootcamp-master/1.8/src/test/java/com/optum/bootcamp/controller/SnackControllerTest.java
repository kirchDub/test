package com.optum.bootcamp.controller;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.optum.bootcamp.entity.SnackEntity;
import com.optum.bootcamp.model.Snack;
import com.optum.bootcamp.service.SnackService;

@SpringBootTest
public class SnackControllerTest {

  @Autowired private SnackController snackController;
  @MockBean private SnackService snackService;

  @Test
  public void getSnackByIdTest() {
    SnackEntity snackEntityToReturn = new SnackEntity();
    snackEntityToReturn.setId(3);
    snackEntityToReturn.setName("Butterfingers");

    Mockito.when(snackService.getSnackById(3)).thenReturn(snackEntityToReturn);

    Snack retrievedSnack = snackController.getSnackById(3);

    assertThat(retrievedSnack.getId()).isEqualTo(3);
    assertThat(retrievedSnack.getName()).isEqualTo("Butterfingers");
  }

  @Test
  public void getAllSnacksTest() {
    snackController.getAllSnacks();

    Mockito.verify(snackService).getAllSnacks();
  }

  @Test
  public void createSnackTest() {
    Integer id = 1;
    String name = "Skittles";

    Snack snackToCreate = new Snack();
    snackToCreate.setName(name);

    SnackEntity snackEntityToReturn = new SnackEntity(id, name);

    Mockito.when(snackService.createSnack(Mockito.any(SnackEntity.class)))
        .thenReturn(snackEntityToReturn);

    Snack createdSnack = snackController.createSnack(snackToCreate);

    assertThat(createdSnack.getId()).isEqualTo(id);
    assertThat(createdSnack.getName()).isEqualTo(name);
  }

  @Test
  public void updateSnackTest() {
    Integer id = 1;
    String originalName = "KitKat";
    String newName = "Twix";

    Snack snackToUpdate = new Snack(id, originalName);
    SnackEntity snackEntityToReturn = new SnackEntity(id, newName);

    Mockito.when(snackService.updateSnack(Mockito.any(SnackEntity.class)))
        .thenReturn(snackEntityToReturn);

    Snack snack = snackController.updateSnack(snackToUpdate);

    assertThat(snack.getId()).isEqualTo(id);
    assertThat(snack.getName()).isEqualTo(newName);
  }

  @Test
  public void deleteSnackByIdTest() {
    Integer id = 1;
    String name = "Milky Way";
    SnackEntity snackEntityToReturn = new SnackEntity(id, name);

    Mockito.when(snackService.deleteSnackById(id)).thenReturn(snackEntityToReturn);

    Snack snack = snackController.deleteSnackById(id);

    assertThat(snack.getId()).isEqualTo(id);
    assertThat(snack.getName()).isEqualTo(name);
  }
}
