package com.optum.otu.novice.service.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicesNoviceDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicesNoviceDemoApplication.class, args);
	}

}
