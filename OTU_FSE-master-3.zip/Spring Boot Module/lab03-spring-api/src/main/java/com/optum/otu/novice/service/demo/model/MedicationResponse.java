/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.optum.otu.novice.service.demo.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class MedicationResponse implements Serializable {

    private String statusMessage;
    private Medication medication;

    public Medication getMedication() {
        return medication;
    }

    public void setMedication(Medication _medication) {
        this.medication = _medication;
    }
    
    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String _message) {
        this.statusMessage = _message;
    }
}
