import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { UITKTableModule } from '@uitk/angular';
import { Snack, SnackType } from '../shared/snack.model';

import { SnacksTableComponent } from './snacks-table.component';

const testData: Snack[] = [
  {
    id: 1,
    name: 'Hummus',
    description: 'A dip, spread, or savory dish made from cooked, mashed chickpeas',
    snackType: SnackType.Umami,
    calories: 177,
    fat: 8.59,
    protein: 4.8,
    carbohydrates: 20.1,
  },
];

describe('SnacksTableComponent', () => {
  let component: SnacksTableComponent;
  let fixture: ComponentFixture<SnacksTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ UITKTableModule ],
      declarations: [ SnacksTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SnacksTableComponent);
    component = fixture.componentInstance;
    component.data = testData;
    fixture.detectChanges();
  });
  
  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  it('should emit selectedSnack', () => {
    component.selectedSnack.subscribe((snack: Snack) => component.selected = snack);
    const tableRows: DebugElement[] = fixture.debugElement.queryAll(By.css('tr.uitk-c-table__row--selectable'));
    
    tableRows[0].nativeElement.click();
    expect(component.selected).toEqual(testData[0]);
  });
});