package com.optum.otu.novice.service.demo.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import javax.persistence.*;

@Data
@NoArgsConstructor
@RequiredArgsConstructor
@Entity
@Table(name = "medication")
public class Medication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String brandname;
    private String classification;
    private String description;
    private String doseform;
    @ManyToOne
    @JoinColumn(name="drugtype")
    private MedicationType drugType;
    private String drugusages;
    @NonNull
    private Long federallegendcode;
    @NonNull
    private Long genericmedid;
    @NonNull
    private Boolean generic;
    @NonNull
    private String name;
    private String route;
    private String strength;
    private String strengthnumericunit;
    private String strengthunit;

}

